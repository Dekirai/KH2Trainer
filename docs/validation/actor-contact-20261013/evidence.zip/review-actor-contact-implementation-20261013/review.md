# Unabhängiger Review: Actor-Kontaktdiagnose

**Akzeptiert, keine offenen Findings.** Geprüft wurde der vom Implementierer bestätigte Quellstand für die sechs neuen Nur-Lese-Werte 493–498. Die bereits ausgelieferten Pakete v0.12.22 wurden nicht verändert; deren `Source.zip` dient als gepinnte Baseline.

## Prüfung

- Soras Werte verwenden die bereits abgeschlossene Rollen-, Status- und Listenprüfung des vorhandenen Gameplay-Snapshots. Ladezustand, Übergang und fehlender Spieler unterdrücken die Werte. Die neuen Lesezugriffe liegen innerhalb des bereits validierten Actorbereichs.
- Zielwerte verwenden die bestehende vollständige, begrenzte aktive Liste, aktuelle Lock-on-Bindungen und Statusrückverweise. Ein zur Beendigung markiertes oder bereits bei null HP angekommenes Ziel kann diagnostisch sichtbar bleiben, solange diese Identität noch gültig ist.
- Alle bisherigen Bedingungen für Zielaktionen bleiben als `ObserveTarget && TargetActionReady` erhalten. `CombatHandle` ist gegen v0.12.22 textgleich; der ebenfalls auf `GetTarget` angewiesene Damage-Tuning-Code ist unverändert. HP- und Revenge-Schreibaktionen werden dadurch nicht für beendende Ziele freigegeben.
- Keine zusätzliche Listentraversierung, kein gespeicherter Actorzeiger, kein neuer Hook und kein nativer Counter-/VM-Aufruf. Die neuen Stores betreffen ausschließlich den gemeinsamen Snapshot. Ein Counterwert null wird nicht als Freigabezulassung verwendet.
- Der vollständige vorzeichenlose DWORD-Bereich bleibt in der Double-Darstellung exakt. Die bereits vorhandene Snapshotleerung entfernt alte Gültigkeitsbits und Werte. Der Katalog ergänzt ausschließlich sechs Nur-Lese-Einträge ohne Befehl oder Profilwiedergabe.

## Eigene isolierte MSVC-Läufe

| Suite | Prüfungen | Fehler |
|---|---:|---:|
| ActorContactDiagnosticsTests | 122 | 0 |
| CombatGuardTests | 2333 | 0 |
| GameplayStateGuardTests | 1066 | 0 |
| TrainerPerformanceTests | 29 | 0 |
| **Gesamt** | **3550** | **0** |

Die neue Suite prüft unter anderem DWORD-Grenzen, getrennte Beendigungsbits, Rollen/Formen, fehlende Statusbindung, entfernte und zyklische Listen, ungültige Lock-on-Ziele, Hostablauf, falschen Thread und Szenenübergang. Der Durchlauf mit nicht ausführbarem, nur lesbarem Fixtureimage und vergifteten VM-Zeigern bestätigt die direkten Lesezugriffe. Ein Bytevergleich erfasst unveränderten Spiel-Fix­turespeicher. Gemessene Tail-Node-Abfragen bleiben bei einer Traversierung pro Snapshot, kombiniert bei zwei.

Die Leistungssuite besteht weiterhin; ihre privaten Zeitmessungen und synthetischen Abfragezahlen sind keine Aussage über die tatsächlichen FPS beim Nutzer. Es gab keine Live-Spiel-, GUI-, Save-, Injection- oder Twitch-Aktion. Ein vollständiger Build und unabhängige Managed-/UI-Ausführung eines künftigen Releases gehören nicht zu diesem Native-Review.

`review.json` pinnt zwölf Quelldateien, das Baselinearchiv und die vier unabhängigen Testlogs. `native-source.diff` enthält den auf Zeilenenden normalisierten Vergleich der beiden geänderten Native-Dateien. Reproduktion der Original-/Quell- und Logpins:

```powershell
py -3 -B artifacts/review-actor-contact-implementation-20261013/audit.py --check
```
