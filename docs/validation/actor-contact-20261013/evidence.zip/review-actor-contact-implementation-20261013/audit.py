"""Independent, read-only source comparison and test-log receipt."""
import argparse,difflib,hashlib,json,re,zipfile
from pathlib import Path
H=Path(__file__).resolve().parent;ROOT=H.parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
normalize=lambda s:'\n'.join(s.splitlines())+'\n'
def function(text,name):
 at=text.index(name);start=text.index('{',at);depth=0
 for index in range(start,len(text)):
  if text[index]=='{':depth+=1
  if text[index]=='}':
   depth-=1
   if not depth:return text[at:index+1]
 raise AssertionError(name)
def main(check=False):
 archive=ROOT/'artifacts/packages/KH2_Trainer_v0.12.22/Source.zip';z=zipfile.ZipFile(archive)
 def old(name):return normalize(z.read(name).decode('utf-8-sig'))
 def now(name):return normalize((ROOT/name).read_text(encoding='utf-8-sig'))
 names=[
  'src/KH2Trainer.Bridge/GameplayStateSupport.inl','src/KH2Trainer.Bridge/CombatFeatures.inl',
  'src/KH2Trainer.Bridge/TrainerBridge.cpp','src/KH2Trainer.Bridge/DamageTuningFeatures.inl',
  'tests/KH2Trainer.Bridge.Tests/ActorContactDiagnosticsTests.cpp','tests/KH2Trainer.Bridge.Tests/run-tests.ps1',
  'tests/KH2Trainer.Bridge.Tests/CombatGuardTests.cpp','tests/KH2Trainer.Bridge.Tests/GameplayStateGuardTests.cpp',
  'tests/KH2Trainer.Bridge.Tests/PlayerBridgeTests.cpp','tests/KH2Trainer.Bridge.Tests/GummiRequestBridgeTests.cpp',
  'tests/KH2Trainer.Bridge.Tests/TrainerPerformanceTests.cpp','src/KH2Trainer/Data/features.json',
 ]
 pins=[{'path':name,'bytes':(ROOT/name).stat().st_size,'sha256':sha((ROOT/name).read_bytes())} for name in names]
 gameplay=names[0];combat=names[1]
 assert old(gameplay).split('void GameplayStateSnapshot(')[0]==now(gameplay).split('void GameplayStateSnapshot(')[0]
 unchanged=[]
 for signature in ['bool PhaseReady(','bool HostFresh(','bool PlayerReady(','bool Listed(','bool CombatHandle(','void CombatTick(','void CombatReset(']:
  assert function(old(combat),signature)==function(now(combat),signature),signature
  unchanged.append(signature)
 for name in [names[2],names[3],names[7],names[10]]:assert old(name)==now(name),name
 diff=''.join(''.join(difflib.unified_diff(old(name).splitlines(True),now(name).splitlines(True),fromfile='v0.12.22/'+name,tofile='reviewed/'+name)) for name in [gameplay,combat])
 newcatalog=load(ROOT/names[-1]);oldcatalog=json.loads(z.read(names[-1]))
 contacts=[f for f in newcatalog if 493<=f['CapabilitySlot']<=498]
 assert len(contacts)==6 and [f for f in newcatalog if f not in contacts]==oldcatalog
 for f in contacts:
  assert f['Kind']=='ReadOnly' and f['CommandId']==0 and f['ValueSlot']==f['CapabilitySlot']
  assert not f.get('Arguments') and not f['CanSaveInProfile'] and not f['ChangesProgression']
  assert f['Maximum']==(4294967295 if f['ValueSlot'] in [493,496] else 1)
 logs=[]
 for suite,expected in [('ActorContactDiagnosticsTests',122),('CombatGuardTests',2333),('GameplayStateGuardTests',1066),('TrainerPerformanceTests',29)]:
  p=H/'logs'/('native-'+suite+'.txt');raw=p.read_bytes();text=raw.decode('utf-8-sig')
  assert re.search(str(expected)+r' checks, 0 failures',text),suite
  assert not re.search(r'warning C\d|error C\d|FAIL:',text),suite
  logs.append({'suite':suite,'checks':expected,'failures':0,'path':p.relative_to(H).as_posix(),'sha256':sha(raw)})
 receipt={'status':'ACCEPTED','findings':[],'scope':'Source-only actor contact diagnostic slots 493..498, native gate preservation, no new traversal or game calls; no package/release approval.',
  'baseline':{'path':archive.relative_to(ROOT).as_posix(),'sha256':sha(archive.read_bytes())},'sourcePins':pins,
  'unchangedNativeFunctions':unchanged,'existingGameplayInspectionUnchanged':True,'trainerFrameAndDamageTuningUnchanged':True,
  'catalogOnlySixReadoutsAdded':True,'tests':logs,'independentlyRunChecks':sum(x['checks'] for x in logs),
  'manualConclusions':[
   'Sora readouts reuse the successful current gameplay identity check and reject loading/transition/no-player; counter and flags are within its validated Actor span.',
   'Target readouts reuse one complete bounded active-list/lock/status observation. Read-only retirement and zero HP do not admit action paths.',
   'GetTarget retains the conjunction of the previous validation terms through ObserveTarget plus TargetActionReady; CombatHandle and DamageTuning call sites are unchanged.',
   'No native counter predicate, VM dispatch, retained Actor, lifetime hook or game-memory store is added; only shared snapshot values/capabilities are written.',
   'UInt32 values fit exactly in the double snapshot. Absent observations remain invalid after the existing publication clear.',
   'New tests execute compiled bridge code against synthetic read-only/non-executable memory; they do not execute native game bodies.'
  ],'limits':['Synthetic tests and source review, no live game/UI/Twitch test.','Performance suite and tail-query counters prove their bounded fixtures; no user-machine FPS guarantee.','The new source-only diagnostic work is separate from delivered v0.12.22 packages.','Independent managed build/UI execution and full next-release build are outside this native review.']}
 def emit(name,data):
  if isinstance(data,dict):data=(json.dumps(data,indent=2,ensure_ascii=False)+'\n').encode()
  elif isinstance(data,str):data=data.encode()
  if check:assert (H/name).read_bytes()==data,name
  else:(H/name).write_bytes(data)
 emit('native-source.diff',diff);emit('review.json',receipt)
 if check and (H/'manifest.json').exists():
  rows=load(H/'manifest.json')['files'];actual={p.relative_to(H).as_posix() for p in H.rglob('*') if p.is_file() and p.name!='manifest.json'}
  assert actual=={r['path'] for r in rows}
  for row in rows:
   data=(H/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
 print(json.dumps({'status':'ACCEPTED','sourcePins':len(pins),'nativeChecks':receipt['independentlyRunChecks'],'findings':0}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');main(p.parse_args().check)
