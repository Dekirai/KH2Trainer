"""Correct public counter semantics; no builds or product execution."""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
for name in ['report.json', 'source-diff.patch']:
    old = HERE / name
    backup = HERE / (old.stem + '-before-semantic-rename' + old.suffix)
    assert not backup.exists(), backup
    backup.write_bytes(old.read_bytes())

def edit(relative, replacements):
    path = ROOT / relative
    data = path.read_bytes()
    for before, after in replacements:
        assert before.encode() in data, (relative, before)
        data = data.replace(before.encode(), after.encode())
    path.write_bytes(data)

edit('src/KH2Trainer/Data/features.json', [
    ('.contact_references', '.reference_count'),
    ('Actor contact diagnostics', 'Actor reference diagnostics'),
    ('Sora contact references', 'Sora references'),
    ('Target contact references', 'Target references'),
    ('Contact references currently counted for Sora. A contact can hold two references to the same actor. Unavailable when Sora cannot be verified.',
     'References currently counted for Sora. Scripts, commands and attacks can contribute; this is not a count of attacks or unique objects.'),
    ('Contact references currently counted for the lock-on enemy. A contact can hold two references to the same actor. Unavailable when no current enemy can be verified.',
     'References currently counted for the current enemy. Scripts, commands and attacks can contribute; this is not a count of attacks or unique objects.'),
    ('0x1403CFB10 / 0x1403B4420', '0x1403CFB10 / 0x1403B4420 / 0x1403E1240 / 0x1403E1A00 / 0x1403DB140 / 0x1403DB100'),
    ('Actor DWORD+1464 is decremented for each non-null contact field+12/+20; those references can alias. Read directly without calling the native counter predicate, which can run VM work.',
     'Actor DWORD+1464 counts references from multiple sources. The YSVM constructor increments the non-null actor stored at VM+96; its guarded cleanup decrements it. Actor command installation and release also increment/decrement the field. Contact cleanup decrements each non-null field+12/+20, which can alias. Read directly without calling the native counter predicate, which can run VM work.'),
])
# Only the two reference counter rows receive the additional evidence source.
p = ROOT / 'src/KH2Trainer/Data/features.json'
data = p.read_bytes()
needle = b'"Level": "Original-byte and IDA evidence in actor-contact-retirement-20261013; bounded snapshot integration. Live gameplay not tested."'
rows = json.loads(data)
for f in rows[-6:]:
    if f['CapabilitySlot'] in [493, 496]:
        start = data.index(('"Id": "' + f['Id'] + '"').encode())
        end = data.index(needle, start)
        replacement = needle.replace(b'actor-contact-retirement-20261013;', b'actor-contact-retirement-20261013 and actor-counter-writers-20261013;')
        data = data[:end] + replacement + data[end+len(needle):]
p.write_bytes(data)

edit('src/KH2Trainer/ViewModels/Navigation.cs', [
    ('Actor contact diagnostics', 'Actor reference diagnostics'), ('Actor contacts', 'Actor references')])
edit('tests/KH2Trainer.Core.Tests/ActorContactCatalogTests.cs', [
    ('.contact_references', '.reference_count'), ('Actor contact', 'Actor reference'),
    ('row.Description.Contains("two references")', 'row.Description.Contains("Scripts, commands and attacks can contribute") && row.Description.Contains("not a count of attacks or unique objects")'),
    ('Contact aliases and full UInt32 range are explicit', 'Multiple reference sources and full UInt32 range are explicit'),
    ('Contact diagnostic replay', 'Actor reference diagnostic replay')])
edit('tests/KH2Trainer.UiTests/FeatureLayoutUiChecks.cs', [
    ('contacts', 'references'), ('contactTab', 'referenceTab'),
    ('contact observation', 'actor reference observation'), ('Contact readout', 'Actor reference readout'),
    ('contact readout', 'actor reference readout')])

edit('artifacts/review-package-v01223-20261013/prepare.py', [
    ("'contact_references'", "'reference_count'"),
    ("'two references' in f['Description']", "'Scripts, commands and attacks can contribute' in f['Description'] and 'not a count of attacks or unique objects' in f['Description']"),
    ('Actor contacts', 'Actor references'),
    ('contact alias count explained', 'multiple reference sources explained')])
print('Renamed four managed/catalog source files and package-audit preparation. Native files unchanged. No build/test run.')
