from pathlib import Path
import difflib
import hashlib
import json
import re
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
files = [
    'src/KH2Trainer.Bridge/CombatFeatures.inl',
    'src/KH2Trainer.Bridge/GameplayStateSupport.inl',
    'src/KH2Trainer/Data/features.json',
    'src/KH2Trainer/ViewModels/Navigation.cs',
    'tests/KH2Trainer.Bridge.Tests/ActorContactDiagnosticsTests.cpp',
    'tests/KH2Trainer.Bridge.Tests/CombatGuardTests.cpp',
    'tests/KH2Trainer.Bridge.Tests/PlayerBridgeTests.cpp',
    'tests/KH2Trainer.Bridge.Tests/GummiRequestBridgeTests.cpp',
    'tests/KH2Trainer.Bridge.Tests/run-tests.ps1',
    'tests/KH2Trainer.Core.Tests/ActorContactCatalogTests.cs',
    'tests/KH2Trainer.Core.Tests/Program.cs',
    'tests/KH2Trainer.UiTests/FeatureLayoutUiChecks.cs',
]
def pin(relative):
    p = ROOT / relative
    b = p.read_bytes()
    return {'path': relative, 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

baseline = ROOT / 'artifacts/packages/KH2_Trainer_v0.12.22/Source.zip'
diff = []
with zipfile.ZipFile(baseline) as archive:
    old_catalog = json.loads(archive.read('src/KH2Trainer/Data/features.json'))
    for name in files:
        before = archive.read(name).decode('utf-8-sig') if name in archive.namelist() else ''
        after = (ROOT / name).read_text(encoding='utf-8-sig')
        diff.extend(difflib.unified_diff(before.replace('\r\n','\n').splitlines(True), after.splitlines(True), fromfile='v0.12.22/'+name, tofile='current/'+name))
current = json.loads((ROOT / 'src/KH2Trainer/Data/features.json').read_bytes())
assert current[:len(old_catalog)] == old_catalog
assert len(old_catalog) == 364 and len(current) == 370
assert [f['CapabilitySlot'] for f in current[364:]] == list(range(493,499))
prior_receipt_path = 'artifacts/actor-contact-implementation-20261013/report-before-semantic-rename.json'
prior_receipt = json.loads((ROOT / prior_receipt_path).read_bytes())
prior_pins = {p['path']: p for p in prior_receipt['sourcePins']}
changed = [name for name in files if pin(name) != prior_pins[name]]
assert set(changed) == {
    'src/KH2Trainer/Data/features.json', 'src/KH2Trainer/ViewModels/Navigation.cs',
    'tests/KH2Trainer.Core.Tests/ActorContactCatalogTests.cs', 'tests/KH2Trainer.UiTests/FeatureLayoutUiChecks.cs'}
assert [f['Id'] for f in current[364:]] == [
    f'actor.{subject}.{field}' for subject in ['sora', 'target']
    for field in ['reference_count', 'retirement_requested', 'retirement_marked']]
assert all(f['Category'] == 'Actor reference diagnostics' for f in current[364:])
(HERE / 'source-diff.patch').write_text(''.join(diff),encoding='utf-8')

native = {}
for name in ['ActorContactDiagnosticsTests','CombatGuardTests','GameplayStateGuardTests','GummiRequestBridgeTests','PlayerBridgeTests','TrainerPerformanceTests']:
    path = 'artifacts/actor-contact-implementation-20261013/logs/native-'+name+'.txt'
    log = (ROOT / path).read_text(encoding='utf-8-sig')
    totals = re.findall(r'(\d+) checks, (\d+) failures',log)
    assert len(totals)==1 and int(totals[0][1])==0, name
    assert not re.search(r'\b(?:warning|error) [A-Z]+\d+|^FAIL',log,re.M), name
    native[name] = {'checks': int(totals[0][0]), 'log': pin(path)}
core_log = (HERE/'core-tests.log').read_text(encoding='utf-8-sig')
assert '3492 passed, 0 failed' in core_log
ui = json.loads((HERE/'ui/report.json').read_bytes())
assert ui['success'] and ui['sourceIsSynthetic'] and ui['bindingErrors']==ui['windowCount']==0
assert ui['featurePages']['features']==370 and ui['twitch']['rewards']==65
sections = [v for v in ui.values() if isinstance(v,dict)]
ui_checks = sum(v.get('checks',0) for v in sections)
ui_renders = sum(len(v['renders']) if isinstance(v.get('renders'),list) else v.get('renders',0) for v in sections)
assert ui_checks==3501 and ui_renders==57
report = {
    'status': 'SOURCE_NAMING_CORRECTED_PENDING_ROOT_BUILD',
    'nativeChecks': sum(v['checks'] for v in native.values()), 'nativeSuites': native,
    'coreChecks': 3492, 'uiChecks': ui_checks, 'uiRenders': ui_renders,
    'catalogFeatures': 370, 'rewardsUnchanged': 65, 'prior364FeaturesUnchanged': True,
    'mapping': [{key:f[key] for key in ['Id','CommandId','CapabilitySlot','ValueSlot']} for f in current[364:]],
    'implementation': [
        'Current Sora raw counter and two independent flags reuse the existing completed GameplayState inspection; retirement input blocking remains observable, while unknown identity/loading/transition/absent player suppress values.',
        'Current target observation retains lock bindings, full bounded active-list membership, enemy category, status backpointer, absent save links and health ranges; only zero HP and retirement/action flags are excluded from the separate strict action predicate.',
        'CombatSnapshot calls ObserveTarget once and reuses it for prior HP/revenge and new readouts. TargetActionReady preserves the original writable-action admission conditions.',
        'Readouts copy Actor DWORD+1464 and bits0x10000000/0x80000 from DWORD+288. They install no hooks, retain no actor pointers and call no native predicates.',
        'A counted private tail node proves one existing target list traversal, one existing player inspection list traversal and exactly two combined; the existing100ms publication cadence remains intact.',
        'Counter is an unsigned DWORD reference count with script VM, actor command and attack/contact sources; it counts neither attacks nor unique objects. Two contact reference fields can alias. Neither counter0 nor a retirement flag proves safe destruction or next-frame completion.',
    ],
    'validation': [
        'Full production bridge included in synthetic native test executable; isolated private memory only. Read-only non-executable image plus poisoned actor VM pointers remains unchanged after snapshots.',
        'Unsigned boundary values through UINT32_MAX, independent flags, stale/absent publication clearing, foreign bindings, complete-list cycles/membership, bad status/ranges, Sora role/forms and rejected target mutations covered.',
        'Before the semantic rename, embedded WPF catalog/navigation and FeatureVm formatting were verified offscreen. The saved dark Actor contacts PNG and managed test logs predate the renamed Actor references tab and descriptions; they do not verify the current wording. No visible windows or input.',
        'The UI fixture explicitly used SkipNativeBridgeBuild=true and reused the existing embedded bridge; no production DLL, package, version, README or research document was rebuilt or changed by this integration work.',
    ],
    'validationProvenance': {
        'priorTestedSourceReceipt': pin(prior_receipt_path),
        'changedSincePriorTestRuns': changed,
        'nativeSourceAndTestsUnchanged': True,
        'currentManagedNamingCompiledOrTested': False,
        'rootFullBuildRequiredForCurrentNaming': True,
        'note': 'Native checks still refer to byte-identical native sources and tests. Core3492/UI3501/57 are preserved prior-run totals, not current renamed-source validation. The root requested no build or test run during this correction.'
    },
    'sourcePins': [pin(name) for name in files],
    'coreLog': pin('artifacts/actor-contact-implementation-20261013/core-tests.log'),
    'uiReport': pin('artifacts/actor-contact-implementation-20261013/ui/report.json'),
    'uiLog': pin('artifacts/actor-contact-implementation-20261013/ui-tests.log'),
    'uiImage': pin('artifacts/actor-contact-implementation-20261013/ui/FeaturePages/advanced-actor-contacts.png'),
    'baselineSourceArchive': pin('artifacts/packages/KH2_Trainer_v0.12.22/Source.zip'),
    'scope': 'Source-only implementation and targeted synthetic regression suites. No packaged release, live game, injected code, Twitch account, real save, native getter invocation or GUI input. Existing all-repository work outside the owned file list is preserved.',
}
(HERE/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['status','nativeChecks','coreChecks','uiChecks','uiRenders','catalogFeatures']}))
