"""Read-only correction receipt; preserve earlier native and managed test provenance."""
import argparse,hashlib,json,zipfile
from pathlib import Path
H=Path(__file__).resolve().parent;ROOT=H.parents[1]
sha=lambda data:hashlib.sha256(data).hexdigest()
load=lambda path:json.loads(path.read_bytes())
def pin(path):
 data=path.read_bytes();return {'path':path.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':sha(data)}
def main(check=False):
 previous=ROOT/'artifacts/review-actor-contact-implementation-20261013/review.json';old=load(previous)
 native=[p for p in old['sourcePins'] if p['path']!='src/KH2Trainer/Data/features.json']
 for p in native:assert pin(ROOT/p['path'])==p,p['path']
 implementation=ROOT/'artifacts/actor-contact-implementation-20261013/report.json'
 assert sha(implementation.read_bytes())=='6b361661da478b678a06ab83249b21f26e6543e812e4b98f49ca455d49676dd5'
 current=load(implementation);changed=current['validationProvenance']['changedSincePriorTestRuns']
 expected=['src/KH2Trainer/Data/features.json','src/KH2Trainer/ViewModels/Navigation.cs','tests/KH2Trainer.Core.Tests/ActorContactCatalogTests.cs','tests/KH2Trainer.UiTests/FeatureLayoutUiChecks.cs']
 assert changed==expected and current['validationProvenance']['nativeSourceAndTestsUnchanged']
 assert current['validationProvenance']['currentManagedNamingCompiledOrTested'] is False
 for p in current['sourcePins']:assert pin(ROOT/p['path'])==p,p['path']
 catalog=load(ROOT/expected[0]);rows=[f for f in catalog if 493<=f['CapabilitySlot']<=498]
 baseline=ROOT/old['baseline']['path'];assert sha(baseline.read_bytes())==old['baseline']['sha256']
 with zipfile.ZipFile(baseline) as z:assert [f for f in catalog if f not in rows]==json.loads(z.read(expected[0]))
 assert len(catalog)==370 and len(rows)==6
 assert [r['Id'] for r in rows]==['actor.sora.reference_count','actor.sora.retirement_requested','actor.sora.retirement_marked','actor.target.reference_count','actor.target.retirement_requested','actor.target.retirement_marked']
 for r in rows:
  assert r['Kind']=='ReadOnly' and r['CommandId']==0 and r['ValueSlot']==r['CapabilitySlot']
  assert not r.get('Arguments') and not r['CanSaveInProfile'] and not r['ChangesProgression']
  assert r['Category']=='Actor reference diagnostics' and r['Minimum']==0
  assert r['Maximum']==(4294967295 if r['ValueSlot'] in [493,496] else 1)
  if r['ValueSlot'] in [493,496]:
   assert 'Scripts, commands and attacks can contribute' in r['Description']
   assert 'not a count of attacks or unique objects' in r['Description']
 navigation=(ROOT/expected[1]).read_text(encoding='utf-8-sig');assert 'new("Actor reference diagnostics", "advanced", "Actor references")' in navigation
 test=(ROOT/expected[2]).read_text(encoding='utf-8-sig');assert 'actor.sora.reference_count' in test and 'actor.target.reference_count' in test
 assert 'Scripts, commands and attacks can contribute' in test
 uitest=(ROOT/expected[3]).read_text(encoding='utf-8-sig');assert 't.Title == "Actor references"' in uitest
 for p in old['tests']:assert sha((previous.parent/p['path']).read_bytes())==p['sha256']
 writer=ROOT/'artifacts/actor-counter-writers-20261013/report.json'
 assert sha(writer.read_bytes())=='2c158dcb504a570dae90d7ac15c64937a2d3dfad411c61f5adc601a0360c5462'
 receipt={'status':'ACCEPTED','findings':[],'scope':'Public label/ID correction and unchanged native source pins; source review only, no new builds or test runs.',
  'previousNativeReview':pin(previous),'unchangedNativeAndTestPins':native,'currentChangedPins':[pin(ROOT/n) for n in expected],
  'currentImplementationReceipt':pin(implementation),'counterWriterEvidence':pin(writer),
  'catalog':{'total':370,'prior364RowsUnchanged':True,'newReadOnlyRows':6,'slots':[493,494,495,496,497,498],'counterIds':['actor.sora.reference_count','actor.target.reference_count']},
  'reviewConclusions':['Actor references is supported by original script-context and command counter writes in addition to attack references.','Names and descriptions no longer imply an exclusive attack/contact count; native behavior and six slot numbers are unchanged.','Navigation and source test expectations consistently use Actor references. Existing 364 catalog rows are untouched.','No new commands, profile replay, hooks, native getter calls or actor-memory writes are introduced by this correction.'],
  'validationProvenance':{'nativeChecks':3550,'nativeFailures':0,'nativeSourcesByteIdenticalToTestedReview':True,'currentManagedNamingCompiledOrTested':False,'priorManagedLogsAndScreenshotPredateRename':True,'nextFullBuildStillRequired':True},
  'limits':['No current-name managed/UI execution; prior managed passes must not be presented as current naming verification.','No live-game, FPS, UI-control or Twitch test.','No product, package, version or prior-review artifact changes by reviewer.']}
 data=(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n').encode()
 if check:assert (H/'review.json').read_bytes()==data
 else:(H/'review.json').write_bytes(data)
 if check and (H/'manifest.json').exists():
  records=load(H/'manifest.json')['files'];assert {p.relative_to(H).as_posix() for p in H.rglob('*') if p.is_file() and p.name!='manifest.json'}=={r['path'] for r in records}
  for r in records:
   raw=(H/r['path']).read_bytes();assert len(raw)==r['bytes'] and sha(raw)==r['sha256']
 print(json.dumps({'status':'ACCEPTED','unchangedPriorPins':len(native),'updatedPins':len(expected),'newTestRuns':0,'currentManagedBuildPending':True}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');main(p.parse_args().check)
