# Ergänzung: Korrekte Bezeichnung der Actor-Referenzen

**Akzeptiert, keine offenen Findings.** Die sechs Werte behalten die Slots 493–498 und bleiben reine Anzeigen. Die Zähler heißen jetzt „Sora references“ und „Target references“, mit IDs `actor.sora.reference_count` und `actor.target.reference_count`. Der Tab heißt „Actor references“.

Die zusätzliche Originalanalyse belegt Beiträge durch Skriptkontexte und Befehlsabläufe. Die neuen Beschreibungen nennen deshalb Skripte, Befehle und Angriffe als mögliche Quellen. Sie stellen den Wert weder als Angriffszahl noch als Anzahl verschiedener Objekte dar. Die vier geänderten Katalog-/Navigation-/Testdateien verwenden die neue Bezeichnung konsistent; alle bisherigen 364 Katalogeinträge sind unverändert.

Elf zuvor gepinnte Native-, Bridge-Kontext- und Testdateien sind bytegleich zum unabhängigen Testlauf mit **3550 Prüfungen und 0 Fehlern**. Die ursprüngliche Reviewakte bleibt unverändert. Ihr alter Katalogpin beschreibt bewusst den damaligen Stand; diese Ergänzung pinnt den korrigierten Katalog und die drei zugehörigen Managed-Dateien separat.

**Keine neuen Builds oder Tests ausgeführt.** Die älteren Core-/UI-Protokolle und die Aufnahme des alten Tabs stammen vor der Umbenennung. Die aktuelle Managed-Benennung benötigt weiterhin den vorgesehenen vollständigen Build. Diese Quellenprüfung ersetzt keine aktuelle UI-Ausführung und keine Live-Spielprüfung.

Reproduktion der Pins und des Katalogvergleichs:

```powershell
py -3 -B artifacts/review-actor-reference-labels-20261013/audit.py --check
```

Keine Produkt-, Paket-, Versions- oder frühere Reviewdatei wurde von diesem Review verändert.
