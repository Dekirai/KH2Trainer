import hashlib
import json
import struct
import argparse
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE = Path(__file__).resolve().parent
SOURCE = Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
EXPECTED = '9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
parser = argparse.ArgumentParser()
parser.add_argument('--check', action='store_true')
options = parser.parse_args()
def emit(path, text):
    encoded = text.encode('utf-8')
    if options.check:
        assert path.read_bytes() == encoded, str(path)
    else:
        path.write_bytes(encoded)
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
peoff = struct.unpack_from('<I', raw, 0x3c)[0]
assert raw[:2] == b'MZ' and raw[peoff:peoff+4] == b'PE\0\0'
sections = struct.unpack_from('<H', raw, peoff+6)[0]
optional = peoff+24
assert struct.unpack_from('<H', raw, optional)[0] == 0x20b
base = struct.unpack_from('<Q', raw, optional+24)[0]
table = optional + struct.unpack_from('<H', raw, peoff+20)[0]
spans = [struct.unpack_from('<IIII', raw, table+i*40+8) for i in range(sections)]
def get_data(rva, length):
    for virtual_size, address, size, offset in spans:
        if address <= rva and rva + length <= address+size:
            return raw[offset+rva-address:offset+rva-address+length]
    raise ValueError(f'No raw-backed span {rva:X}+{length:X}')
exception_rva, exception_size = struct.unpack_from('<II', raw, optional+112+3*8)
runtime_functions = list(struct.iter_unpack('<III', get_data(exception_rva, exception_size)))
md = Cs(CS_ARCH_X86, CS_MODE_64)
md.detail = True
items = []
capture = HERE / 'root-capture'
lookups = {int(x['fn']['addr'], 0): x['fn'] for x in json.loads((capture / 'lookup_funcs.json').read_text())['result']}
ida_bytes = {int(x['addr'], 0): bytes(int(b, 16) for b in x['data'].split())
             for x in json.loads((capture / 'get_bytes.json').read_text())['result']}
for rva in [0x3B6CB0, 0x3B68B0, 0x401D60, 0x405440]:
    end = rva + int(lookups[base+rva]['size'], 0)
    code = get_data(rva, end - rva)
    assert ida_bytes[base+rva] == code
    query = json.loads((capture / f'0x{base+rva:X}-instructions.json').read_text())['result'][0]
    assert query['cursor']['done'] and not query['truncated'] and not query['error']
    assert query['count'] == query['scanned'] == len(query['matches'])
    assert query['ranges'] == [{'start': hex(base+rva), 'end': hex(base+end)}]
    heads = query['matches']
    insns = []
    noncode = []
    aliases = {'retn':'ret', 'jz':'je', 'jnz':'jne', 'jnb':'jae', 'jna':'jbe',
               'jnl':'jge', 'jng':'jle', 'cmovz':'cmove', 'cmovnz':'cmovne'}
    covered = set()
    for index, head in enumerate(heads):
        address = int(head['addr'], 0)
        next_address = int(heads[index+1]['addr'], 0) if index+1 < len(heads) else base+end
        token = head['disasm'].split()[0]
        if token in ('align', 'db', 'dw', 'dd', 'dq'):
            noncode.append({'address': hex(address), 'length': next_address-address,
                            'ida': head['disasm'], 'originalBytes': get_data(address-base,next_address-address).hex(' ')})
            continue
        insn = next(md.disasm(get_data(address-base, min(15, base+end-address)), address, count=1))
        assert insn.size == next_address-address, (hex(address), insn.size, next_address-address)
        assert aliases.get(token, token) == insn.mnemonic, (head, insn.mnemonic)
        insns.append(insn)
        covered.update(range(address, address+insn.size))
    decoded = sum(i.size for i in insns)
    assert len(covered) + sum(x['length'] for x in noncode) == len(code)
    item = {'rva': hex(rva), 'endRva': hex(end),
            'peRuntimeFunctions': [{'begin':hex(a),'end':hex(b),'unwind':hex(c)}
                                   for a,b,c in runtime_functions if a < end and b > rva],
            'originalBytes': code.hex(' '), 'extentBytes': len(code), 'idaHeadCount':len(heads),
            'instructionCount': len(insns), 'instructionBytes': decoded, 'noncode': noncode,
            'instructions': [{'address': hex(i.address), 'size': i.size, 'bytes': i.bytes.hex(' '),
                              'mnemonic': i.mnemonic, 'operands': i.op_str,
                              'ida':next(h['disasm'] for h in heads if int(h['addr'],0)==i.address)} for i in insns]}
    items.append(item)
    emit(HERE / f'original-{rva:X}.asm', '\n'.join(
        f'{i.address:016X}  {i.bytes.hex(" "):24s}  {i.mnemonic} {i.op_str}' for i in insns) + '\n')
emit(HERE / 'original.json', json.dumps({'originalSha256': EXPECTED, 'imageBase': hex(base),
    'scope': 'Full IDA function extents compared byte-for-byte with original PE; each actual instruction is independently decoded. IDA data/alignment directives are retained separately and excluded from instruction totals.',
    'functions': items}, indent=2) + '\n')
print(json.dumps([{k: i[k] for k in ['rva', 'endRva', 'extentBytes', 'idaHeadCount', 'instructionCount', 'instructionBytes']} for i in items]))
