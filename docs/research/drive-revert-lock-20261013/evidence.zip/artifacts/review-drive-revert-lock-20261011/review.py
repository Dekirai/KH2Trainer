import argparse
import hashlib
import json
import struct
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p/'src/KH2Trainer.Core').is_dir())
parser = argparse.ArgumentParser()
parser.add_argument('--check', action='store_true')
options = parser.parse_args()

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p, base=HERE): return {'path':p.relative_to(base).as_posix(), 'length':p.stat().st_size, 'sha256':sha(p)}
def emit(name, value):
    data = (json.dumps(value, indent=2, ensure_ascii=False)+'\n').encode('utf-8')
    if options.check: assert (HERE/name).read_bytes() == data, name
    else: (HERE/name).write_bytes(data)

run = subprocess.run([sys.executable, '-B', str(HERE/'original.py'), '--check'], capture_output=True, text=True)
assert run.returncode == 0, run.stdout + run.stderr
original = json.loads((HERE/'original.json').read_text())
functions = original['functions']
instructions = {int(i['address'],0):i for f in functions for i in f['instructions']}
anchors = [
    (0x1403B6CB9, 'mov', 'ebx, edx'),
    (0x1403B6CBB, 'movzx', 'ecx, word ptr [rcx + 2]'),
    (0x1403B6CBF, 'cmp', 'word ptr [rax], cx'),
    (0x1403B6CC7, 'call', '0x1403b68b0'),
    (0x1403B6CD0, 'cmp', 'word ptr [rax], cx'),
    (0x1403B6CD3, 'jne', '0x1403b6cc4'),
    (0x1403B6CD5, 'movzx', 'ecx, word ptr [rax + 0x2c]'),
    (0x1403B6CD9, 'bt', 'ecx, ebx'),
    (0x1403B6CDC, 'setb', 'al'),
    (0x1403B68C4, 'movsxd', 'rcx, ecx'),
    (0x1403B68C7, 'mov', 'r9d, 0x30'),
    (0x1403B68D2, 'movsxd', 'r8, dword ptr [rdx + 4]'),
    (0x1403B68D6, 'add', 'rdx, 8'),
    (0x1403B68E0, 'cmp', 'word ptr [rax + 2], 2'),
    (0x1403B68E7, 'cmp', 'word ptr [rax], 2'),
    (0x1403B68ED, 'movsx', 'ecx, word ptr [rax + 4]'),
    (0x1403B68F1, 'call', '0x1403c5900'),
    (0x140401D9C, 'mov', 'r14d, 5'),
    (0x140401FE6, 'call', '0x1403b6cf0'),
    (0x140401FED, 'jne', '0x14040201c'),
    (0x140401FF4, 'mov', 'edx, dword ptr [rdi + 0xde0]'),
    (0x140401FFA, 'mov', 'rcx, rsi'),
    (0x140401FFD, 'call', '0x1403b6cb0'),
    (0x140402004, 'jne', '0x14040201c'),
    (0x14040201C, 'mov', 'eax, r14d'),
    (0x14040544A, 'movzx', 'r8d, word ptr [rdx + 2]'),
    (0x140405465, 'sub', 'r8d, 4'),
    (0x14040546F, 'sub', 'r8d, 1'),
    (0x140405473, 'je', '0x1404054ed'),
    (0x1404054ED, 'xor', 'edx, edx'),
    (0x1404054EF, 'call', '0x14040ce60'),
    (0x1404054F4, 'or', 'dword ptr [rsi + 0x120], 0x100'),
]
for address, mnemonic, operands in anchors:
    i = instructions[address]
    assert (i['mnemonic'],i['operands']) == (mnemonic,operands), (hex(address),i)
anchors_out = [{'address':hex(a), 'mnemonic':m, 'operands':o, 'bytes':instructions[a]['bytes']} for a,m,o in anchors]

# Resolve the two RIP-relative bsearch call operands against the PE IAT location.
for call in [0x1403B68DA, 0x1403B6913]:
    i = instructions[call]
    data = bytes.fromhex(i['bytes'])
    assert data[:2] == bytes.fromhex('ff 15')
    assert call + i['size'] + struct.unpack_from('<i',data,2)[0] == 0x14057BB80
for address in [0x1403B68B6,0x1403B68F6]:
    i = instructions[address]
    assert address + i['size'] + struct.unpack_from('<i',bytes.fromhex(i['bytes']),3)[0] == 0x142A161E8

# This is an explicit arithmetic model of MOVZX WORD / register BT32, not native execution.
form_cases = [(0,False),(1,True),(2,True),(3,True),(4,True),(5,True),(6,True),
              (7,False),(12,False),(15,False),(16,False),(31,False),(32,False),(33,True),(-1,False)]
modeled = [{'form':form, 'registerBitIndex':form&31, 'maskedWord':0x7e,
            'setsAvailabilityTo5':bool((0x7e >> (form&31)) & 1)} for form,_ in form_cases]
assert [x['setsAvailabilityTo5'] for x in modeled] == [expected for _,expected in form_cases]
body = next(f for f in functions if f['rva']=='0x401d60')
data = bytes.fromhex(body['originalBytes'])
table_index = data[0x402060-0x401d60+5]
assert table_index == 4
type5_target = struct.unpack_from('<I',data,0x40203c-0x401d60+4*table_index)[0]
assert type5_target == 0x401f3d

emit('anchor-checks.json', {'originalSha256':original['originalSha256'], 'anchors':anchors_out,
    'resolverTableGlobal':'0x142A161E8', 'resolverIndirectCallIat':'0x14057BB80',
    'type5AvailabilitySwitch':{'indirectIndex':table_index, 'targetRva':hex(type5_target)},
    'arithmeticModel':{'scope':'Arithmetic interpretation of verified MOVZX WORD and register BT32 only; no native/game execution or owner-lifetime model.', 'cases':modeled}})

counts = {'functions':len(functions), 'instructions':sum(f['instructionCount'] for f in functions),
    'instructionBytes':sum(f['instructionBytes'] for f in functions),
    'extentBytes':sum(f['extentBytes'] for f in functions),
    'noninstructionBytes':sum(n['length'] for f in functions for n in f['noncode'])}
assert counts == {'functions':4,'instructions':342,'instructionBytes':1385,'extentBytes':1551,'noninstructionBytes':166}
claims = [
    {'rva':'0x3B6CB0','claim':'RCX is the initial command row and EDX the form index. The body follows row WORD+2 through3B68B0 until WORD+0 equals WORD+2; only the resulting root WORD+44 is zero-extended and tested with register BT32, returning the carry bit in AL.',
     'limits':'No null, cycle or explicit depth guard exists in this body. This is conditional on valid rows and lookup results.'},
    {'rva':'0x3B68B0','claim':'The resolver uses table global2A161E8, rows at table+8, signed DWORD count+4 extended to R8 and row stride48. Both lookups call IAT57BB80. A row with WORD+2=2 and WORD+0!=2 is remapped via3C5900(signed WORD+4) and a second lookup.',
     'limits':'The indirect-call name bsearch is supplied by the captured IDA decompile; this review independently proves its IAT address and ABI operands. The resolver does not null-check the first returned row or bound a negative count.'},
    {'rva':'0x401D60','claim':'In the common ending path, after3B6CF0, a nonnull admitted actor supplies DWORD+3552 as the form index to3B6CB0. A nonzero AL immediately selects return5. Type5 resolves through the original inline switch data to401F3D before reaching this ending path.',
     'limits':'The meaning is native command availability for this examined path. Other admission predicates and downstream consumers remain in force.'},
    {'rva':'0x405440','claim':'Command WORD+2=5 takes4054ED: EDX=0, RCX remains the actor,40CE60 is called, and actor DWORD+288 is ORed with0x100. This local dispatch branch has no3B6CB0 availability call.',
     'limits':'Masking availability cannot itself stop a direct40CE60 call or an already-dispatched action; the callee and all forced/scripted reverts are outside this review.'},
    {'rva':'0x3B6CD5','claim':'For form indices1..6, root WORD+44 OR0x7E makes the tested bit true. Bits outside0x7E are preserved by that proposed OR. Form0,7 and12 are not blocked by that mask alone.',
     'limits':'0x7E is the proposed conservative trainer policy. Register BT uses the index modulo32; this is not admission for arbitrary form values or proof that a runtime row with id5/kind5 remains alive.'}
]
emit('review.json', {'schema':1,'status':'accepted','scope':'Independent original-PE and fresh IDA instruction review of the proposed Revert command-availability mask; no product implementation or lifetime acceptance.',
    'originalSha256':original['originalSha256'], 'counts':counts,
    'sourceProvenance':{'reviewerSession':'c6a23154, unreachable; no reopen attempted',
        'captureProvider':'Root existing IDA worker28e14b48/PID71984; root-capture/idb_list.json; original full bytes independently checked here',
        'reuse':'These known functions are freshly recaptured for verification. No claim of four newly discovered functions or closed global callgraph.'},
    'claims':claims, 'openBlockers':[],
    'integrationRequirements':['Validate the intended row is id5/kind5 and validate the bounded table before modifying WORD+44.',
        'Retained pointer lifetime, native writers, replacement/load/restore behavior and token ownership require the separate owner review.',
        'Do not describe the mask as manual-menu-only: existing context decompiles405320/404A40 show Status+436<=0 paths through3A9EA0, whose401D60<4 check can also be rejected. These three context bodies are not part of this four-body ASM review; resolve the intended natural-expiry policy separately.',
        'Direct scripted/forced calls and already dispatched actions are not blocked by the reviewed availability branch alone.',
        'Restrict form indices to the intended supported forms; neither the native lookup nor BT supplies that policy.'],
    'checks':['Full original SHA and four extent byte comparisons;342 independent Capstone decodes against complete IDA heads.',
        '32 exact semantic instruction anchors; two resolver IAT targets and two table-global RIP targets.',
        'Original inline switch entry for kind5;15 declared arithmetic boundary cases, no native execution.'],
    'methodLimits':['No complete lifetime, concurrent writer, native save or hook safety proof.',
        'Captured401D60 count186 includes183 actual instructions plus align/dd/db directives. The166 noninstruction bytes are retained separately.',
        '405440 spans three PE RUNTIME_FUNCTION records; its491-byte full IDA body is checked, not only the initial269-byte runtime range.',
        'No game, GUI, process attachment, injection, DB mutation or executable native probe performed.']})

if options.check:
    manifest=json.loads((HERE/'manifest.json').read_text())
    files={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and p != HERE/'manifest.json'}
    assert files == {x['path'] for x in manifest['members']}
    for member in manifest['members']: assert pin(HERE/member['path']) == member
else:
    emit('manifest.json',{'schema':1,'members':[pin(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p != HERE/'manifest.json']})
print(json.dumps({'status':'PASS','counts':counts,'reviewSha256':sha(HERE/'review.json'), 'manifestSha256':sha(HERE/'manifest.json')}))
