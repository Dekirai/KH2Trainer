"""Record independent managed review and prepare a read-only release audit."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent

def pin(relative):
    path = ROOT / relative
    data = path.read_bytes()
    return {'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

files = [
    'src/KH2Trainer.Core/DriveRevertLockSnapshot.cs',
    'src/KH2Trainer.Twitch/Effects/DriveRevertEffectLease.cs',
    'src/KH2Trainer.Twitch/Effects/EffectModel.cs',
    'src/KH2Trainer.Twitch/Effects/EffectEngine.cs',
    'src/KH2Trainer.Twitch/Effects/EffectCatalog.cs',
    'src/KH2Trainer/ViewModels/TwitchViewModel.cs',
    'tests/KH2Trainer.Twitch.Tests/DriveRevertOwnershipTests.cs',
    'tests/KH2Trainer.Twitch.Tests/DriveRevertLockFake.cs',
    'tests/KH2Trainer.UiTests/GameplayAdapterChecks.cs',
]
report = {
    'status': 'PASS_WITH_FIXED_FINDING', 'openBlockers': [],
    'scope': 'Independent managed source review, actual isolated Release Twitch test runner with in-process fakes, no live KH2 or Twitch account actions. Adapter tests inspected; root executed the complete isolated offscreen UI suite and this reviewer checked its saved report. Reviewer authored the fifteen additional regression checks and the lease/timer fixes after independently finding the issues.',
    'fixedFinding': {
        'title': 'Deferred form end could revert a later same-ID form after a different bridge or owner took over',
        'cause': 'Release discarded its bridge intent without recording foreign identity; a deferred EndForm could run after player control returned and see only the old numeric form ID.',
        'fix': 'Retain admitted bridge identity beyond release and record fresh different bridge or nonzero foreign owner observations before and after release. The existing EndForm ownership-lost gate then suppresses the direct native Revert. Normal owner zero after own release still permits it.',
        'before': {'passed': 2571, 'failed': 6}, 'after': {'passed': 2577, 'failed': 0},
    },
    'fixedTimerFinding': {
        'title': 'Old formtimer scalar restore could overwrite a newer bridge or owner after proven identity replacement',
        'fix': 'A separate ForeignIdentity marker records only fresh different bridge or nonzero foreign owner. RestoreAsync then removes only this old effect combat.formtimer entry. Ordinary lost owner zero and confirmed own release preserve normal timer restoration.',
        'before': {'passed': 2578, 'failed': 8}, 'after': {'passed': 2586, 'failed': 0},
        'regressions': 'Four deferred-control cases, two pre/post release takeover cases, and active loss under states0/1/2. The owner0 control case passed before and after; all eight foreign-identity timer assertions failed before and passed after.',
    },
    'reviewedRootCompileFix': {
        'file': 'tests/KH2Trainer.UiTests/GameplayAdapterChecks.cs',
        'change': 'Exactly four intentional low-half conversions of ulong const owner/bridge to uint now use unchecked; both high-half shifts are unchanged. Removing exactly those four wrappers reproduces the previously reviewed SHA2565b8df42fcae834bdc18414602e44eaf7e39e985f37056f8554499f82a23badd0.',
        'reason': 'C# constant evaluation otherwise rejects these out-of-range truncations even though the intended low32-bit split is valid.',
        'rootOffscreenReport': pin('artifacts/revert-ui-20261013/report.json'),
        'rootOffscreenLog': pin('artifacts/revert-ui-20261013.txt'),
        'savedResult': {'success': True, 'adapterChecks': 37, 'bindingErrors': 0, 'windowCount': 0},
    },
    'reviewedInvariants': [
        'All six fixed form rewards and Roulette use the same lock start/monitor/end path.',
        'Acquire requires current supported independent native bridge identity, stores cleanup intent before await, and confirms own effective owner before timer/Drive trigger.',
        'Full UInt64 bridge/owner values are split into exact UInt32 arguments and reconstructed from one fresh snapshot.',
        'No form establishment or charge without both the completed target transition and own effective lock.',
        'Fresh proven loss is observed before generic control/usability gates; missing publication pauses without asserting loss.',
        'Release is attempted before control and pending-Drive-cancel gates; uncertain ACK/state2 retains durable cleanup and is retried.',
        'Deferred cleanup never reacquires. Native direct end-Revert waits until lock release is confirmed.',
        'Replace releases old owner before new acquire; Extend retains original owner; refused Kick Out leaves old reward locked; accepted Kick Out acts before releasing it.',
        'Foreign identity appearing before release, during release, or after release while control is absent prevents a later direct Revert.',
        'Fresh bridge replacement with zero current owner also prevents a deferred old reward from reverting a same-ID form in the replacement game.',
        'Proven foreign identity also discards only the old combat.formtimer restore, leaving the newer hold at1 without a timer command; ordinary owner0 loss does not discard the normal restore.',
    ],
    'sourcePins': [pin(path) for path in files],
    'logs': [pin('artifacts/review-drive-revert-managed-20261013/' + name) for name in ['tests-before-fix.log', 'tests-after-fix.log', 'tests-before-timer-fix.log', 'tests-after-timer-fix.log']],
    'limits': [
        'No gameplay or real Twitch redemption acceptance is claimed.',
        'Generic scalar restoration otherwise retains its preexisting compare-before-restore semantics. The narrow formtimer exception requires positively observed foreign identity; missing or owner0 data is not treated as a takeover.',
        'This review does not independently re-prove the native command-mask mechanism; root and native reviewers cover it.',
    ],
}
(HERE / 'review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
(HERE / 'review.md').write_text('''# Managed Drive Revert lock review — 2026-10-13

The review found and fixed one deferred-cleanup bug. When a reward stopped while player control was absent, its later end could revert a same-ID form after a different bridge or owner took over. The lease now retains the original bridge identity after release and records fresh foreign identities before and after release. The existing form-end guard prevents that delayed native Revert.

Six new regression cases reproduced the direct-Revert bug against the actual EffectEngine and FakeGame: **2571 passed, 6 failed** before the fix, **2577 passed, 0 failed** after it. Nine further checks verified that the old timer restore cannot overwrite a newer owner or bridge: **2578 passed, 8 failed** before its narrow fix, **2586 passed, 0 failed** afterward. The owner-zero control case remained green. Normal expiry/stop, uncertain acknowledgements, owner state 2, missing player control, native transition failure, Replace/Extend and Kick Out remained green.

The reviewed source files and all four complete test logs are pinned in `review.json`. The reviewer independently found the issues, then authored the two fixes and fifteen additional regression checks. Root subsequently fixed exactly four intentional low32-bit casts of constant UInt64 test identities with `unchecked`; removing only these four wrappers reproduces the prior file hash. This is correct for the exact split-identity fixture. The root's complete isolated offscreen WPF report passed, including 37 adapter checks, zero binding errors and zero windows. That report and log are pinned too. No live game, real Twitch account, or UI input was used.

This review covers managed lock ownership, direct native Revert, and the narrow formtimer restore exception after proven foreign identity. A separate marker distinguishes fresh different bridge or nonzero foreign owner from ordinary owner-zero loss. Other scalar restore behavior remains unchanged, and native command-table evidence is reviewed separately. No live gameplay acceptance is claimed.
''', encoding='utf-8')

text = (ROOT / 'artifacts/review-package-v01221-20261011/audit.py').read_text(encoding='utf-8')
text = text.replace('v0.12.21 package audit', 'v0.12.22 package audit')
text = text.replace("KH2_Trainer_v0.12.21'", "KH2_Trainer_v0.12.22'", 1)
text = text.replace("OLD = ROOT / 'artifacts/packages/KH2_Trainer_v0.12.20'", "OLD = ROOT / 'artifacts/packages/KH2_Trainer_v0.12.21'")
old = """    for name in ['src/KH2Trainer.Bridge/DriveFeatures.inl', 'src/KH2Trainer.Bridge/DriveWeaponSupport.inl', 'tests/KH2Trainer.Bridge.Tests/DriveGuardTests.cpp', 'tests/KH2Trainer.Bridge.Tests/DriveWeaponTests.cpp']:
        check(archive.read(name) == old.read(name), 'Drive unchanged ' + name)
"""
assert old in text
text = text.replace(old, """    reviewed = js(ROOT / 'artifacts/review-drive-revert-managed-20261013/review.json')
    for row in reviewed['sourcePins']:
        data = archive.read(row['path'])
        check(len(data) == row['bytes'] and sha(data) == row['sha256'], 'independently reviewed managed source ' + row['path'])
    for name in ['src/KH2Trainer.Core/DriveRevertLockSnapshot.cs', 'src/KH2Trainer.Twitch/Effects/DriveRevertEffectLease.cs', 'src/KH2Trainer.Bridge/DriveRevertLockSupport.inl']:
        check(name in names and name not in old.namelist(), 'new Revert ownership module ' + name)
""")
text = text.replace('<Version>0.12.21</Version>', '<Version>0.12.22</Version>')
text = text.replace('len(prior) == 362', 'len(prior) == 364')
text = text.replace("check(set(features) - set(prior) == {'target_reduce_hp_percent', 'movement.heavy_jumps'} and not set(prior) - set(features), 'exact new feature IDs')", "check(features == prior, 'v22 adds no manual catalog features and preserves v21 feature definitions')")
text = text.replace("check(changed == {'display.brightness_preview'}, 'only preexisting catalog delta is brightness')", "check(not changed, 'manual catalog unchanged from v21')")
text = text.replace("for name, total in [('core', 3476), ('twitch', 2417)]:", "for name, total in [('core', 3476), ('twitch', 2586)]:")
text = text.replace("len(suites) == len(set(suites)) == 50", "len(suites) == len(set(suites)) and len(suites) >= 50")
text = text.replace("'exact50 native suites'", "'exact runner/validation native suite inventory (at least v21 baseline)'")
text = text.replace("[0, 12, 21, 0], 'EXE version0.12.21.0'", "[0, 12, 22, 0], 'EXE version0.12.22.0'")
text = text.replace("'version': '0.12.21'", "'version': '0.12.22'")
text = text.replace("'newFeatures': ['target_reduce_hp_percent', 'movement.heavy_jumps']", "'newFeatures': [], 'twitchFormRevertLock': True")
text = text.replace("'driveSourceAndTestsUnchanged': True", "'managedReviewReceipt': pin(ROOT / 'artifacts/review-drive-revert-managed-20261013/review.json')")
text = text.replace('Reviewer authored the Twitch delta; this is a packaging audit, not independent acceptance of that source implementation.', 'Reviewer independently reviewed managed ownership and authored the deferred-end identity and timer fixes plus fifteen regression checks; native implementation acceptance belongs to the independent native review. This is a packaging audit, not a live gameplay claim.')
out = ROOT / 'artifacts/review-package-v01222-20261013'
out.mkdir(exist_ok=True)
(out / 'audit.py').write_text(text, encoding='utf-8')
print(json.dumps({'review': 'PASS_WITH_FIXED_FINDING', 'managedChecks': 2586, 'failed': 0, 'pinnedFiles': len(files), 'auditPrepared': str(out / 'audit.py')}))
