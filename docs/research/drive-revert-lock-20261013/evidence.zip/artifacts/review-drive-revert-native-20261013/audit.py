"""Read-only original-PE pin comparison and scoped implementation capture."""
import hashlib
import json
import re
import struct
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PE = Path(r"E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe")
EXPECTED = "9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed"
parser = argparse.ArgumentParser()
parser.add_argument("--check", action="store_true")
options = parser.parse_args()
FILES = [
    "src/KH2Trainer.Bridge/DriveRevertLockSupport.inl",
    "src/KH2Trainer.Bridge/DriveFeatures.inl",
    "src/KH2Trainer.Bridge/DriveWeaponSupport.inl",
    "src/KH2Trainer.Bridge/TrainerBridge.cpp",
    "src/KH2Trainer.Bridge/DevToolsProtocol.h",
    "tests/KH2Trainer.Bridge.Tests/DriveGuardTests.cpp",
    "tests/KH2Trainer.Bridge.Tests/DriveRevertBridgeTests.cpp",
    "tests/KH2Trainer.Bridge.Tests/run-tests.ps1",
]

raw = PE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
peoff = struct.unpack_from("<I", raw, 0x3C)[0]
assert raw[:2] == b"MZ" and raw[peoff:peoff + 4] == b"PE\0\0"
sections = struct.unpack_from("<H", raw, peoff + 6)[0]
optional = peoff + 24
assert struct.unpack_from("<H", raw, optional)[0] == 0x20B
base = struct.unpack_from("<Q", raw, optional + 24)[0]
table = optional + struct.unpack_from("<H", raw, peoff + 20)[0]
spans = [struct.unpack_from("<IIII", raw, table + i * 40 + 8) for i in range(sections)]

def bytes_at(rva, size):
    for virtual_size, address, raw_size, offset in spans:
        if address <= rva and rva + size <= address + raw_size:
            return raw[offset + rva - address:offset + rva - address + size]
    raise ValueError(f"Span not original-file backed: {rva:X}+{size:X}")

source = (ROOT / FILES[0]).read_text(encoding="utf-8-sig")
arrays = {name: bytes(int(x, 16) for x in re.findall(r"0x([0-9A-Fa-f]+)", data))
          for name, data in re.findall(r"constexpr BYTE (\w+)\[\]\s*=\s*\{([^}]+)\}", source)}
pins = re.findall(r"\{(0x[0-9A-Fa-f]+),(k\w+),sizeof\(\2\)\}", source)
assert len(pins) == 4
pin_results = []
for rva_text, name in pins:
    rva = int(rva_text, 16)
    pin = arrays[name]
    assert pin == bytes_at(rva, len(pin)), name
    pin_results.append({"name": name, "rva": rva_text, "size": len(pin),
                        "sha256": hashlib.sha256(pin).hexdigest(), "matchesOriginal": True})

files = []
for name in FILES:
    content = (ROOT / name).read_bytes()
    target = HERE / "sources" / name
    if options.check:
        assert target.read_bytes() == content, f"Current source changed: {name}"
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    files.append({"path": name, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()})
result = {"schema": 1, "originalSha256": EXPECTED, "originalImageBase": hex(base),
          "scope": "Exact current source capture and original-file comparison of the four lock code pins. Not a live-game test or semantic-proof substitute.",
          "pins": pin_results, "sources": files}
encoded = (json.dumps(result, indent=2) + "\n").encode("utf-8")
if options.check:
    assert (HERE / "source-and-pin-audit.json").read_bytes() == encoded
else:
    (HERE / "source-and-pin-audit.json").write_bytes(encoded)
print(json.dumps({"pins": len(pins), "pinBytes": sum(x["size"] for x in pin_results), "sources": len(files), "failures": 0}))
