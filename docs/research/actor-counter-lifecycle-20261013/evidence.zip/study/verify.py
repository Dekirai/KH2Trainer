"""Verify bounded context lifecycle evidence against the untouched original PE."""
import argparse, hashlib, json, runpy, struct
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

H = Path(__file__).resolve().parent
ROOT = H.parents[1]
B = 0x140000000
PIN = '9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
SOURCE = Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_bytes())
number = lambda value: int(value, 16) if isinstance(value, str) else value
octets = lambda s: bytes(int(x, 16) for x in s.split()) if '0x' in s else bytes.fromhex(s)

def main(check=False):
    raw = SOURCE.read_bytes()
    assert sha(raw) == PIN
    nt = struct.unpack_from('<I', raw, 0x3c)[0]
    opt = nt + 24
    assert struct.unpack_from('<Q', raw, opt + 24)[0] == B
    sections = [struct.unpack_from('<IIII', raw, opt + struct.unpack_from('<H', raw, nt + 20)[0] + 40*i + 8)
                for i in range(struct.unpack_from('<H', raw, nt + 6)[0])]
    def pe(addr, size):
        rva = addr - B
        for vs, start, rs, offset in sections:
            if start <= rva and rva + size <= start + rs:
                return raw[offset+rva-start:offset+rva-start+size]
        raise AssertionError(hex(addr))
    def emit(name, value):
        data = (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()
        if check:
            assert (H / name).read_bytes() == data, name
        else:
            (H / name).write_bytes(data)
    inventory = {number(f['address']): f['size'] for line in
                 (ROOT / 'docs/research/coverage/function_status.jsonl').read_text().splitlines()
                 if (f := json.loads(line))['domain'] == 'native'}
    cs = Cs(CS_ARCH_X86, CS_MODE_64)
    cs.detail = True
    aliases = {'retn':'ret', 'jz':'je', 'jnz':'jne', 'jnb':'jae', 'jna':'jbe', 'jnl':'jge',
               'jng':'jle', 'cmovz':'cmove', 'cmovnz':'cmovne', 'setz':'sete', 'setnz':'setne',
               'setnb':'setae', 'sal':'shl', 'cmovns':'cmovns'}
    functions, ranges, dependencies, ins = [], [], [], {}
    def validate(addr, size, data, rows, origin, fresh, is_range=False):
        assert len(data) == size and data == pe(addr, size)
        if not is_range:
            assert size == inventory[addr]
        assert number(rows[0]['addr']) == addr
        normalized, noncode = [], []
        for index, row in enumerate(rows):
            at = number(row['addr'])
            end = number(rows[index+1]['addr']) if index+1 < len(rows) else addr+size
            text = row.get('disasm', row.get('instruction'))
            mn = text.split()[0]
            original = data[at-addr:end-addr]
            if mn in ['align', 'db', 'dw', 'dd', 'dq']:
                noncode.append({'addr':hex(at), 'size':end-at, 'bytes':original.hex(), 'ida':text})
                continue
            i = next(cs.disasm(original, at, count=1))
            assert i.size == end-at, (hex(at), i.size, end-at)
            assert aliases.get(mn, mn) == i.mnemonic or (text == 'xchg ax, ax' and i.mnemonic == 'nop'), (hex(at), text, i.mnemonic)
            ins[at] = i
            normalized.append({'addr':hex(at), 'bytes':bytes(i.bytes).hex(), 'instruction':i.mnemonic+' '+i.op_str, 'ida':text})
        record = {'addr':hex(addr), 'size':size, 'complete':not is_range, 'originalBytes':data.hex(),
                  'sha256':sha(data), 'sourceMetadata':{'freshCapture':fresh, 'source':origin},
                  'instructions':normalized, 'nonInstructionSpans':noncode}
        if is_range:
            record['scope'] = 'Bounded code range only; IDA has no containing function and reports no entry xrefs. Not a complete-function claim.'
            ranges.append(record)
        else:
            functions.append(record)
    cap = H / 'root-capture'
    captures = {number(r['addr']):octets(r['data']) for name in ['bytes.json', 'reuse-bytes.json']
                for r in load(cap/name)['result']}
    for name in ['instructions.json', 'reuse-instructions.json']:
        for q in load(cap/name)['result']:
            assert q['cursor'] == {'done':True} and not q.get('truncated') and not q.get('error')
            assert q['count'] == q['scanned'] == len(q['matches']) and len(q['ranges']) == 1
            addr = number(q['ranges'][0]['start'])
            size = number(q['ranges'][0]['end']) - addr
            validate(addr, size, captures[addr], q['matches'], 'root-capture/'+name, True, addr == B+0x3E1810)
    assert {number(f['addr'])-B for f in functions} == {0x3E1790, 0x3B5F30, 0x3C6150, 0x26AE40}
    assert len(ranges) == 1 and ranges[0]['size'] == 48
    reuses = {
        'actor-reference-counter-20261013':[0x3E1240, 0x3E1410, 0x3E1C80, 0x3E1730, 0x3E1840, 0x3B44D0],
        'actor-rebind-context-20261008':[0x41B320],
        'app-timer-dispatch-20261008':[0x3E1530],
        'bdx-bank9-calls-20261008':[0x3E1970, 0x3E1910, 0x3E15A0],
        'bdx-system-calls-20261008':[0x3E1E30, 0x3E1F00],
    }
    for study, rvas in reuses.items():
        path = ROOT / 'docs/research' / study / 'evidence.json'
        evidence = load(path)
        selected = [f for f in evidence['functions'] if number(f['addr'])-B in rvas]
        assert len(selected) == len(rvas)
        dependencies.append({'path':path.relative_to(ROOT).as_posix(), 'sha256':sha(path.read_bytes()), 'functions':[hex(B+r) for r in rvas]})
        for f in selected:
            rows = f['disassembly']['asm']['lines'] if 'disassembly' in f else f['asm']
            if isinstance(rows, dict):
                rows = rows['lines']
            validate(number(f['addr']), number(f['size']), octets(f['originalBytes']), rows,
                     path.relative_to(ROOT).as_posix()+'#functions[addr='+f['addr']+']', False)
    for path in cap.glob('*-decompile.json'):
        d = load(path)
        assert d['cursor'] == {'done':True} and not d.get('truncated') and d['line_count'] == d['total_lines']
    xref_counts = {}
    for q in load(cap/'xrefs.json')['result']:
        assert not q.get('more') and q['xref_count'] == len(q['xrefs'])
        xref_counts[q['addr'].lower()] = {'code':sum(x['type']=='code' for x in q['xrefs']), 'data':sum(x['type']=='data' for x in q['xrefs'])}
    lookup = load(cap/'lookup.json')['result']
    assert lookup[1]['fn'] is None and lookup[2]['fn'] is None
    assert xref_counts['0x1403e1810'] == {'code':0, 'data':0}
    anchor_rvas = [0x3E17A8,0x3E17AD,0x3E17B6,0x3E17D2,0x3E17E3,0x3E17F4,
                   0x3E1810,0x3E1819,0x3E182B,0x3E1837,0x3E19A8,0x3E19B6,
                   0x3E19C2,0x3E19D3,0x3E19D6,0x3E1CED,0x3E1D2F,0x3E1D34,
                   0x3E1DA5,0x3E1DB7,0x3E1DDE,0x3E1471,0x3E14D9,0x3E153F,
                   0x3E1548,0x3E154E,0x3E155D,0x3E1576,0x3E15D8,0x3E15EA,
                   0x3E13EA,0x3E1759,0x3E176F,0x3B5F42,0x3B5F95,0x3C6198,
                   0x26AE70,0x26AE7D,0x26AEBC,0x41B328]
    anchors = []
    for rva in anchor_rvas:
        i = ins[B+rva]
        anchors.append({'addr':hex(i.address), 'bytes':bytes(i.bytes).hex(), 'instruction':i.mnemonic+' '+i.op_str})
    # Critical operands independently decoded from original bytes, not IDA labels.
    expected = {
        0x3E17AD:'mov dword ptr [rbx + 0x38], 0',
        0x3E17E3:'dec dword ptr [rcx + 0x5b8]',
        0x3E1810:'mov dword ptr [rcx + 0x38], 0',
        0x3E182B:'dec dword ptr [rdx + 0x5b8]',
        0x3E19A8:'mov r9, qword ptr [rbx + 0x60]',
        0x3E19B6:'call 0x1403e1240',
        0x3E1D2F:'call 0x1403e1c80',
        0x3E1DDE:'cmp qword ptr [rsi + 0x48], 0',
        0x3E1471:'call 0x1403e1530',
        0x3E153F:'call 0x1403e1410',
        0x3B5F42:'call 0x1403e1730',
        0x3C6198:'jmp 0x1403e1790',
        0x26AEBC:'jmp 0x1403e1790',
        0x41B328:'mov dword ptr [rcx + 8], edx',
    }
    for rva, text in expected.items():
        i = ins[B+rva]
        assert i.mnemonic+' '+i.op_str == text, (hex(B+rva), text, i.mnemonic+' '+i.op_str)
    groups = {}
    for fresh, name in [(True,'fresh'), (False,'reused')]:
        fs = [f for f in functions if f['sourceMetadata']['freshCapture'] == fresh]
        groups[name] = {'functions':len(fs), 'instructions':sum(len(f['instructions']) for f in fs), 'bodyBytes':sum(f['size'] for f in fs)}
    groups['boundedRanges'] = {'ranges':len(ranges), 'instructions':sum(len(f['instructions']) for f in ranges),
                               'bytes':sum(f['size'] for f in ranges), 'noninstructionBytes':sum(s['size'] for f in ranges for s in f['nonInstructionSpans'])}
    emit('evidence.json', {'schema':1, 'originalSha256':PIN, 'functions':functions, 'codeRanges':ranges,
                         'dependencies':dependencies, 'anchors':anchors})
    report = load(H/'report.json') if (H/'report.json').exists() else {}
    claims = report.get('claims', [])
    range_claims = report.get('rangeFindings', [])
    refs = 0
    parser = runpy.run_path(str(ROOT/'scripts/update-analysis-coverage.py'), run_name='actor_lifecycle_reference_check')
    for claim in claims + range_claims:
        assert {'addr','Finding','Evidence','Limitations'} <= claim.keys()
        for ref in claim['Evidence']:
            assert parser['resolve_reference'](H/'report.json', ref).get('status') == 'exists', ref
            refs += 1
    emit('verification.json', {'status':'PASS', 'originalSha256':PIN, 'counts':groups, 'anchors':len(anchors),
                              'exactOperandAnchors':len(expected), 'claims':len(claims), 'rangeFindings':len(range_claims),
                              'resolvedEvidenceReferences':refs, 'xrefCounts':xref_counts,
                              'nativeExecution':False, 'modelCases':0,
                              'scope':'Selected context writers and lifecycle paths, not all callers, no reachable bug or lifetime guarantee. The orphan code range is excluded from complete-function counts.',
                              'readiness':'Root captures used; global autoanalysis completion not independently observed.'})
    if check and (H/'manifest.json').exists():
        rows = load(H/'manifest.json')['files']
        actual = {p.relative_to(H).as_posix() for p in H.rglob('*') if p.is_file() and p.name != 'manifest.json'}
        assert actual == {r['path'] for r in rows}
        for r in rows:
            data = (H/r['path']).read_bytes()
            assert len(data) == r['bytes'] and sha(data) == r['sha256'], r['path']
    print(json.dumps({'status':'PASS', 'counts':groups, 'anchors':len(anchors), 'claims':len(claims), 'rangeFindings':len(range_claims), 'references':refs}))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    main(parser.parse_args().check)
