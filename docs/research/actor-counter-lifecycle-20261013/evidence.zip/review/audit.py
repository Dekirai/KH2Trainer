"""Independent byte/operand audit of the bounded context lifecycle study."""
import hashlib,json,struct,subprocess,sys
from pathlib import Path
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
H=Path(__file__).resolve().parent;ROOT=H.parents[1];S=ROOT/'artifacts/actor-counter-lifecycle-20261013';B=0x140000000
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
original=Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe').read_bytes()
assert sha(original)=='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
nt=struct.unpack_from('<I',original,0x3c)[0];opt=nt+24
sections=[struct.unpack_from('<IIII',original,opt+struct.unpack_from('<H',original,nt+20)[0]+40*i+8) for i in range(struct.unpack_from('<H',original,nt+6)[0])]
def pe(at,size):
    for vs,start,rs,offset in sections:
        if start<=at-B and at-B+size<=start+rs:return original[offset+at-B-start:offset+at-B-start+size]
    raise AssertionError(hex(at))
e=load(S/'evidence.json');cs=Cs(CS_ARCH_X86,CS_MODE_64);ins={};counts=[]
for key in ['functions','codeRanges']:
    size=code=heads=padding=0
    for f in e[key]:
        at=int(f['addr'],16);data=bytes.fromhex(f['originalBytes']);assert data==pe(at,f['size']) and len(data)==f['size']
        assert sha(data)==f['sha256'];size+=len(data)
        assert f['complete']==(key=='functions')
        intervals=[]
        for row in f['instructions']:
            address=int(row['addr'],16);raw=bytes.fromhex(row['bytes']);assert raw==pe(address,len(raw))
            i=next(cs.disasm(raw,address,count=1));assert i.size==len(raw)
            text=i.mnemonic+' '+i.op_str;assert text==row['instruction']
            ins[address-B]=text;heads+=1;code+=len(raw);intervals.append((address,address+len(raw)))
        for gap in f['nonInstructionSpans']:
            address=int(gap['addr'],16);raw=bytes.fromhex(gap['bytes']);assert len(raw)==gap['size'] and raw==pe(address,len(raw))
            padding+=len(raw);intervals.append((address,address+len(raw)))
        intervals.sort();assert intervals[0][0]==at and intervals[-1][1]==at+f['size']
        assert all(a[1]==b[0] for a,b in zip(intervals,intervals[1:]))
    counts.append({'category':key,'records':len(e[key]),'bytes':size,'instructions':heads,'codeBytes':code,'paddingBytes':padding})
expected={0x3E17A8:'call 0x14041c690',0x3E17AD:'mov dword ptr [rbx + 0x38], 0',0x3E17B6:'jle 0x1403e17d7',0x3E17D2:'jmp 0x14041b320',0x3E17E3:'dec dword ptr [rcx + 0x5b8]',
          0x3B5F3C:'mov rdx, rcx',0x3B5F42:'call 0x1403e1730',0x3B5F7F:'call 0x1403e1840',0x3B5F84:'mov rcx, qword ptr [rbx + 0x5b0]',0x3B5F95:'call 0x1403e1790',
          0x3C618F:'lea edx, [r9 + 0x15]',0x3C6198:'jmp 0x1403e1790',0x3E1810:'mov dword ptr [rcx + 0x38], 0',0x3E1819:'jg 0x14041b320',0x3E182B:'dec dword ptr [rdx + 0x5b8]',
          0x3E19A8:'mov r9, qword ptr [rbx + 0x60]',0x3E19B6:'call 0x1403e1240',0x3E1E6F:'mov r9, qword ptr [rdi + 0x60]',0x3E1E7D:'call 0x1403e1240',
          0x3E1C95:'jne 0x1403e1cfc',0x3E1CFC:'mov rbx, qword ptr [rsi + 0x48]',0x3E1D2F:'call 0x1403e1c80',0x3E1D34:'cmp eax, 1',0x3E1DDA:'test al, 1',0x3E1DDE:'cmp qword ptr [rsi + 0x48], 0',
          0x3E1F49:'and ecx, r15d',0x3E1F4C:'cmp ecx, r14d',0x3E1FB9:'call 0x1403e1410',0x3E153F:'call 0x1403e1410',0x3E1548:'je 0x1403e157b',0x3E154E:'jne 0x1403e156e',
          0x26AE70:'call 0x1403e1910',0x26AE78:'xor edx, edx',0x26AE7D:'call 0x1403e1730',0x26AEBC:'jmp 0x1403e1790'}
for addr,text in expected.items():assert ins[addr]==text,(hex(addr),ins[addr],text)
for d in e['dependencies']:assert sha((ROOT/d['path']).read_bytes())==d['sha256']
p=subprocess.run([sys.executable,'-B',str(S/'verify.py'),'--check'],capture_output=True,text=True)
assert p.returncode==0,p.stdout+p.stderr
(H/'author-verifier.log').write_text(p.stdout+p.stderr,encoding='utf-8')
sourcefiles=[{'path':p.relative_to(S).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(S.rglob('*')) if p.is_file()]
report={'status':'PASS','sourceStudy':S.relative_to(ROOT).as_posix(),'originalSha256':sha(original),'counts':counts,'exactOperandChecks':len(expected),'semanticReview':{'functionClaims':9,'rangeFindings':1,'openFindings':[],
 'acceptedBoundaries':['Reset at3E1790 is local and does not prove reachable repeated release.','Event0 may mutate context state;3B5F30 reloads pointer before event1.','3C6150 existing pointer does not prove prior release.','Parent release and child drain are separate; script/allocator callbacks remain open.','3E1810 range has no IDA function/xrefs and is excluded from full-function count.','No all-writer, all-caller, runtime crash, whole-cleanup idempotence or exact raw-counter interpretation.']},
 'sourceFiles':sourcefiles,'nativeExecution':False,'semanticEmulator':False}
(H/'review.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','counts':counts,'exactOperandChecks':len(expected),'claims':9,'ranges':1,'openFindings':0}))
