# Independent review: Actor context lifecycle

Accepted: all nine function claims and the separate bounded-range finding. No open semantic issue was found.

The review read all 17 complete bodies and the orphan range, checked their original PE bytes independently, decoded every recorded instruction again, and asserted 35 critical operands. Full bodies cover 832 instructions / 3,059 bytes. The separate 48-byte range contains 12 instructions / 43 code bytes plus 5 alignment bytes. It remains excluded from complete-function counts.

The critical limits are preserved:

- `3E1790` clears the release state after event lookup, but no reachable repeated-release sequence is demonstrated.
- `3B5F30` executes event0 and reloads the Actor's context pointer before event1; no unchanged-new-context guarantee is made.
- `3C6150` starts an existing pointer, with its prior release state still unknown.
- Each constructed child can hold its own reference. A parent's own release flag and completion of the child list are separate conditions.
- The alternate destructor branch is described as a call to `031DD0`, without assuming freeing behavior. Its true empty body is independently established by the separate cleanup study, not required by this report.
- Callback effects, allocation failures, all callers, all writers, actual gameplay errors and whole-cleanup idempotence remain outside the proof.

`audit.py` is an original-byte and instruction audit, not a semantic emulator. `review.json` pins the reviewed source files; the author verifier was also run in read-only `--check` mode. No product, docs, coverage, packages or game state were changed.
