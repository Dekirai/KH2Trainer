"""Independent original-PE/raw-capture review. Never execute the game."""
from pathlib import Path
import hashlib
import json
import struct
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

H = Path(__file__).resolve().parent
ROOT = H.parents[1]
STUDY = ROOT / 'artifacts/actor-destruction-boundary-20261013'
EXE = Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_bytes())
def pin(p):
    data=p.read_bytes()
    return {'path':p.relative_to(ROOT).as_posix(),'bytes':len(data),'sha256':sha(data)}
manifest_pin=pin(STUDY/'manifest.json')
assert manifest_pin['sha256']=='67920efebc3f7d268de6d18b2aa8816693b8d2e60753016a2c165acf4166ab40'
manifest=load(STUDY/'manifest.json')['files']
actual={p.relative_to(STUDY).as_posix() for p in STUDY.rglob('*') if p.is_file() and p.name!='manifest.json'}
assert actual=={r['path'] for r in manifest} and len(actual)==33
for row in manifest:
    data=(STUDY/row['path']).read_bytes()
    assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']

raw=EXE.read_bytes()
assert sha(raw)=='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
nt=struct.unpack_from('<I',raw,0x3c)[0]
assert raw[nt:nt+4]==b'PE\0\0'
count=struct.unpack_from('<H',raw,nt+6)[0]
optional_size=struct.unpack_from('<H',raw,nt+20)[0]
base=struct.unpack_from('<Q',raw,nt+48)[0]
assert base==0x140000000
sections=[struct.unpack_from('<IIII',raw,nt+24+optional_size+i*40+8) for i in range(count)]
def pe(address,size):
    rva=address-base
    for virtual_size,start,raw_size,offset in sections:
        if start<=rva and rva-start+size<=raw_size:
            return raw[offset+rva-start:offset+rva-start+size]
    raise AssertionError(hex(address))
def octets(s): return bytes(int(x,16) for x in s.split())
md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
fresh={}
for prefix in ['', 'followup-', 'callback-']:
    buffers={int(r['addr'],16):octets(r['data']) for r in load(STUDY/'root-capture'/f'{prefix}bytes.json')['result']}
    lookup={int(r['fn']['addr'],16):int(r['fn']['size'],16) for r in load(STUDY/'root-capture'/f'{prefix}lookup.json')['result']}
    for capture in load(STUDY/'root-capture'/f'{prefix}instructions.json')['result']:
        assert capture['cursor']=={'done':True} and not capture.get('truncated') and not capture.get('error')
        assert len(capture['ranges'])==1 and capture['count']==capture['scanned']==len(capture['matches'])
        a=int(capture['ranges'][0]['start'],16);end=int(capture['ranges'][0]['end'],16)
        body=buffers[a]
        assert a not in fresh and end-a==len(body)==lookup[a]
        assert body==pe(a,len(body)),hex(a)
        decoded=list(md.disasm(body,a))
        assert sum(i.size for i in decoded)==len(body)
        assert [i.address for i in decoded]==[int(r['addr'],16) for r in capture['matches']]
        fresh[a]={'body':body,'decoded':decoded,'origin':f'root-capture/{prefix}instructions.json'}
assert len(fresh)==15

evidence=load(STUDY/'evidence.json')
dependency_path=ROOT/'docs/research/actor-contact-retirement-20261013/evidence.json'
dependency={int(f['addr'],16):f for f in load(dependency_path)['functions']}
functions={};decoded_rows=[]
for f in evidence['functions']:
    a=int(f['addr'],16);body=bytes.fromhex(f['originalBytes'])
    assert f['complete'] and a not in functions and len(body)==f['size'] and sha(body)==f['sha256']
    assert body==pe(a,len(body)),f['addr']
    decoded=list(md.disasm(body,a))
    assert sum(i.size for i in decoded)==len(body)
    assert len(decoded)==f['disassembly']['instruction_count']==f['disassembly']['total_instructions']
    assert [i.address for i in decoded]==[int(r['addr'],16) for r in f['disassembly']['asm']['lines']]
    if f['captureKind']=='fresh': assert a in fresh and body==fresh[a]['body']
    else:
        assert f['captureKind']=='reused' and a in dependency
        prior=dependency[a]
        assert prior['complete'] and body==bytes.fromhex(prior['originalBytes']) and len(body)==prior['size']
    functions[a]=decoded
    decoded_rows.append({'address':hex(a),'kind':f['captureKind'],'size':len(body),'sha256':sha(body),
                         'instructions':[{'address':hex(i.address),'bytes':bytes(i.bytes).hex(),'text':i.mnemonic+' '+i.op_str} for i in decoded]})
assert len(functions)==29 and len(fresh)==sum(f['captureKind']=='fresh' for f in evidence['functions'])
tables=[]
for row in load(STUDY/'root-capture/table-bytes.json')['result']:
    a=int(row['addr'],16);data=octets(row['data'])
    assert data==pe(a,len(data))
    tables.append({'address':hex(a),'bytes':len(data),'sha256':sha(data),'qwords':list(struct.unpack('<'+'Q'*(len(data)//8),data))})
assert sum(t['bytes'] for t in tables)==136
byaddr={t['address']:t for t in tables}
assert byaddr['0x14074c380']['qwords']==[0x1405c6250]
vtable=byaddr['0x1405c6250']['qwords']
assert {i:vtable[i] for i in [0,6,8,9,14]}=={0:0x1403d2720,6:0x1403d2840,8:0x1403d28b0,9:0x1403d28c0,14:0x1403d2920}

instructions={i.address:i for rows in functions.values() for i in rows}
checks=[]
def exact(rva,mnemonic,operands):
    i=instructions[base+rva]
    assert i.mnemonic==mnemonic and i.op_str==operands,(hex(i.address),i.mnemonic,i.op_str)
    checks.append({'address':hex(i.address),'instruction':mnemonic+' '+operands,'bytes':bytes(i.bytes).hex()})
# Direct retirement: preserve signed threshold from incoming ECX; eleven cleanup
# calls precede the loop, and the signed JL skips the direct slot72 branch.
exact(0x3bf8fa,'mov','edi, ecx')
exact(0x3bf92b,'call','0x1403cfed0')
pre=[i for i in functions[base+0x3bf8f0] if i.address<base+0x3bf935 and i.mnemonic=='call']
assert len(pre)==11
exact(0x3bf956,'mov','eax, dword ptr [rbx + 0x120]')
exact(0x3bf95c,'shr','eax, 0x13')
exact(0x3bf961,'jne','0x1403bf935')
exact(0x3bf973,'call','qword ptr [r8 + 0x70]')
exact(0x3bf977,'cmp','eax, edi')
exact(0x3bf979,'jl','0x1403bf991')
exact(0x3bf98b,'call','qword ptr [r8 + 0x48]')
assert not any(i.mnemonic=='call' and '[r8 + 0x40]' in i.op_str for i in functions[base+0x3bf8f0])
exact(0x3ac2f4,'mov','ecx, 0x7d0');exact(0x3ac2f9,'call','0x1403bf8f0')
exact(0x3ad133,'mov','ecx, 0x7d0');exact(0x3ad138,'call','0x1403bf8f0')
exact(0x3ad165,'mov','dword ptr [rbx + 0x3c], 2');exact(0x3ad16c,'mov','qword ptr [rbx + 0x40], 3')
# Descriptor callback precedes the actual descriptor destructor dispatch;
# completion flag is AFTER return, so it is not a pre-reentry guard.
exact(0x3bf336,'call','0x1403b4e80');exact(0x3bf34b,'call','qword ptr [r8]')
exact(0x3b4e94,'jne','0x1403b4eb1')
exact(0x3b4ea6,'call','qword ptr [r8 + 0x30]')
exact(0x3b4eaa,'or','dword ptr [rbx + 0x9b8], 0x40')
exact(0x3d2840,'mov','rcx, rdx');exact(0x3d2843,'jmp','0x1403dabe0')
exact(0x3dabf4,'call','0x1403c7300');exact(0x3dac28,'jmp','0x1403b43c0')
exact(0x3b43d4,'call','0x1403e61e0');exact(0x3b43e8,'call','0x140152590')
exact(0x3b43ed,'mov','r8, qword ptr [rdi + 0x7b0]')
exact(0x3b43f4,'mov','rdx, rax');exact(0x3b43fe,'call','qword ptr [rbx + 0x48]')
exact(0x3b4401,'mov','qword ptr [rdi + 0xa88], 0')
exact(0x3d2781,'call','0x1403b3d60');exact(0x3d2789,'call','0x140152570')
for rva in [0x3bf8f0,0x3b3d60,0x3d2720,0x3b4e80]:
    assert not any(op.type==3 and op.mem.disp==1464 for i in functions[base+rva] for op in i.operands)
# Scheduler dispatch is direct under retained task+112==0. Mask/value0/0
# makes selection independent of task flags, but says nothing about all callers.
exact(0x3bf554,'call','0x1403f6540');exact(0x3bf564,'jmp','0x14014fc20')
exact(0x14fc20,'xor','r8d, r8d');exact(0x14fc23,'xor','edx, edx');exact(0x14fc25,'jmp','0x14014fd60')
exact(0x14fd9b,'and','eax, ebp');exact(0x14fd9d,'cmp','eax, esi')
exact(0x14fdf3,'cmp','qword ptr [rbx + 0x70], r15')
exact(0x14fdf7,'jne','0x14014fe00');exact(0x14fdfc,'call','qword ptr [rbx]')
exact(0x14f7ba,'mov','qword ptr [rax + 0x70], r9')
exact(0x14f79d,'xor','r9d, r9d');exact(0x3bf866,'call','0x14014f770')
def rip_target(rva):
    i=instructions[base+rva]
    mem=next(op.mem for op in i.operands if op.type==3)
    assert i.reg_name(mem.base)=='rip'
    return i.address+i.size+mem.disp
assert rip_target(0x3bf559)==base+0x2a17180
assert rip_target(0x3bf851)==base+0x2a17180
assert rip_target(0x3bf858)==base+0x3bf5e0
assert rip_target(0x3bf816)==base+0x3bf550
assert rip_target(0x3bf605)==base+0x2a171c8
assert rip_target(0x3bf629)==base+0x2a17248
assert rip_target(0x3bf773)==base+0x2a17248
assert rip_target(0x14ecd2)==base+0x9ba888
exact(0x14ecd9,'call','0x14014fc20')
exact(0x3d2920,'mov','rcx, rdx');exact(0x3d2923,'jmp','0x1403b44a0')
exact(0x3b44a4,'mov','ecx, dword ptr [rcx + 8]');exact(0x3b44ac,'xor','edx, edx')
exact(0x3b44b1,'call','0x1403e0b50');exact(0x3b44bd,'jmp','0x14039db20')
exact(0x3baa80,'test','dword ptr [rcx + 0x120], 0x10080000')

report=load(STUDY/'report.json')
assert len(report['claims'])==15 and report['completeSemanticAnalysis'] is False and report['liveGame'] is False
assert all(int(c['addr'],16) in functions for c in report['claims'])
assert not any(int(f['addr'],16)==base+0x3ac750 for f in evidence['functions'])
assert pin(STUDY/'manifest.json')==manifest_pin
receipt={'status':'ACCEPTED','findings':[],'authorManifest':manifest_pin,
         'authorReport':pin(STUDY/'report.json'),'authorReportMarkdown':pin(STUDY/'report.md'),
         'authorEvidence':pin(STUDY/'evidence.json'),'sourceDependency':pin(dependency_path),
         'originalSha256':sha(raw),'manifestMembers':len(manifest),'claims':len(report['claims']),
         'functions':len(functions),'instructions':sum(len(v) for v in functions.values()),
         'bodyBytes':sum(f['size'] for f in evidence['functions']),'dataBytes':sum(t['bytes'] for t in tables),
         'freshFunctions':len(fresh),'reusedFunctions':len(functions)-len(fresh),
         'semanticAnchors':checks,'descriptorTables':tables,
         'scope':'Independent read-only raw completeness, original PE bytes, decoded full-body control flow and manual claim review; no product or native execution.',
         'limits':['Signed threshold direct-slot72 path is not proof of a live defect: contact cleanup and other helpers precede it.',
                   'Synchronous Actor task dispatch is conditional on unchanged task/link/manager; not universal thread or termination proof.',
                   'No-counter claims are local to decoded bodies; helpers and dynamic allocators remain outside closure.',
                   'No production Motion admission, all-free/all-writer closure or current gameplay result is approved.']}
(H/'decoded.json').write_text(json.dumps(decoded_rows,indent=2)+'\n',encoding='utf-8')
(H/'review.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['status','findings','manifestMembers','claims','functions','instructions','bodyBytes','dataBytes']}))
