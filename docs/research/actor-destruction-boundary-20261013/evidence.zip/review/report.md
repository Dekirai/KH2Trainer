# Independent review: Actor destruction boundary

Status: **ACCEPTED**, no findings. Reviewed the frozen author study against the
original executable and complete raw captures, including all 15 claims.

## Evidence checks

- All 33 author manifest members match the frozen manifest.
- All 29 bodies match their original PE bytes: 1199 decoded instructions,
  4759 body bytes. The 15 fresh captures are complete; the 14 reused bodies match
  their explicit dependency. The 136 descriptor/data bytes also match the PE.
- Independent Capstone decoding checks full coverage, instruction boundaries and
  selected operands/control-flow anchors. The review inspected complete relevant
  bodies rather than relying only on the author's verifier.
- The author's `verify.py --check` also passed. This is additional evidence,
  separate from the independent checks.

## Conclusions checked

1. `3BF8F0` retains the signed 32-bit threshold and uses signed `JL` at `3BF979`.
   It can call descriptor slot72 directly for results at least the threshold,
   without the normal local slot64 admission call. Its eleven earlier helper
   calls include contact cleanup `3CFED0`. The report correctly avoids treating
   the absent local counter test as proof of a live game defect.
2. `3BF550` dispatches through `14FC20` with the Actor manager from `2A17180`.
   Mask/value zero select linked tasks. The constructor clears task+112 at
   `14F7BA`, and `14FD60` directly invokes the callback when that field remains
   null. The claimed order through `3BF5E0` is conditional on the same unchanged
   task, link and manager. It is not a global thread or termination guarantee.
3. `3BF300` invokes `3B4E80` before descriptor slot0. `3B4E80` calls slot48 before
   setting bit `0x40` in Actor+2488, so the text correctly rejects a general
   reentry guarantee. The actual descriptor maps slot48 through `3D2840` to
   `3DABE0`; `3B43C0` subsequently passes the return value of `152590` and
   Actor+1968 to the resource callback before clearing Actor+2696.
4. `3D2720` and `3B3D60` contain the documented cleanup calls and no local
   Actor+1464 operand. This does not close transitive helper behavior or the
   dynamic allocator. The report preserves those limits.
5. The threshold result's full meaning remains open. `3AC750` is explicitly
   excluded from complete body evidence. The main manager from `9BA888` is
   kept distinct from the Actor manager from `2A17180`.

These results do not approve production Motion admission, retained Actor
pointers, all-free/all-writer closure, or any current gameplay behavior.
No product edits, builds, native game calls, GUI or Twitch actions were performed.

## Reproduction and pins

```powershell
py -3 -B artifacts/review-actor-destruction-boundary-20261013/audit.py
```

- Author manifest: `67920efebc3f7d268de6d18b2aa8816693b8d2e60753016a2c165acf4166ab40`
- Author report JSON: `5cc8bf4eecaae60129d7d26b140f7b698d5c094281c54085aa2c8f56c72c8bc3`
- Author report Markdown: `780157a4982681b437b2501da8cac9da508d1e226bb459cc216421fa4d93e43e`
- Author evidence: `0e5295610da2d12017aaa30488dbcd58d6eb7e88c4e2a534b93e0c9c7521dda9`
- Original executable: `9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed`

`review.json` contains the exact selected semantic anchors and data-table checks.
`decoded.json` contains the independent full instruction decoding. This folder's
`manifest.json` pins the review outputs and verifier.
