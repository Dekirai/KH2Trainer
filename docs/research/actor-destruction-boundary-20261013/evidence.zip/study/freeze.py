from pathlib import Path
import hashlib,json
here=Path(__file__).resolve().parent
report=json.loads((here/'report.json').read_bytes())
report['status']='AUTHOR_COMPLETE'
(here/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
files=[]
for path in sorted(here.rglob('*')):
    if path.is_file() and path.name!='manifest.json':
        data=path.read_bytes()
        files.append({'path':path.relative_to(here).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(here/'manifest.json').write_text(json.dumps({'schema':1,'selfExcluded':True,'files':files},indent=2)+'\n')
print(json.dumps({'files':len(files),'manifestSha256':hashlib.sha256((here/'manifest.json').read_bytes()).hexdigest()}))
