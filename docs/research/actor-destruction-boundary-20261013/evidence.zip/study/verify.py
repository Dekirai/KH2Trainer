"""Verify selected original bodies and descriptor cells; never execute game code."""
from pathlib import Path
import argparse, hashlib, json, struct
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = 0x140000000
SOURCE = Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
PIN = '9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_bytes())
number = lambda v: int(v, 16) if isinstance(v, str) else v
octets = lambda s: bytes(int(x,16) for x in s.split()) if '0x' in s else bytes.fromhex(s)

def main(check=False):
    raw = SOURCE.read_bytes()
    assert sha(raw) == PIN
    nt = struct.unpack_from('<I', raw, 0x3c)[0]
    opt = nt + 24
    assert struct.unpack_from('<Q', raw, opt + 24)[0] == BASE
    sections = [struct.unpack_from('<IIII', raw, opt + struct.unpack_from('<H',raw,nt+20)[0] + 40*i + 8)
        for i in range(struct.unpack_from('<H',raw,nt+6)[0])]
    def pe(addr,size):
        rva=addr-BASE
        for vs,start,rs,offset in sections:
            if start <= rva and rva+size <= start+rs:
                return raw[offset+rva-start:offset+rva-start+size]
        raise AssertionError(hex(addr))
    def emit(name, value):
        data=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
        if check:
            assert (HERE/name).read_bytes() == data, name
        else:
            (HERE/name).write_bytes(data)
    inventory={number(f['address']):f['size'] for line in (ROOT/'docs/research/coverage/function_status.jsonl').read_text().splitlines()
        if (f:=json.loads(line))['domain']=='native'}
    decoder=Cs(CS_ARCH_X86,CS_MODE_64)
    decoder.detail=True
    aliases={'retn':'ret','jz':'je','jnz':'jne','jnb':'jae','jna':'jbe','jnl':'jge','jng':'jle',
        'cmovz':'cmove','cmovnz':'cmovne','setz':'sete','setnz':'setne','setnb':'setae','sal':'shl'}
    functions=[]
    all_ins={}
    def validate(addr,size,data,rows,origin,fresh,name):
        assert data == pe(addr,size) and len(data) == size == inventory[addr]
        assert number(rows[0]['addr']) == addr
        normalized=[]
        for index,row in enumerate(rows):
            at=number(row['addr'])
            end=number(rows[index+1]['addr']) if index+1<len(rows) else addr+size
            text=row.get('disasm',row.get('instruction'))
            instruction=next(decoder.disasm(data[at-addr:end-addr],at,count=1))
            assert instruction.size == end-at, (hex(at),text)
            mnemonic=text.split()[0]
            assert aliases.get(mnemonic,mnemonic) == instruction.mnemonic or (text=='xchg ax, ax' and instruction.mnemonic=='nop'), (hex(at),text,instruction.mnemonic)
            all_ins[at]=instruction
            normalized.append({'addr':hex(at),'instruction':text,'decoded':instruction.mnemonic+' '+instruction.op_str,
                'bytes':bytes(instruction.bytes).hex()})
        page={'addr':hex(addr),'asm':{'name':name,'start_ea':hex(addr),'segment':'.text','lines':normalized},
            'instruction_count':len(rows),'total_instructions':len(rows),'cursor':{'done':True}}
        functions.append({'addr':hex(addr),'name':name,'size':size,'complete':True,'originalBytes':data.hex(' '),
            'sha256':sha(data),'captureKind':'fresh' if fresh else 'reused','origin':origin,'pages':[page],'disassembly':page})
    for prefix in ['', 'followup-', 'callback-']:
        captures={number(r['addr']):octets(r['data']) for r in load(HERE/'root-capture'/f'{prefix}bytes.json')['result']}
        for q in load(HERE/'root-capture'/f'{prefix}instructions.json')['result']:
            assert q['cursor']=={'done':True} and not q.get('truncated') and not q.get('error')
            assert q['count']==q['scanned']==len(q['matches']) and len(q['ranges'])==1
            addr=number(q['ranges'][0]['start']);size=number(q['ranges'][0]['end'])-addr
            validate(addr,size,captures[addr],q['matches'],'root-capture/'+prefix+'instructions.json',True,q['matches'][0]['fn']['name'])
    assert len(functions)==15 and len({f['addr'] for f in functions})==15
    reused=[0x3BF810,0x14F770,0x14FD60,0x3BF300,0x3D2720,0x3BFD30,0x3D28B0,0x3D28C0,0x3D2DA0,0x3B45C0,0x3B4420,0x3BF4C0,0x3DAC30,0x3CFED0]
    dependency=ROOT/'docs/research/actor-contact-retirement-20261013/evidence.json'
    originals={number(f['addr']):f for f in load(dependency)['functions']}
    for rva in reused:
        f=originals[BASE+rva]
        validate(BASE+rva,number(f['size']),octets(f['originalBytes']),f['disassembly']['asm']['lines'],
            dependency.relative_to(ROOT).as_posix(),False,f['name'])
    tables=[]
    for row in load(HERE/'root-capture/table-bytes.json')['result']:
        addr=number(row['addr']);data=octets(row['data'])
        assert data==pe(addr,len(data))
        tables.append({'addr':hex(addr),'size':len(data),'bytes':data.hex(' '),'sha256':sha(data),
            'qwords':[hex(v[0]) for v in struct.iter_unpack('<Q',data)]})
    assert tables[0]['qwords'][0]=='0x1403d2720'
    assert tables[0]['qwords'][6]=='0x1403d2840'
    assert tables[0]['qwords'][8]=='0x1403d28b0'
    assert tables[0]['qwords'][9]=='0x1403d28c0'
    assert tables[0]['qwords'][14]=='0x1403d2920'
    assert tables[1]['qwords']==['0x1405c6250']
    anchor_rvas=[0x3BF564,0x14FC25,0x3BF641,0x3BF6BF,0x3BF762,0x3BF773,
        0x3BF961,0x3BF973,0x3BF98B,0x3BF92B,0x3AC2F9,0x3AD138,
        0x3B4E94,0x3B4EA6,0x3B4EAA,0x3D2843,0x3DAC1E,
        0x3B43FE,0x3B4401,0x3D2781,0x3D2789,0x14ECD9]
    anchors=[]
    for rva in anchor_rvas:
        i=all_ins[BASE+rva]
        anchors.append({'addr':hex(i.address),'bytes':bytes(i.bytes).hex(),'instruction':i.mnemonic+' '+i.op_str})
    groups={}
    for kind in ['fresh','reused']:
        fs=[f for f in functions if f['captureKind']==kind]
        groups[kind]={'functions':len(fs),'instructions':sum(f['disassembly']['instruction_count'] for f in fs),'bodyBytes':sum(f['size'] for f in fs)}
    for path in (HERE/'root-capture').glob('*-decompile.json'):
        d=load(path);assert d['cursor']=={'done':True} and not d.get('truncated') and d['line_count']==d['total_lines']
    for q in load(HERE/'root-capture/xrefs.json')['result']:
        assert not q['more'] and q['xref_count']==len(q['xrefs'])
    emit('evidence.json',{'schema':1,'originalSha256':PIN,'functions':functions,'tables':tables,'anchors':anchors,
        'dependencies':[{'path':dependency.relative_to(ROOT).as_posix(),'sha256':sha(dependency.read_bytes())}]})
    emit('verification.json',{'status':'PASS','counts':groups,'dataBytes':sum(x['size'] for x in tables),
        'anchors':len(anchors),'nativeExecution':False,'scope':'Selected original bodies and descriptor cells; no global thread, all-writer, all-free or native allocation lifetime proof.'})
    if check and (HERE/'manifest.json').exists():
        members=load(HERE/'manifest.json')['files']
        actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and p.name!='manifest.json'}
        assert actual=={r['path'] for r in members}
        for row in members:
            data=(HERE/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
    print(json.dumps({'status':'PASS','counts':groups,'dataBytes':sum(x['size'] for x in tables),'anchors':len(anchors)}))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--check',action='store_true')
    main(parser.parse_args().check)
