"""Bounded full-body original verification of additional Actor counter writers."""
import argparse,hashlib,json,runpy,struct
from pathlib import Path
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
H=Path(__file__).resolve().parent;ROOT=H.parents[1];B=0x140000000
PIN='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
SOURCE=Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
sha=lambda data:hashlib.sha256(data).hexdigest()
load=lambda path:json.loads(path.read_bytes())
number=lambda v:int(v,16) if isinstance(v,str) else v
def octets(s):return bytes(int(x,16) for x in s.split()) if '0x' in s else bytes.fromhex(s)
def main(check=False):
 raw=SOURCE.read_bytes();assert sha(raw)==PIN
 nt=struct.unpack_from('<I',raw,0x3c)[0];opt=nt+24;assert struct.unpack_from('<Q',raw,opt+24)[0]==B
 sections=[struct.unpack_from('<IIII',raw,opt+struct.unpack_from('<H',raw,nt+20)[0]+40*i+8) for i in range(struct.unpack_from('<H',raw,nt+6)[0])]
 def pe(addr,size):
  rva=addr-B
  for vs,start,rs,offset in sections:
   if start<=rva and rva+size<=start+rs:return raw[offset+rva-start:offset+rva-start+size]
  raise AssertionError(hex(addr))
 def emit(name,value):
  data=(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
  if check:assert (H/name).read_bytes()==data,name
  else:(H/name).write_bytes(data)
 inventory={number(f['address']):f['size'] for line in (ROOT/'docs/research/coverage/function_status.jsonl').read_text().splitlines() if (f:=json.loads(line))['domain']=='native'}
 cs=Cs(CS_ARCH_X86,CS_MODE_64);cs.detail=True
 aliases={'retn':'ret','jz':'je','jnz':'jne','jnb':'jae','jna':'jbe','jnl':'jge','jng':'jle','cmovz':'cmove','cmovnz':'cmovne','setz':'sete','setnz':'setne','setnb':'setae','sal':'shl'}
 functions=[];dependencies=[];ins={}
 def validate(addr,size,data,rows,origin,fresh):
  assert data==pe(addr,size) and len(data)==inventory[addr]==size
  assert number(rows[0]['addr'])==addr
  normalized=[];noncode=[]
  for index,row in enumerate(rows):
   at=number(row['addr']);end=number(rows[index+1]['addr']) if index+1<len(rows) else addr+size
   text=row.get('disasm',row.get('instruction'));mn=text.split()[0];original=data[at-addr:end-addr]
   if mn in ['align','db','dw','dd','dq']:
    noncode.append({'addr':hex(at),'size':end-at,'bytes':original.hex(),'ida':text});continue
   i=next(cs.disasm(original,at,count=1));assert i.size==end-at
   assert aliases.get(mn,mn)==i.mnemonic or (text=='xchg ax, ax' and i.mnemonic=='nop'),(hex(at),text,i.mnemonic)
   ins[at]=i;normalized.append({'addr':hex(at),'bytes':bytes(i.bytes).hex(),'instruction':i.mnemonic+' '+i.op_str,'ida':text})
  functions.append({'addr':hex(addr),'size':size,'complete':True,'originalBytes':data.hex(),'sha256':sha(data),'sourceMetadata':{'freshCapture':fresh,'source':origin},'instructions':normalized,'nonInstructionSpans':noncode})
 captures={number(r['addr']):octets(r['data']) for r in load(H/'bytes.json')['result']}
 for path in sorted(H.glob('*-insns.json')):
  q=load(path)['result'][0];assert q['cursor']=={'done':True} and not q.get('truncated') and not q.get('error')
  assert q['count']==q['scanned']==len(q['matches']) and len(q['ranges'])==1
  addr=number(q['ranges'][0]['start']);size=number(q['ranges'][0]['end'])-addr
  validate(addr,size,captures[addr],q['matches'],path.name,True)
 assert {number(f['addr'])-B for f in functions}=={0x3E1240,0x3E1410,0x3E1A00,0x3E1C80,0x3DB100,0x3DB140}
 reuses={'actor-scale-contract-20261007':[0x3B44D0,0x3E1730,0x3E1840],'actor-scale-ownership-20261011':[0x1C9D60,0x1C7E00]}
 for study,rvas in reuses.items():
  path=ROOT/'docs/research'/study/'evidence.json';evidence=load(path)
  selected=[f for f in evidence['functions'] if number(f['addr'])-B in rvas];assert len(selected)==len(rvas)
  dependencies.append({'path':path.relative_to(ROOT).as_posix(),'sha256':sha(path.read_bytes()),'functions':[hex(B+r) for r in rvas]})
  for f in selected:
   rows=f['disassembly']['asm']['lines'] if 'disassembly' in f else f['asm']['lines']
   validate(number(f['addr']),number(f['size']),octets(f['originalBytes']),rows,path.relative_to(ROOT).as_posix()+'#functions[addr='+f['addr']+']',False)
 for path in H.glob('*-decompile.json'):
  d=load(path);assert d['cursor']=={'done':True} and not d.get('truncated') and d['line_count']==d['total_lines']
 for q in load(H/'xrefs.json')['result']:assert not q.get('more') and q['xref_count']==len(q['xrefs'])
 search=load(H/'direct-displacement-search.json');assert search['n']==len(search['hits'])==56 and search['cursor']=={'done':True}
 anchors=[]
 for rva in [0x3B4525,0x3B452B,0x3B4533,0x3E1759,0x3E176F,0x3E126A,0x3E13EA,0x3E14D9,0x3E1A14,0x3E1CED,0x3DB12A,0x3DB181,0x3DB271,0x3E1870,0x3E1882,0x1C9F44,0x1C7EDB]:
  i=ins[B+rva];anchors.append({'addr':hex(i.address),'bytes':bytes(i.bytes).hex(),'instruction':i.mnemonic+' '+i.op_str})
 groups={}
 for fresh,name in [(True,'fresh'),(False,'reused')]:
  fs=[f for f in functions if f['sourceMetadata']['freshCapture']==fresh]
  groups[name]={'functions':len(fs),'instructions':sum(len(f['instructions']) for f in fs),'bodyBytes':sum(f['size'] for f in fs),'noninstructionBytes':sum(s['size'] for f in fs for s in f['nonInstructionSpans'])}
 emit('evidence.json',{'schema':1,'originalSha256':PIN,'functions':functions,'dependencies':dependencies,'anchors':anchors})
 claims=load(H/'report.json')['claims'] if (H/'report.json').exists() else []
 refs=0
 if claims:
  parser=runpy.run_path(str(ROOT/'scripts/update-analysis-coverage.py'),run_name='actor_counter_reference_check')
  for claim in claims:
   assert {'addr','Finding','Evidence','Limitations'}<=claim.keys()
   for reference in claim['Evidence']:
    assert parser['resolve_reference'](H/'report.json',reference).get('status')=='exists',reference
    refs+=1
 emit('verification.json',{'status':'PASS','originalSha256':PIN,'counts':groups,'anchors':len(anchors),'claims':len(claims),'resolvedEvidenceReferences':refs,'nativeExecution':False,'modelCases':0,'scope':'Selected full original bodies plus explicit actor-argument provenance; not all writers, all callers, atomicity or lifetime proof. IDA names are labels, not evidence of semantics.','readiness':'Root captures used; global autoanalysis completion not independently observed.'})
 if check and (H/'manifest.json').exists():
  rows=load(H/'manifest.json')['files'];actual={p.relative_to(H).as_posix() for p in H.rglob('*') if p.is_file() and p.name!='manifest.json'};assert actual=={r['path'] for r in rows}
  for r in rows:
   data=(H/r['path']).read_bytes();assert len(data)==r['bytes'] and sha(data)==r['sha256']
 print(json.dumps({'status':'PASS','counts':groups,'anchors':len(anchors),'claims':len(claims),'references':refs}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');main(p.parse_args().check)
