"""Independent bounded Actor-counter review; no native or imported code execution."""
from pathlib import Path
import hashlib, json, struct
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STUDY = ROOT / 'artifacts/actor-counter-writers-20261013'
SHA = '9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
BASE = 0x140000000
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_bytes())
raw = Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe').read_bytes()
assert sha(raw) == SHA
pe = struct.unpack_from('<I', raw, 0x3c)[0]
assert raw[pe:pe+4] == b'PE\0\0' and struct.unpack_from('<H', raw, pe+24)[0] == 0x20b
assert struct.unpack_from('<Q', raw, pe+48)[0] == BASE
table = pe+24+struct.unpack_from('<H', raw, pe+20)[0]
sections = [struct.unpack_from('<IIII', raw, table+i*40+8) for i in range(struct.unpack_from('<H', raw, pe+6)[0])]
def read(addr, size):
    for _, start, count, offset in sections:
        if start <= addr-BASE and addr-BASE+size <= start+count:
            return raw[offset+addr-BASE-start:offset+addr-BASE-start+size]
    raise AssertionError(hex(addr))

evidence = load(STUDY / 'evidence.json')
assert evidence['originalSha256'] == SHA
assert len(evidence['functions']) == len({f['addr'] for f in evidence['functions']}) == 11
inventory = {int(f['address'], 16): f for line in (ROOT / 'docs/research/coverage/function_status.jsonl').read_text('utf8').splitlines() if (f := json.loads(line))['domain'] == 'native'}
decoder = Cs(CS_ARCH_X86, CS_MODE_64)
heads = {}; records = []; groups = {}
for f in evidence['functions']:
    addr = int(f['addr'], 16); size = f['size']; data = read(addr, size)
    assert size == inventory[addr]['size'] and data == bytes.fromhex(f['originalBytes'])
    assert sha(data) == f['sha256'] and f['complete'] and not f['nonInstructionSpans']
    ins = list(decoder.disasm(data, addr))
    assert sum(i.size for i in ins) == size and len(ins) == len(f['instructions'])
    assert [i.address for i in ins] == [int(i['addr'], 16) for i in f['instructions']]
    assert [i.bytes.hex() for i in ins] == [i['bytes'] for i in f['instructions']]
    assert [i.mnemonic + ' ' + i.op_str for i in ins] == [i['instruction'] for i in f['instructions']]
    heads.update({i.address: (i.mnemonic, i.op_str) for i in ins})
    source = f['sourceMetadata']
    if source['freshCapture']:
        query = load(STUDY / source['source'])['result'][0]
        assert query['cursor'] == {'done': True} and not query.get('truncated') and not query.get('error')
        assert query['count'] == query['scanned'] == len(query['matches']) == len(ins)
        assert query['ranges'] == [{'start': hex(addr), 'end': hex(addr+size)}]
        assert [int(i['addr'], 16) for i in query['matches']] == [i.address for i in ins]
    kind = 'fresh' if source['freshCapture'] else 'reused'
    group = groups.setdefault(kind, {'functions': 0, 'instructions': 0, 'bodyBytes': 0})
    group['functions'] += 1; group['instructions'] += len(ins); group['bodyBytes'] += size
    records.append({'addr': f['addr'], 'size': size, 'instructions': len(ins), 'sha256': sha(data), 'kind': kind})
assert groups == {'fresh': {'functions': 6, 'instructions': 409, 'bodyBytes': 1487}, 'reused': {'functions': 5, 'instructions': 306, 'bodyBytes': 1284}}
for d in evidence['dependencies']:
    assert sha((ROOT / d['path']).read_bytes()) == d['sha256']

# Exact observed operands anchor the manual, bounded dataflow assessment below.
expected = {
 0x3b44dc: ('mov', 'rbx, rcx'), 0x3b4525: ('mov', 'rdx, rbx'),
 0x3b452b: ('call', '0x1403e1730'), 0x3b4533: ('mov', 'qword ptr [rbx + 0x5b0], rax'),
 0x3e1747: ('mov', 'rbx, rdx'), 0x3e1759: ('mov', 'r9, rbx'), 0x3e176f: ('jmp', '0x1403e1240'),
 0x3e1254: ('mov', 'qword ptr [rcx + 0x38], rsi'), 0x3e126a: ('mov', 'qword ptr [rcx + 0x60], r9'),
 0x3e13de: ('mov', 'rax, qword ptr [rdi + 0x60]'), 0x3e13e8: ('je', '0x1403e13f0'),
 0x3e13ea: ('inc', 'dword ptr [rax + 0x5b8]'),
 0x3e14ce: ('jne', '0x1403e14e8'), 0x3e14d0: ('mov', 'rax, qword ptr [rsi + 0x60]'),
 0x3e14d9: ('dec', 'dword ptr [rax + 0x5b8]'), 0x3e14e2: ('or', 'ecx, 2'),
 0x3e14e5: ('mov', 'dword ptr [rsi + 0x38], ecx'),
 0x3e1a09: ('jne', '0x1403e1a23'), 0x3e1a14: ('dec', 'dword ptr [rax + 0x5b8]'),
 0x3e1a1d: ('or', 'edx, 2'), 0x3e1a20: ('mov', 'dword ptr [rcx + 0x38], edx'),
 0x3e1cd4: ('cmp', 'eax, 1'), 0x3e1cd7: ('je', '0x1403e1cfc'),
 0x3e1ce2: ('jne', '0x1403e1cfc'), 0x3e1ced: ('dec', 'dword ptr [rax + 0x5b8]'),
 0x3e1cf6: ('or', 'ecx, 2'), 0x3e1cf9: ('mov', 'dword ptr [rsi + 0x38], ecx'),
 0x3e1870: ('mov', 'r9, qword ptr [rbx + 0x60]'), 0x3e1882: ('call', '0x1403e1240'),
 0x3e18dc: ('call', '0x1403e1410'),
 0x3db10c: ('mov', 'rbx, rcx'), 0x3db127: ('call', 'qword ptr [rax + 0x28]'),
 0x3db12a: ('dec', 'dword ptr [rbx + 0x5b8]'), 0x3db130: ('and', 'dword ptr [rbx + 0x124], 0xfffff7ff'),
 0x3db166: ('mov', 'rsi, rcx'), 0x3db181: ('dec', 'dword ptr [rsi + 0x5b8]'),
 0x3db267: ('or', 'dword ptr [rsi + 0x124], 0x800'), 0x3db271: ('inc', 'dword ptr [rsi + 0x5b8]'),
 0x1c9f3b: ('mov', 'rcx, qword ptr [rdi + 8]'), 0x1c9f44: ('call', '0x1403db140'),
 0x1c7ed7: ('mov', 'rcx, qword ptr [r15 + 8]'), 0x1c7edb: ('call', '0x1403db100'),
}
assert all(heads[BASE+rva] == pair for rva, pair in expected.items())
assert read(BASE+0x5c6b00, 5) == b'comd\0'
# The literal comes from a captured RIP-relative reference, not a new scan.
lea = read(BASE+0x3db193, 7)
assert BASE+0x3db19a+struct.unpack_from('<i', lea, 3)[0] == BASE+0x5c6b00

report = load(STUDY / 'report.json') if (STUDY / 'report.json').exists() else None
manifest_path = STUDY / 'manifest.json'
manifest_hash = None
if manifest_path.exists():
    manifest_hash = sha(manifest_path.read_bytes())
    manifest = load(manifest_path)
    assert {p.relative_to(STUDY).as_posix() for p in STUDY.rglob('*') if p.is_file() and p != manifest_path} == {r['path'] for r in manifest['files']}
    for row in manifest['files']:
        data = (STUDY / row['path']).read_bytes()
        assert sha(data) == row['sha256'] and len(data) == row['bytes']

result = {'status': 'PASS', 'scope': 'Independent PE/instruction comparison and manual local dataflow review. No semantic VM or native execution.',
 'originalSha256': SHA, 'groups': groups, 'functions': 11, 'instructions': 715, 'bodyBytes': 2771,
 'selectedOperandAnchors': len(expected), 'additionalOriginalLiteralBytes': 5,
 'sourceManifestSha256': manifest_hash,
 'sourceHashes': {p.relative_to(STUDY).as_posix(): sha(p.read_bytes()) for p in sorted(STUDY.rglob('*')) if p.is_file()},
 'dependencyHashes': evidence['dependencies'], 'records': records,
 'semanticReview': [
   {'topic': 'Actor VM provenance', 'finding': '3B44D0 preserves its Actor in RBX, passes it as 3E1730 argument2, and stores the returned context at Actor+1456. 3E1730 preserves argument2, allocates112 bytes and on successful allocation tailcalls 3E1240 with that pointer in argument4. The constructor stores argument4 at context+96, resets context flags including mask0x2, then increments nonnull owner DWORD+1464.'},
   {'topic': 'VM release guards', 'finding': '3E1A00 and the final release part of3E1410 test context+56 mask0x2, decrement the nonnull pointer at context+96 plus1464 only while the mask is clear, then set mask0x2. This suppresses another local decrement while that mask remains set; it does not make the entire destructor idempotent, since cleanup/calls precede its guard.'},
   {'topic': 'VM update and temporary contexts', 'finding': '3E1C80 executes only while mask0x2 is clear and, if the interpreter return is not1, rechecks the mask before the same release. It recursively updates children. 3E1840 forwards parent context+96 to a temporary stack context constructor and later calls3E1410; the same Actor can therefore have additional context contributions. Abnormal helper exits and other writers remain outside the claim.'},
   {'topic': 'Command binding', 'finding': '3DB140 conditionally releases an existing Actor+292 mask0x800 contribution, locates comd resources with BAR types24 and25, calls its setup helpers, then sets mask0x800 and increments the same Actor DWORD+1464 if execution reaches that tail. 3DB100 tests this mask and, when set, calls virtual+40 before decrementing Actor+1464 and clearing the mask. The concrete callers1C9D60 and1C7E00 supply the Actor from their object+8, not the separately loaded player cache.'},
   {'topic': 'UI label', 'finding': 'Actor reference count is supported by the attack evidence already in the preceding studies and these additional VM/command contributions. It is not an attack-object count, contact-list count, number of unique actors or number of unique owners.'}
 ],
 'limits': ['Only selected existing captured functions and explicitly pinned provenance were inspected; no new xref or binary-wide writer scan was performed.',
   'No complete writer list, unique-owner cardinality, atomicity, reentrancy safety, arbitrary pointer validity or universal lifetime guarantee.',
   'Context mask0x2 is bit index1; mask0x800 in Actor+292 is bit index11. Local guards do not prove global ownership.',
   'Command setup has intervening opaque calls and assumes resource validity; no guaranteed success or live timing is established.'],
 'unresolvedFindings': []}
(HERE / 'review.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf8')
print(json.dumps({k: result[k] for k in ['status', 'functions', 'instructions', 'bodyBytes', 'selectedOperandAnchors', 'sourceManifestSha256']}))
