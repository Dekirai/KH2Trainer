# Independent review: Actor reference counter

**PASS.** The eleven selected complete bodies match the original executable: six fresh captures with 409 instructions/1487 bytes and five reused provenance bodies with 306 instructions/1284 bytes. Total: 715 instructions and 2771 bytes. The review independently checks 42 exact operand anchors and the five original bytes of the already referenced `comd` literal.

The final seven source claims were read against the complete instruction lists. No findings remain after the author clarified the flag mask, the cleanup boundary, and the conditional temporary-context update.

## Supported interpretation

The public label **Actor references** or **Actor reference count** is supported. In addition to the attack paths established in the preceding studies, the selected bodies contribute through VM contexts and command-data bindings. It is not a count of active attacks, contact-list entries, or unique objects or owners.

- `3B44D0` forwards its Actor as `3E1730` argument 2 and stores the returned context at Actor+1456. The allocator forwards that pointer as constructor argument 4. `3E1240` stores it at context+96 and increments the nonnull target's DWORD+1464. The distinct shared-data counter associated with context+88 is not this Actor counter.
- `3E1A00`, the final release block of `3E1410`, and the release block of `3E1C80` decrement through context+96 only while context+56 mask `0x2` is clear, then set the mask. The update rechecks after interpreter execution and releases only when its return is not 1.
- `3E1410` performs other cleanup before that flag check. The whole cleanup is therefore not proved idempotent. The guard prevents another selected local decrement only while its mask remains set, with no atomicity or reentrancy guarantee.
- `3E1840` copies context+96 into a temporary stack context. The update is optional when the resolved entry is positive; the normal tail calls cleanup. This is another local context contribution, not proof of every invocation or helper outcome.
- `3DB140` reads BAR types 24/25 under the literal `comd`. When its tail is reached, it sets input+292 mask `0x800` and increments input+1464. Existing binding release occurs first when that mask was already set. `3DB100` calls controller virtual+40 before decrementing and clearing the mask. No guaranteed net change is inferred across the opaque helper calls.
- The specific callers `1C9D60` and `1C7E00` supply their context+8 pointer to command setup/release. Their separate cached-player operations do not substitute a different pointer for that argument. This is the bounded provenance endpoint, not a universal caller or live sequencing claim.

## Boundaries and receipts

No new binary-wide scan or IDA capture was performed. The recorded 56 text matches are candidates that include unrelated object offsets and stack/vector accesses; they are not 56 verified Actor writers. Counter0 alone does not authorize destruction.

The review does not prove all writers, unique-owner cardinality, concurrency safety, arbitrary pointer validity, or all resource lifetimes. No native/game execution or synthetic semantic VM was used.

`review.json` pins all frozen source files and the source manifest, including the final seven-claim report. `audit.py` writes only this independent review directory. The source manifest SHA256 is `b177d643b68a40b169cec8f85dcb5215e6fa102080b607baf7403de0162ef71b`.
