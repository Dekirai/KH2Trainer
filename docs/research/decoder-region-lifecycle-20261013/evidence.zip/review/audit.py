"""Independent static PE, instruction-flow and metadata review. No game calls."""
from pathlib import Path
import hashlib,json,re,struct
from capstone import Cs,CS_ARCH_X86,CS_MODE_64

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
STUDY=ROOT/'artifacts/decoder-region-lifecycle-20261013'
CAP=STUDY/'root-capture'
EXE=Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
load=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
num=lambda x:int(x,16) if isinstance(x,str) else x
octets=lambda s:bytes(int(x,16) for x in s.split()) if '0x' in s else bytes.fromhex(s)
def pin(p):
    b=p.read_bytes();return {'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':sha(b)}
manifest_pin=pin(STUDY/'manifest.json')
assert manifest_pin['sha256']=='803c7c04c3afa6d54fe826853a3c7d2930552ad82f1c741b9e336f78387d8e00'
members=load(STUDY/'manifest.json')['files']
assert {r['path'] for r in members}=={p.relative_to(STUDY).as_posix() for p in STUDY.rglob('*') if p.is_file() and p.name!='manifest.json'}
for r in members:
    b=(STUDY/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path']
raw=EXE.read_bytes()
assert sha(raw)=='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
nt=struct.unpack_from('<I',raw,60)[0];assert raw[nt:nt+4]==b'PE\0\0'
opt=nt+24;base=struct.unpack_from('<Q',raw,opt+24)[0];assert base==0x140000000
section_table=opt+struct.unpack_from('<H',raw,nt+20)[0]
sections=[struct.unpack_from('<IIII',raw,section_table+i*40+8) for i in range(struct.unpack_from('<H',raw,nt+6)[0])]
def pe(a,n):
    for _,start,size,offset in sections:
        if start<=a-base and a-base+n<=start+size:
            return raw[offset+a-base-start:offset+a-base-start+n]
    raise AssertionError(hex(a))
def cstring(a):
    out=bytearray()
    while (v:=pe(a+len(out),1))!=b'\0':out+=v
    return out.decode('ascii')

md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
functions={};insns={};decoded=[];padding=[]
def check(a,b,rows,origin):
    assert a not in functions and b==pe(a,len(b))
    assert num(rows[0]['addr'])==a
    out=[]
    for k,row in enumerate(rows):
        at=num(row['addr']);end=num(rows[k+1]['addr']) if k+1<len(rows) else a+len(b)
        assert a<=at<end<=a+len(b)
        chunk=b[at-a:end-a];seq=list(md.disasm(chunk,at))
        assert sum(i.size for i in seq)==len(chunk) and seq
        i=seq[0];insns[at]=i
        if len(seq)>1:
            assert all(x.mnemonic in ['nop','int3'] for x in seq[1:])
            padding.append({'address':hex(at+i.size),'bytes':chunk[i.size:].hex()})
        out.append({'address':hex(at),'text':i.mnemonic+' '+i.op_str,'bytes':bytes(i.bytes).hex()})
    f={'address':hex(a),'size':len(b),'sha256':sha(b),'origin':origin,'instructions':out}
    functions[a]=f;decoded.append(f)

buffers={num(r['addr']):octets(r['data']) for r in load(CAP/'new-bytes.json')['result']}
look={num(r['fn']['addr']):num(r['fn']['size']) for r in load(CAP/'new-lookup.json')['result']}
fresh=set()
for q in load(CAP/'new-instructions.json')['result']:
    assert q['cursor']=={'done':True} and not q.get('truncated') and not q.get('error')
    assert q['count']==q['scanned']==len(q['matches']) and len(q['ranges'])==1
    a=num(q['ranges'][0]['start']);n=num(q['ranges'][0]['end'])-a
    assert len(buffers[a])==n==look[a]
    check(a,buffers[a],q['matches'],'fresh');fresh.add(a)
assert len(fresh)==7
dep=ROOT/'docs/research/motion-native-copy-contract-20261011/evidence.json'
prior={num(f['addr']):f for f in load(dep)['functions']}
reused={base+x for x in [0x4ad240,0x4ad270,0x4ad2c0,0x4ad390,0x4ad3f0]}
for a in sorted(reused):
    f=prior[a];b=octets(f['originalBytes']);assert len(b)==num(f['size'])
    check(a,b,f['disassembly']['asm']['lines'],'reused')
assert len(functions)==12
evidence=load(STUDY/'evidence.json')
assert {num(f['addr']) for f in evidence['functions']}==set(functions)
for f in evidence['functions']:
    a=num(f['addr']);ind=functions[a]
    assert f['complete'] and f['size']==ind['size'] and sha(octets(f['originalBytes']))==ind['sha256']==f['sha256']
    rows=f['disassembly']['asm']['lines']
    assert len(rows)==len(ind['instructions'])==f['disassembly']['instruction_count']==f['disassembly']['total_instructions']
    for row,actual in zip(rows,ind['instructions']):
        assert num(row['addr'])==num(actual['address']) and row['bytes']==actual['bytes'] and row['decoded']==actual['text']
assert sum(f['size'] for f in functions.values())==891
assert sum(len(f['instructions']) for f in functions.values())==211
assert padding==[{'address':'0x1404ad2fc','bytes':'0f1f4000'}]

anchors=[]
def exact(rva,text):
    i=insns[base+rva];assert i.mnemonic+' '+i.op_str==text,(hex(i.address),i.mnemonic+' '+i.op_str,text)
    anchors.append({'address':hex(i.address),'bytes':bytes(i.bytes).hex(),'text':text})
def rip_target(rva):
    i=insns[base+rva];m=next(o.mem for o in i.operands if o.type==3)
    assert i.reg_name(m.base)=='rip'
    return i.address+i.size+m.disp

# Saturation is a straight original-code branch, not a simulated game run.
exact(0x4ad39d,'and r9d, 0x1ffffff');exact(0x4ad3a4,'and r8, 0xfffffffffe000000')
exact(0x4ad3ae,'xor eax, eax');exact(0x4ad3b0,'mov rdx, qword ptr [rcx]')
exact(0x4ad3b3,'cmp rdx, -1');exact(0x4ad3b7,'je 0x1404ad3d4')
exact(0x4ad3b9,'cmp rdx, r8');exact(0x4ad3bc,'je 0x1404ad3db')
exact(0x4ad3be,'inc eax');exact(0x4ad3c0,'add rcx, 8')
exact(0x4ad3c4,'cmp eax, 0x40');exact(0x4ad3c7,'jb 0x1404ad3b0')
exact(0x4ad3c9,'shl eax, 0x19');exact(0x4ad3cc,'or eax, r9d')
exact(0x4ad3cf,'bts eax, 0x1f');exact(0x4ad3d3,'ret ')
exact(0x4ad3d7,'mov qword ptr [r10 + rcx*8], r8')
exact(0x4ad3db,'shl eax, 0x19');exact(0x4ad3e1,'bts eax, 0x1f')
exact(0x4ad3fd,'btr ebx, 0x1f');exact(0x4ad40a,'mov eax, ebx')
exact(0x4ad40c,'shr rax, 0x19');exact(0x4ad410,'and ecx, 0x1ffffff')
exact(0x4ad416,'mov rax, qword ptr [rdx + rax*8]');exact(0x4ad41a,'or rax, rcx')
for rva in [0x4ad393,0x4ad401,0x4ad360]:assert rip_target(rva)==base+0x2b0d720
encoder=[insns[num(r['address'])] for r in functions[base+0x4ad390]['instructions']]
assert [i.address for i in encoder if any(o.type==3 and o.access & 2 for o in i.operands)]==[base+0x4ad3d7]
assert not any(i.mnemonic.startswith('lock') or i.mnemonic in ['call','xchg','cmpxchg'] for i in encoder)
# Each possible low-offset value preserves its bits, so (64<<25) becomes only
# the removed marker bit for every offset. Check extremal/example values too.
assert ((64<<25)&0xffffffff)==0x80000000
arithmetic=[]
for offset in [0,1,0x12345,0x1ffffff]:
    word=((64<<25)|offset|0x80000000)&0xffffffff
    region=(word&0x7fffffff)>>25
    assert region==0 and word&0x1ffffff==offset
    arithmetic.append({'offset':offset,'word':hex(word),'decodedRegion':region})

# Guard, completion, abort and wrapper order.
exact(0x4ad2ee,'jg 0x1404ad34b');exact(0x4ad352,'call 0x140439f50')
exact(0x4ad357,'cmp dword ptr [rip + 0x26605c2], -1')
exact(0x4ad35e,'jne 0x1404ad2f0');exact(0x4ad367,'mov edx, 8')
exact(0x4ad343,'sub rdx, 1');exact(0x4ad347,'je 0x1404ad36e')
exact(0x4ad349,'jmp 0x1404ad300');exact(0x4ad375,'call 0x140439ef0')
loop=[insns[num(r['address'])] for r in functions[base+0x4ad2c0]['instructions'] if base+0x4ad300<=num(r['address'])<base+0x4ad343]
stores=[i for i in loop if i.mnemonic=='mov'];assert len(stores)==8
assert all(i.op_str.endswith('0xffffffffffffffff') and i.operands[0].size==8 for i in stores)
exact(0x439f66,'cmp dword ptr [rbx], 0');exact(0x439f6b,'or dword ptr [rbx], 0xffffffff')
exact(0x439f70,'mov ecx, 0x64');exact(0x439f75,'call 0x14043a028')
exact(0x439f7a,'jmp 0x140439f66');exact(0x439f7c,'cmp dword ptr [rbx], -1')
exact(0x439f7f,'je 0x140439f70')
exact(0x439f19,'inc eax');exact(0x439f21,'mov dword ptr [rbx], eax')
exact(0x439f3c,'mov dword ptr [r9 + r8], eax')
exact(0x439ed6,'and dword ptr [rbx], 0');exact(0x439eeb,'jmp 0x140439fc8')
exact(0x5707a7,'jmp 0x140439ec0')
assert rip_target(0x5707a0)==base+0x2b0d920
assert rip_target(0x439f1b)==base+0x759204
for rva in [0x439f59,0x439fa4,0x439ef9,0x439ed9,0x43a06d,0x43a08c]:assert rip_target(rva)==base+0x2af9b20
for call,jump in [(0x4ad256,0x4ad266),(0x4ad296,0x4ad2a6)]:
    exact(call,'call 0x1404ad2c0');exact(jump,'jmp 0x1404ad390')

# Resolve imported synchronization names from the PE itself, not IDA labels.
imports={}
idir=struct.unpack_from('<II',raw,opt+112+8)[0]
at=base+idir
while any(desc:=struct.unpack('<IIIII',pe(at,20))):
    original,_,_,name,first=desc;dll=cstring(base+name)
    k=0
    while thunk:=struct.unpack('<Q',pe(base+original+8*k,8))[0]:
        imports[base+first+8*k]=(dll,cstring(base+thunk+2) if not thunk>>63 else 'ordinal:'+str(thunk&0xffff));k+=1
    at+=20
api_calls={0x439f60:'EnterCriticalSection',0x439fb0:'LeaveCriticalSection',
  0x439f00:'EnterCriticalSection',0x439f40:'LeaveCriticalSection',
  0x439ed0:'EnterCriticalSection',0x439ee0:'LeaveCriticalSection',
  0x43a000:'SetEvent',0x43a011:'ResetEvent',0x43a074:'LeaveCriticalSection',
  0x43a086:'WaitForSingleObjectEx',0x43a098:'EnterCriticalSection'}
for rva,name in api_calls.items():assert imports[rip_target(rva)][1]==name

# Runtime function -> UNWIND_INFO -> FuncInfo -> unwind action and IP states.
tables=[]
for r in load(CAP/'initializer-metadata-bytes.json')['result']:
    a=num(r['addr']);b=octets(r['data']);assert b==pe(a,len(b))
    tables.append({'address':hex(a),'bytes':len(b),'sha256':sha(b)})
assert sum(t['bytes'] for t in tables)==116
prva,psize=struct.unpack_from('<II',raw,opt+112+3*8)
runtime=next(r for r in struct.iter_unpack('<III',pe(base+prva,psize)) if r[0]==0x4ad2c0)
assert runtime==(0x4ad2c0,0x4ad386,0x6fb948)
assert struct.unpack('<III',pe(base+0x2bc6e90,12))==runtime
hdr=pe(base+runtime[2],4);assert hdr==bytes.fromhex('110d0100')
assert hdr[0]&7==1 and hdr[0]>>3==2
uend=(4+2*hdr[2]+3)&~3
handler,info=struct.unpack('<II',pe(base+runtime[2]+uend,8))
assert (handler,info)==(0x471a36,0x5fa7c0)
fi=struct.unpack('<10I',pe(base+info,40))
assert fi==(0x19930522,1,0x6fb918,0,0,5,0x6fb920,0x20,0,0)
assert struct.unpack('<iI',pe(base+fi[2],8))==(-1,0x5707a0)
ip_states=list(struct.iter_unpack('<Ii',pe(base+fi[6],8*fi[5])))
assert ip_states==[(0x4ad2c0,-1),(0x4ad300,0),(0x4ad34b,-1),(0x4ad360,0),(0x4ad36e,-1)]

# Complete captured xrefs mean exactly that recorded scope; no alias closure.
for name in ['region-xrefs.json','guard-wrapper-xrefs.json','abort-xrefs.json','slot-xrefs.json']:
    for q in load(CAP/name)['result']:
        assert not q.get('error') and not q['more'] and q['xref_count']==len(q['xrefs'])
slots=load(CAP/'slot-xrefs.json')['result']
assert [num(q['addr']) for q in slots]==[base+0x2b0d720+8*k for k in range(64)]
assert sum(q['xref_count'] for q in slots)==3
assert all(q['xref_count']==0 for q in slots[1:])

report=load(STUDY/'report.json');assert len(report['claims'])==9 and report['status']=='AUTHOR_COMPLETE'
references=0
for c in report['claims']:
    assert num(c['addr']) in functions and c['Limitations']
    for ref in c['Evidence']:
        path,separator,fragment=ref.partition('#');p=STUDY/path
        assert p.is_file(),ref
        if separator:
            payload=load(p)
            if match:=re.fullmatch(r'functions\[addr=(0x[0-9a-fA-F]+)\]',fragment):
                assert any(num(f['addr'])==num(match[1]) for f in payload['functions'])
            else:assert fragment in payload
        references+=1
assert pin(STUDY/'manifest.json')==manifest_pin
receipt={'status':'ACCEPTED','findings':[],'authorManifest':manifest_pin,
 'authorReport':pin(STUDY/'report.json'),'authorMarkdown':pin(STUDY/'report.md'),'authorEvidence':pin(STUDY/'evidence.json'),
 'dependency':pin(dep),'originalSha256':sha(raw),'manifestMembers':len(members),'claims':9,'references':references,
 'functions':12,'recordedInstructions':211,'bodyBytes':891,'alignmentBytesWithinBodies':4,
 'metadataBytes':116,'semanticAnchors':len(anchors),'originalImportNames':api_calls,
 'metadata':{'runtimeFunction':runtime,'handler':handler,'funcInfo':info,'unwindAction':0x5707a0,'ipStates':ip_states},
 'saturationArithmetic':arithmetic,
 'scope':'Independent original PE byte equality, full recorded-body review, import-name and selected EH metadata parsing. Static only.',
 'limits':['No live exhaustion or actual race demonstrated.','No all-writer or all-indirect-caller closure.',
           'No ordinary slot-free/reuse path demonstrated.','Region identity is not allocation generation or production ReadScope admission.']}
(HERE/'decoded.json').write_text(json.dumps({'functions':decoded,'padding':padding,'anchors':anchors},indent=2)+'\n',encoding='utf-8')
(HERE/'review.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['status','findings','manifestMembers','claims','functions','recordedInstructions','bodyBytes','alignmentBytesWithinBodies','metadataBytes','semanticAnchors']}))
