# Independent review: decoder region lifecycle

Status: **ACCEPTED**, no findings. All nine bounded claims match the selected
complete instruction bodies and PE metadata. The author verifier also passes.

## Independent checks

- All 25 frozen author files match the expected manifest.
- Twelve complete bodies match the original executable: 211 recorded
  instructions and 891 body bytes, including four separately accounted alignment
  bytes. Seven bodies are fresh; five match their explicit earlier dependency.
- All 116 captured metadata bytes match the PE. The PE exception directory
  independently selects `[4AD2C0,4AD386,6FB948]`. The unwind header links to
  handler `471A36` and FuncInfo `5FA7C0`; the unwind map selects `5707A0`.
- All five IP-to-state entries also match: state 0 covers the initializer store
  ranges, while the other recorded states are -1. This supports the particular
  cleanup binding without claiming complete OS/language exception semantics.
- Synchronization import names were read independently from the original PE's
  import directory. The relevant calls resolve to Enter/LeaveCriticalSection,
  SetEvent, ResetEvent and WaitForSingleObjectEx.
- Fifty-one independent exact semantic anchors cover the encoder/decoder,
  guard protocol, completion, abort and wrappers. Complete captured slot xrefs
  contain three references to the first slot and none to the other 63 addresses.

## Conclusions

The exhaustion branch is explicit: after 64 unequal occupied slots, the code
shifts EAX=64 left by 25 in 32 bits, adds the low offset and sets the marker bit.
The decoder clears that bit and therefore selects region 0. The only encoder
table store belongs to the free-slot branch. No table store or explicit error
occurs on exhaustion. This is an arithmetic/control-flow consequence, not an
observed runtime failure or a native execution test.

The initialization guard is distinct from encoder registration. The acquisition
helper leaves its critical section before returning to the initializer; the
wrappers reach the encoder only after initialization returns. The selected
encoder has no local lock, atomic slot reservation or call to a lock helper.
This does not prove a concurrent race: callers and their thread ordering remain
outside this closure.

The cleanup funclet resets the guard through `439EC0`; it does not reset the
table itself. A later initialization attempt may repeat sentinel initialization.
No ordinary free/reuse path for individual table slots is established. Stable
region bytes cannot establish allocation generation or resource lifetime.

The report preserves the important limits: no live exhaustion, actual race,
all-writer closure, universal CRT/OS correctness or production ReadScope
admission. No product, research-document, global-coverage or package edits were
performed. No game, GUI, Twitch, build or native execution occurred.

## Reproduction and source pins

```powershell
py -3 -B artifacts/review-decoder-region-lifecycle-20261013/audit.py
```

- Author manifest: `803c7c04c3afa6d54fe826853a3c7d2930552ad82f1c741b9e336f78387d8e00`
- Author report JSON: `c9ce9ea531ec757a6d8622224d60c343c3757bfb53fa8477f1ca6e8696c8a742`
- Author report Markdown: `8704a4d17cd86e2d0977e847edfea45acfa05f4d7809532f2e8674223e079c9f`
- Author evidence: `b283caf62d2af02582e11132de7d7d56dd9db5f1a346f6fd0b3b120818314d51`
- Original EXE: `9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed`

The review receipt records exact pins, parsed metadata, import names and scope.
The independent decoding and selected anchors are saved in `decoded.json`.
