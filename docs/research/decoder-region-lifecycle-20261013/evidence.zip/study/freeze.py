from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
rows=[]
for p in sorted(root.rglob('*')):
    if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts:
        b=p.read_bytes();rows.append({'path':p.relative_to(root).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
data=(json.dumps({'selfExcluded':True,'files':rows},indent=2)+'\n').encode()
(root/'manifest.json').write_bytes(data)
print(json.dumps({'files':len(rows),'manifestSha256':hashlib.sha256(data).hexdigest()}))
