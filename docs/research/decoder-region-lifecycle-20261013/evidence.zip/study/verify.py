"""Check selected Ptr32/CRT bodies against the original executable; never run them."""
from pathlib import Path
import argparse, hashlib, json, struct
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=0x140000000
SOURCE=Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
PIN='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
num=lambda n:int(n,16) if isinstance(n,str) else n
octets=lambda s:bytes(int(x,16) for x in s.split()) if '0x' in s else bytes.fromhex(s)

def main(check=False):
    raw=SOURCE.read_bytes();assert sha(raw)==PIN
    nt=struct.unpack_from('<I',raw,0x3c)[0];opt=nt+24
    assert struct.unpack_from('<Q',raw,opt+24)[0]==BASE
    sections=[struct.unpack_from('<IIII',raw,opt+struct.unpack_from('<H',raw,nt+20)[0]+40*i+8)
        for i in range(struct.unpack_from('<H',raw,nt+6)[0])]
    def pe(addr,size):
        rva=addr-BASE
        for vs,start,rs,offset in sections:
            if start<=rva and rva+size<=start+rs:return raw[offset+rva-start:offset+rva-start+size]
        raise AssertionError(hex(addr))
    def emit(name,obj):
        data=(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode()
        if check:assert (HERE/name).read_bytes()==data,name
        else:(HERE/name).write_bytes(data)
    inventory={num(f['address']):f['size'] for line in (ROOT/'docs/research/coverage/function_status.jsonl').read_text().splitlines()
        if (f:=json.loads(line))['domain']=='native'}
    md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
    aliases={'retn':'ret','jz':'je','jnz':'jne','jnb':'jae','jna':'jbe','jnl':'jge','jng':'jle',
        'cmovz':'cmove','cmovnz':'cmovne','setz':'sete','setnz':'setne','sal':'shl'}
    functions=[];decoded={};padding=[]
    def body(addr,size,data,rows,origin,fresh,name):
        assert len(data)==size==inventory[addr] and pe(addr,size)==data
        assert num(rows[0]['addr'])==addr
        normalized=[]
        for j,row in enumerate(rows):
            at=num(row['addr']);end=num(rows[j+1]['addr']) if j+1<len(rows) else addr+size
            text=row.get('disasm',row.get('instruction'))
            i=next(md.disasm(data[at-addr:end-addr],at,count=1))
            assert i.size<=end-at
            word=text.split()[0]
            assert aliases.get(word,word)==i.mnemonic or (word=='xchg' and i.mnemonic=='nop'),(hex(at),text,i.mnemonic)
            decoded[at]=i
            if i.size<end-at:
                gap=data[at-addr+i.size:end-addr]
                alignment=list(md.disasm(gap,at+i.size))
                assert sum(a.size for a in alignment)==len(gap) and all(a.mnemonic in ('nop','int3') for a in alignment),(hex(at),gap.hex())
                padding.append({'addr':hex(at+i.size),'bytes':gap.hex(' ')})
            normalized.append({'addr':hex(at),'instruction':text,'decoded':i.mnemonic+' '+i.op_str,'bytes':bytes(i.bytes).hex()})
        page={'addr':hex(addr),'asm':{'name':name,'start_ea':hex(addr),'segment':'.text','lines':normalized},
            'instruction_count':len(rows),'total_instructions':len(rows),'cursor':{'done':True}}
        functions.append({'addr':hex(addr),'name':name,'size':size,'complete':True,'originalBytes':data.hex(' '),
            'sha256':sha(data),'captureKind':'fresh' if fresh else 'reused','origin':origin,'pages':[page],'disassembly':page})
    bs={num(b['addr']):octets(b['data']) for b in load(HERE/'root-capture/new-bytes.json')['result']}
    for q in load(HERE/'root-capture/new-instructions.json')['result']:
        assert q['cursor']=={'done':True} and not q.get('truncated') and not q.get('error')
        assert q['count']==q['scanned']==len(q['matches']) and len(q['ranges'])==1
        a=num(q['ranges'][0]['start']);size=num(q['ranges'][0]['end'])-a
        body(a,size,bs[a],q['matches'],'root-capture/new-instructions.json',True,q['matches'][0]['fn']['name'])
    dep=ROOT/'docs/research/motion-native-copy-contract-20261011/evidence.json'
    existing={num(f['addr']):f for f in load(dep)['functions']}
    for rva in [0x4AD240,0x4AD270,0x4AD2C0,0x4AD390,0x4AD3F0]:
        f=existing[BASE+rva];asm=f['disassembly']['asm']
        body(BASE+rva,num(f['size']),octets(f['originalBytes']),asm['lines'],dep.relative_to(ROOT).as_posix(),False,asm.get('name',hex(BASE+rva)))
    assert len(functions)==12
    xr=[]
    for name in ['region-xrefs.json','guard-wrapper-xrefs.json','abort-xrefs.json','slot-xrefs.json']:
        q=load(HERE/'root-capture'/name)['result']
        for x in q:assert not x.get('error') and not x['more'] and x['xref_count']==len(x['xrefs'])
        xr.append({'path':'root-capture/'+name,'queries':len(q),'xrefOccurrences':sum(x['xref_count'] for x in q)})
    slots=load(HERE/'root-capture/slot-xrefs.json')['result']
    assert len(slots)==64 and [num(x['addr']) for x in slots]==list(range(BASE+0x2B0D720,BASE+0x2B0D920,8))
    assert sum(x['xref_count'] for x in slots)==3
    tables=[]
    for row in load(HERE/'root-capture/initializer-metadata-bytes.json')['result']:
        a=num(row['addr']);b=octets(row['data']);assert b==pe(a,len(b))
        tables.append({'addr':hex(a),'size':len(b),'bytes':b.hex(' '),'sha256':sha(b)})
    assert struct.unpack('<iI',pe(BASE+0x6FB918,8))==(-1,0x5707A0)
    assert struct.unpack('<III',pe(BASE+0x5FA7C0,12))==(0x19930522,1,0x6FB918)
    pdata_rva,pdata_size=struct.unpack_from('<II',raw,opt+112+3*8)
    runtime_rows=list(struct.iter_unpack('<III',pe(BASE+pdata_rva,pdata_size)))
    runtime=next(r for r in runtime_rows if r[0]==0x4AD2C0)
    assert runtime==(0x4AD2C0,0x4AD386,0x6FB948)
    assert struct.unpack('<III',pe(BASE+0x2BC6E90,12))==runtime
    unwind_header=pe(BASE+runtime[2],4)
    unwind_size=(4+2*unwind_header[2]+3)&~3
    handler,handler_data=struct.unpack('<II',pe(BASE+runtime[2]+unwind_size,8))
    assert (handler,handler_data)==(0x471A36,0x5FA7C0)
    runtime_evidence={'runtimeFunction':[hex(v) for v in runtime],'unwindHeader':unwind_header.hex(' '),
        'handlerRva':hex(handler),'handlerData':hex(handler_data)}
    anchor_rvas=[0x4AD2EE,0x4AD300,0x4AD343,0x4AD347,0x4AD352,0x4AD357,0x4AD35E,0x4AD360,0x4AD367,0x4AD375,
        0x4AD3B0,0x4AD3B3,0x4AD3B7,0x4AD3B9,0x4AD3BC,0x4AD3BE,0x4AD3C4,0x4AD3C7,0x4AD3C9,0x4AD3CF,0x4AD3D7,
        0x439F60,0x439F66,0x439F6B,0x439F75,0x439F7C,0x439FB0,0x439F1B,0x439F21,0x439F3C,0x439ED6,0x5707A0,0x5707A7]
    anchors=[]
    for rva in anchor_rvas:
        i=decoded[BASE+rva];anchors.append({'addr':hex(i.address),'bytes':bytes(i.bytes).hex(),'instruction':i.mnemonic+' '+i.op_str})
    # Arithmetic consequence of the verified exhaustion branch (EAX=64, SHL 25, BTS 31).
    full_encoded=((64<<25)|0x12345|0x80000000)&0xffffffff
    saturation={'indexBeforeShift':64,'exampleOffset':0x12345,'returnedWord':hex(full_encoded),
        'decodedIndex':(full_encoded&0x7fffffff)>>25,'tableWriteOnExhaustion':False,
        'scope':'Arithmetic consequence of original instruction flow; not a live-game or native execution test.'}
    assert saturation['decodedIndex']==0
    groups={k:{'functions':len(fs:=[f for f in functions if f['captureKind']==k]),
        'instructions':sum(f['disassembly']['instruction_count'] for f in fs),'bodyBytes':sum(f['size'] for f in fs)} for k in ['fresh','reused']}
    emit('evidence.json',{'schema':1,'originalSha256':PIN,'functions':functions,'tables':tables,'anchors':anchors,
        'padding':padding,'xrefCaptures':xr,'saturation':saturation,'initializerRuntimeMetadata':runtime_evidence,
        'dependencies':[{'path':dep.relative_to(ROOT).as_posix(),'sha256':sha(dep.read_bytes())}]})
    emit('verification.json',{'status':'PASS','counts':groups,'anchors':len(anchors),'dataBytes':sum(t['size'] for t in tables),
        'paddingBytes':sum(len(octets(p['bytes'])) for p in padding),'queriedSlots':64,'nativeExecution':False,
        'scope':'Selected original instruction flow, CRT helpers, direct xrefs and arithmetic. No all-writer closure, OS synchronization proof or runtime saturation/concurrency claim.'})
    if check and (HERE/'manifest.json').exists():
        rows=load(HERE/'manifest.json')['files']
        actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and p.name!='manifest.json'}
        assert actual=={r['path'] for r in rows}
        for row in rows:
            data=(HERE/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
    print(json.dumps({'status':'PASS','counts':groups,'anchors':len(anchors),'nativeExecution':False}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');main(p.parse_args().check)
