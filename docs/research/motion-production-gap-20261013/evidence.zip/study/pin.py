"""Pin read-only source/evidence inspection inputs; no builds or game access."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sources = [
    'src/KH2Trainer.Bridge/MotionReadGate.h',
    'src/KH2Trainer.Bridge/MotionPayloadCopy.h',
    'src/KH2Trainer.Bridge/MotionEntryPlan.h',
    'src/KH2Trainer.Bridge/MotionObserverSupport.h',
    'src/KH2Trainer.Bridge/MotionObservationRuntime.h',
    'src/KH2Trainer.Bridge/MotionFeatures.inl',
    'src/KH2Trainer.Bridge/ActorLifetimeSupport.inl',
    'src/KH2Trainer.Bridge/StatusRevisionLedger.h',
    'src/KH2Trainer.Bridge/StatusThreadDrain.h',
    'src/KH2Trainer.Bridge/TrainerBridge.cpp',
    'src/KH2Trainer.Bridge/DevToolsProtocol.h',
    'src/KH2Trainer.Core/BridgeProtocol.cs',
    'src/KH2Trainer.Core/MotionPayloadReader.cs',
    'tests/KH2Trainer.Bridge.Tests/MotionReadGateTests.cpp',
    'tests/KH2Trainer.Bridge.Tests/MotionPayloadCopyTests.cpp',
]
evidence = [
    'docs/research/motion-cache-read-scope-20261011/evidence.json',
    'docs/research/actor-contact-retirement-20261013/evidence.json',
    'artifacts/actor-destruction-boundary-20261013/root-capture/followup-bytes.json',
    'artifacts/actor-destruction-boundary-20261013/root-capture/followup-lookup.json',
    'artifacts/actor-destruction-boundary-20261013/root-capture/bytes.json',
    'artifacts/actor-destruction-boundary-20261013/root-capture/lookup.json',
    'artifacts/motion-production-gap-20261013/scheduler-order.json',
    'docs/research/motion-native-copy-contract-20261011/contract.md',
    'docs/research/motion-native-copy-contract-20261011/root-ida-decompile-0x1404ad240.json',
    'docs/research/motion-native-copy-contract-20261011/root-ida-decompile-0x1404ad270.json',
    'docs/research/motion-provider-write-closure-20261011/report.md',
    'docs/research/motion-provider-write-closure-20261011/contract.md',
    'docs/research/motion-provider-write-closure-20261011/root-xrefs-next.json',
    'docs/research/motion-provider-write-closure-20261011/root-xrefs-retirement.json',
    'docs/research/motion-provider-write-closure-20261011/root-xrefs-handlers.json',
    'docs/research/motion-cache-read-scope-20261011/contract.md',
    'docs/research/motion-cache-read-scope-20261011/report.md',
    'docs/research/motion-resource-binding-20261011/report.md',
    'docs/research/motion-resource-binding-20261011/report.json',
    'docs/research/motion-read-gate-20261011/README.md',
    'docs/research/motion-prepared-copy-20261011/README.md',
    'docs/research/motion-payload-copy-implementation-20261011/README.md',
]
def pin(name):
    data = (ROOT / name).read_bytes()
    return {'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
receipt = {'scope': 'Read-only gap analysis; no native evidence recollection or execution.',
           'sourcePins': [pin(name) for name in sources],
           'evidencePins': [pin(name) for name in evidence],
           'report': pin('artifacts/motion-production-gap-20261013/report.md')}
(HERE / 'source-pins.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'sourcePins': len(sources), 'evidencePins': len(evidence), 'report': receipt['report']}))
