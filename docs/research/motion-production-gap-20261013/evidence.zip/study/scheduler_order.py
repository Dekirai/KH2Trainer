"""Reuse six captured bodies and compare them to the original PE; no game execution."""
from pathlib import Path
import hashlib
import json
import struct
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
EXE = Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
original = EXE.read_bytes()
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(original) == '9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
pe = struct.unpack_from('<I', original, 0x3c)[0]
assert original[pe:pe+4] == b'PE\0\0'
section_count = struct.unpack_from('<H', original, pe+6)[0]
optional_size = struct.unpack_from('<H', original, pe+20)[0]
image_base = struct.unpack_from('<Q', original, pe+24+24)[0]
sections = []
for i in range(section_count):
    at = pe+24+optional_size+i*40
    virtual_size, rva, size, offset = struct.unpack_from('<IIII', original, at+8)
    sections.append((rva, size, offset))
def original_at(address, size):
    rva = address-image_base
    for start, raw_size, offset in sections:
        if start <= rva and rva-start+size <= raw_size:
            return original[offset+rva-start:offset+rva-start+size]
    raise AssertionError(hex(address))

functions = []
for path, targets in [
    ('docs/research/motion-cache-read-scope-20261011/evidence.json', [0x1403a09c0, 0x14014f770, 0x1403a0790]),
    ('docs/research/actor-contact-retirement-20261013/evidence.json', [0x14014fd60]),
]:
    data=json.loads((ROOT/path).read_bytes())
    selected=[f for f in data['functions'] if int(f['addr'],16) in targets]
    assert len(selected)==len(targets)
    for f in selected:
        assert f['complete']
        raw=bytes.fromhex(f['originalBytes'])
        assert len(raw)==f['size'] and sha(raw)==f['sha256']
        functions.append({'address':f['addr'],'size':len(raw),'raw':raw,'origin':path+'#functions[addr='+f['addr']+']'})
capture='artifacts/actor-destruction-boundary-20261013/root-capture/'
for byte_name, lookup_name, address in [('followup-bytes.json','followup-lookup.json',0x14014eb70), ('bytes.json','lookup.json',0x14014fc20)]:
    rows=json.loads((ROOT/capture/byte_name).read_bytes())['result']
    row=next(r for r in rows if int(r['addr'],16)==address)
    raw=bytes(int(x,16) for x in row['data'].split())
    lookup=json.loads((ROOT/capture/lookup_name).read_bytes())['result']
    declared=next(r['fn'] for r in lookup if int(r['fn']['addr'],16)==address)
    assert len(raw)==int(declared['size'],16)
    functions.append({'address':row['addr'],'size':len(raw),'raw':raw,'origin':capture+byte_name+'#result[addr='+row['addr']+']'})

md=Cs(CS_ARCH_X86,CS_MODE_64)
anchors={0x1403a09e8,0x1403a09ef,0x1403a09f6,0x1403a09f8,0x1403a09fe,
         0x14014f787,0x14014f78a,0x14014f794,0x14014f797,0x14014f79d,0x14014f7a9,
         0x14014f7ac,0x14014f7b0,0x14014f7b3,0x14014f7be,0x14014f806,0x14014f80a,
         0x14014ecd2,0x14014ecd9,0x14014fc20,0x14014fc23,0x14014fc25,
         0x14014fd75,0x14014fd7b,0x14014fd98,0x14014fd9b,0x14014fd9d,
         0x14014fdf3,0x14014fdf7,0x14014fdf9,0x14014fdfc,0x14014fdfe,
         0x1403a07c0,0x1403a07c7,0x1403a07cd,0x1403a07eb,0x1403a07ef,
         0x1403a0821,0x1403a0841,0x1403a0843,0x1403a08c4}
seen=set()
for f in functions:
    raw=f.pop('raw'); address=int(f['address'],16)
    assert raw==original_at(address,len(raw)),f['address']
    instructions=list(md.disasm(raw,address))
    assert sum(i.size for i in instructions)==len(raw),f['address']
    f['sha256']=sha(raw);f['originalMatch']=True
    f['instructionCount']=len(instructions)
    f['anchors']=[{'address':hex(i.address),'bytes':bytes(i.bytes).hex(' '),'instruction':i.mnemonic+' '+i.op_str}
                  for i in instructions if i.address in anchors]
    seen.update(i.address for i in instructions if i.address in anchors)
assert seen==anchors,sorted(hex(a) for a in anchors-seen)
report={'status':'CAPTURED_BYTES_MATCH_ORIGINAL','scope':'Bounded call order for the unchanged registered task and same manager instance; no global thread/admission guarantee.',
        'original':{'path':str(EXE),'bytes':len(original),'sha256':sha(original)},
        'functions':functions,'functionCount':len(functions),'extentBytes':sum(f['size'] for f in functions),
        'instructionCount':sum(f['instructionCount'] for f in functions),'anchors':len(anchors)}
(HERE/'scheduler-order.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:report[k] for k in ['status','functionCount','extentBytes','instructionCount','anchors']}))
