from pathlib import Path
import hashlib,json,struct
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SRC=ROOT/'artifacts/motion-production-gap-20261013'
sha=lambda data:hashlib.sha256(data).hexdigest()
load=lambda path:json.loads(path.read_bytes())
manifest=load(SRC/'manifest.json')
assert sha((SRC/'manifest.json').read_bytes())=='5c0285c5d34de7395f3027833484cec0df27ce46ed7698f00b007270044cb73b'
for row in manifest['files']:
    data=(SRC/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
pins=load(SRC/'source-pins.json')
for group in ['sourcePins','evidencePins']:
    for row in pins[group]:
        data=(ROOT/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path']
receipt=load(SRC/'scheduler-order.json')
raw=Path(receipt['original']['path']).read_bytes()
assert sha(raw)==receipt['original']['sha256']=='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
nt=struct.unpack_from('<I',raw,0x3c)[0];opt=nt+24
base=struct.unpack_from('<Q',raw,opt+24)[0]
sections=[struct.unpack_from('<IIII',raw,opt+struct.unpack_from('<H',raw,nt+20)[0]+40*i+8) for i in range(struct.unpack_from('<H',raw,nt+6)[0])]
def pe(address,size):
    rva=address-base
    for vs,start,rs,offset in sections:
        if start<=rva and rva+size<=start+rs:return raw[offset+rva-start:offset+rva-start+size]
    raise AssertionError(hex(address))
md=Cs(CS_ARCH_X86,CS_MODE_64)
anchors=0
for f in receipt['functions']:
    data=pe(int(f['address'],16),f['size'])
    assert sha(data)==f['sha256']
    ins=list(md.disasm(data,int(f['address'],16)))
    assert len(ins)==f['instructionCount'] and sum(i.size for i in ins)==len(data)
    by_addr={i.address:i for i in ins}
    for a in f['anchors']:
        i=by_addr[int(a['address'],16)]
        assert bytes(i.bytes)==bytes.fromhex(a['bytes']) and i.mnemonic+' '+i.op_str==a['instruction']
        anchors+=1
assert anchors==41 and len(receipt['functions'])==6
result={'status':'ACCEPTED','findings':[],'studyManifestSha256':sha((SRC/'manifest.json').read_bytes()),
    'sourcePins':len(pins['sourcePins']),'evidencePins':len(pins['evidencePins']),
    'originalFunctions':6,'originalInstructions':sum(f['instructionCount'] for f in receipt['functions']),
    'originalBodyBytes':sum(f['size'] for f in receipt['functions']),'anchors':anchors,
    'semanticReview':[
        'Root inspected current Pin/Resolve, OnFrame, HookedUpdate and Motion gate/copier source: observation retention is not native memory retention; no production ReadScope/transport is installed.',
        'Root independently inspected IDA bodies3A09C0/3A0790/14FD60/14EB70: registration and Update share global9BA888; context-null callback is synchronous; state!=2 entries can remain after consumer return.',
        'Mask0/value0 selects linked tasks regardless of flags. Accepted call order is explicitly conditional on the same manager, unchanged linked callback/context and normal return.',
        'The remaining resource aliases, worker completion, bootstrap and mutation history are actual requirements; this evidence does not authorize installing a production native read scope.'
    ],
    'scope':'Read-only original-byte, anchor and current-source review. No native execution, builds, synthetic tests, game/GUI/Twitch actions or product edits.'}
(HERE/'review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
