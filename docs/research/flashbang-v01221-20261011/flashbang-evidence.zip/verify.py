"""Offline original-byte/native-ASM/DXBC review. Never calls a game function."""
import argparse,ctypes,hashlib,json,math,pathlib,struct,subprocess
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
from capstone.x86 import X86_OP_IMM,X86_OP_MEM
H=pathlib.Path(__file__).resolve().parent
ROOT=next(p for p in H.parents if (p/'src/KH2Trainer.Core').is_dir())
EXE=pathlib.Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
EXPECTED='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
BASE=0x140000000
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save_or_check(n,v,write):
 p=H/n
 if write:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
 else:assert read(p)==v,n
def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def main(write):
 pe=EXE.read_bytes();assert sha(pe)==EXPECTED
 nt=struct.unpack_from('<I',pe,60)[0];count=struct.unpack_from('<H',pe,nt+6)[0];opt=struct.unpack_from('<H',pe,nt+20)[0]
 secs=[struct.unpack_from('<8sIIII',pe,nt+24+opt+i*40) for i in range(count)]
 def raw(rva,num):
  for _,v,a,s,off in secs:
   if a<=rva and rva-a+num<=s:return pe[off+rva-a:off+rva-a+num]
  raise AssertionError(hex(rva))
 # Every historical file is an exact Git object snapshot, including the disclosed incomplete registration ASM.
 pins=[]
 for p in sorted((H/'historical').glob('*')):
  original=subprocess.check_output(['git','show','ffac525:work/trainer/research/'+p.name],cwd=ROOT)
  assert original==p.read_bytes();pins.append({'path':p.relative_to(H).as_posix(),'sha256':sha(original)})
 cs=Cs(CS_ARCH_X86,CS_MODE_64);cs.detail=True;insmap={};bodies=[]
 for number,rvas in [(3,[0x5061A0]),(2,[0x1268C0]),(0,[0x111AE0]),(10,[0x1219F0])]:
  name=f'historical/render_controls_deep_evidence_{number}.json'
  for rva in rvas:
   f=next(x for x in read(H/name)['functions'] if int(x['addr'],16)==BASE+rva);d=f['disassembly'];ls=d['asm']['lines'];pc=f['pseudocode']
   assert d['cursor']['done'] and d['instruction_count']==d['total_instructions']==len(ls)
   assert pc['cursor']['done'] and not pc.get('truncated') and pc['line_count']==pc['total_lines']
   seq=[];prev=BASE+rva
   for l in ls:
    at=int(l['addr'],16);i=next(cs.disasm(raw(at-BASE,15),at,count=1));assert i.address==at==prev;prev=at+i.size
    for ref in l.get('refs',[]):
     target=int(ref['addr'],16)
     if i.mnemonic in ['jmp','call'] and i.operands[0].type==X86_OP_IMM:assert i.operands[0].imm==target
    insmap[at]=i;seq.append({'addr':hex(at),'ida':l['instruction'],'originalDecode':i.mnemonic+' '+i.op_str,'bytes':bytes(i.bytes).hex(' ')})
   size=prev-(BASE+rva);b=raw(rva,size)
   bodies.append({'addr':hex(BASE+rva),'source':name+'#functions[addr='+f['addr']+']','size':size,'sha256':sha(b),'originalBytes':b.hex(' '),'complete':True,'instructions':seq})
 assert raw(0x5B532C,4)==struct.pack('<f',50.0) and raw(0x5A9CB4,4)==struct.pack('<f',2.2)
 expected={0x5061A0:'movsx',0x5061A7:'cvtdq2ps',0x5061AA:'divss',0x1268D9:'movss',0x1268E1:'addss',0x1268E5:'divss',0x1268EE:'movss'}
 for a,n in expected.items():assert insmap[BASE+a].mnemonic==n
 assert insmap[BASE+0x5061A0].op_str=='eax, cx'
 assert insmap[BASE+0x5061B2].operands[0].imm==BASE+0x1268C0
 assert insmap[BASE+0x1268D9].operands[0].mem.disp==716 and insmap[BASE+0x1268EE].operands[0].mem.disp==23360
 # Setter scalar arithmetic and ABI: a positive short never crosses a denominator singularity.
 levels=[];sample_inputs=[0,1/255,0.01,0.1,0.5,1]
 for level in [-50,0,50,500,1000,5000,32767]:
  assert struct.unpack('<h',struct.pack('<h',level))[0]==level
  adjustment=f32(f32(level)/f32(50));denominator=f32(adjustment+f32(2.2));gamma=f32(f32(2.2)/denominator)
  assert math.isfinite(adjustment) and math.isfinite(gamma) and denominator>0 and gamma>0
  outputs=[0 if x==0 else x**gamma for x in sample_inputs]
  assert outputs==sorted(outputs) and all(0<=v<=1 for v in outputs)
  if level>=0:assert all(v>=x-1e-12 for x,v in zip(sample_inputs,outputs))
  levels.append({'level':level,'adjustmentFloat32':adjustment,'denominatorFloat32':denominator,'inverseGammaFloat32':gamma,'idealShaderInputs':sample_inputs,'idealShaderOutputsBeforeColorCorrection':outputs})
 assert next(x for x in levels if x['level']==5000)['adjustmentFloat32']==100
 assert f32(f32(f32(-110)/50)+f32(2.2))==0
 assert struct.unpack('<h',struct.pack('<H',32768))[0]==-32768
 # Shader disassembly is offline, using the installed Microsoft library against immutable original bytes.
 header=raw(0x5A4550,32);assert header[:4]==b'DXBC';size=struct.unpack_from('<I',header,24)[0];shader=raw(0x5A4550,size)
 assert size==9988 and shader==(H/'final-pixel-shader.dxbc').read_bytes()
 dllpath=pathlib.Path(r'C:\Windows\System32\D3DCompiler_47.dll');dll=ctypes.WinDLL(str(dllpath));fn=dll.D3DDisassemble
 fn.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_uint,ctypes.c_char_p,ctypes.POINTER(ctypes.c_void_p)];fn.restype=ctypes.c_long
 src=ctypes.create_string_buffer(shader);out=ctypes.c_void_p();assert fn(src,len(shader),0,None,ctypes.byref(out))==0
 vt=ctypes.cast(out,ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
 ptr=ctypes.WINFUNCTYPE(ctypes.c_void_p,ctypes.c_void_p)(vt[3])(out);n=ctypes.WINFUNCTYPE(ctypes.c_size_t,ctypes.c_void_p)(vt[4])(out)
 asm=ctypes.string_at(ptr,n).rstrip(b'\0');ctypes.WINFUNCTYPE(ctypes.c_ulong,ctypes.c_void_p)(vt[2])(out)
 assert asm==(H/'final-pixel-shader.asm').read_bytes();text=asm.decode('utf-8')
 required=['float inverseGamma;                // Offset:   60 Size:     4','log r1.xyz, r0.xyzx','mul r1.xyz, r1.xyzx, cb6[3].wwww','exp r0.xyz, r1.xyzx','if_nz cb6[4].x','mov o0.xyzw, r0.xyzw']
 positions=[text.index(x) for x in required];assert positions==sorted(positions)
 assert text.count('cb6[3].wwww')==1
 # Historical registration is deliberately not counted as a complete ASM body.
 reg=next(x for x in read(H/'historical/render_deep_evidence_pagination.json') if x['addr']=='0x14011e1d0')
 limitation={'addr':reg['addr'],'reportedInstructions':reg['asm']['instruction_count'],'actualAsmLines':len(reg['asm']['asm']['lines']),'completeAsmAccepted':False}
 assert limitation['actualAsmLines']==10 and limitation['reportedInstructions']==1903
 fresh=read(H/'root-disasm-0x14011e1d0.json');fresh=fresh.get('structuredContent',fresh)
 assert fresh['total_instructions']==1903 and len(fresh['asm']['lines'])==10
 # Fresh explicit range queries repair only the required connection, not the full body.
 ranges=[]
 q=read(H/'root-insn-final-shader-ranges.json');q=q.get('structuredContent',q)
 bq=read(H/'root-bytes-final-shader.json');bq=bq.get('structuredContent',bq)
 for x in bq['result']:
  b=bytes(int(z,16) for z in x['data'].split());assert raw(int(x['addr'],16)-BASE,len(b))==b
 for x in q['result']:
  start=int(x['query']['start'],16);end=int(x['query']['end'],16);b=raw(start-BASE,end-start);decoded=list(cs.disasm(b,start))
  assert not x['truncated'] and x['cursor']['done'] and x['count']==x['scanned']==len(x['matches'])==len(decoded)
  assert sum(i.size for i in decoded)==len(b)
  for i,l in zip(decoded,x['matches']):assert i.address==int(l['addr'],16);insmap[i.address]=i
  lines=[{'addr':l['addr'],'instruction':l['disasm']} for l in x['matches']]
  ranges.append({'addr':hex(start),'end':hex(end),'size':len(b),'complete':True,'observed_line_count':len(lines),'asm':{'lines':lines},'disassembly':{'asm':{'lines':lines},'cursor':{'done':True}},'originalBytes':b.hex(' '),'sha256':sha(b),'independentDecode':[{'addr':hex(i.address),'instruction':i.mnemonic+' '+i.op_str,'bytes':bytes(i.bytes).hex(' ')} for i in decoded]})
 assert [(r['addr'],r['size']) for r in ranges]==[('0x14011f96c',56),('0x14011fdff',75)]
 def rip(at):
  i=insmap[BASE+at];o=i.operands[1];assert o.type==X86_OP_MEM and i.reg_name(o.mem.base)=='rip';return i.address+i.size+o.mem.disp
 assert rip(0x11F998)==BASE+0x5A4550 and rip(0x11FE36)==BASE+0x59AC40
 assert insmap[BASE+0x11F993].operands[1].imm==9988
 assert insmap[BASE+0x11F989].operands[1].mem.disp==31720
 assert insmap[BASE+0x11FDFF].operands[1].mem.disp==31736+552*47==57680
 assert insmap[BASE+0x11FE06].operands[1].mem.disp==31720
 assert insmap[BASE+0x11FE0D].op_str=='qword ptr [rdi + 8], rax'
 assert insmap[BASE+0x112007].operands[1].mem.disp==23300 and 23300+60==23360
 assert insmap[BASE+0x112014].operands[1].imm==80 and insmap[BASE+0x1120F0].operands[1].imm==3
 assert insmap[BASE+0x121BEB].operands[1].imm==47
 assert insmap[BASE+0x121C26].operands[1].imm==5 and insmap[BASE+0x121C2B].operands[1].mem.disp==42
 save_or_check('native-evidence.json',{'functions':bodies,'code_ranges':ranges,'historicalSourcePins':pins,'excludedHistoricalRegistrationAsm':limitation,'excludedFreshRegistrationAsm':{'reportedInstructions':1903,'actualAsmLines':10,'completeAsmAccepted':False}},write)
 result={'status':'PASS','originalSha256':EXPECTED,'nativeBodies':len(bodies),'originalInstructions':sum(len(x['instructions']) for x in bodies),'extentBytes':sum(x['size'] for x in bodies),'dedicatedRegistrationRanges':len(ranges),'rangeInstructions':sum(x['observed_line_count'] for x in ranges),'rangeBytes':sum(x['size'] for x in ranges),'shader':{'addr':'0x1405a4550','bytes':size,'sha256':sha(shader),'disassemblySha256':sha(asm),'disassemblerSha256':sha(dllpath.read_bytes())},'arithmeticCases':levels,'boundaries':{'nativeSignedShortPositiveMaximum':32767,'recommendedProductPositiveMaximum':5000,'unchangedNegativeMinimum':-50,'menuMaximumIsPolicyNotSetterClamp':50,'denominatorZeroAtLevel':-110,'firstPositiveInt16OverflowAt':32768},'limits':['Ideal shader numbers are not GPU measurements; optional color correction occurs afterwards.','No game calls, process access, renderer writes, or GPU execution.','This review supports scalar bounds; existing thread/mutex/lifetime/restore requirements remain.']}
 save_or_check('verification.json',result,write)
 print(json.dumps({k:v for k,v in result.items() if k!='arithmeticCases'},indent=2))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--write',action='store_true');ap.add_argument('--check',action='store_true');main(ap.parse_args().write)
