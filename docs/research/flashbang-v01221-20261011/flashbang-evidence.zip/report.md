# Flashbang: begründeter Helligkeitswert 5000

**Empfehlung: Flashbang auf 5000 setzen und die positive Previewgrenze auf 5000 erweitern; die negative Grenze -50 beibehalten.** Dieser Wert ist im echten signed-int16-ABI darstellbar und erzeugt einen positiven, endlichen Shaderexponenten. Er ist eine bewusst gewählte Produktgrenze oberhalb des Spielmenüs, keine native Clampgrenze und kein behauptetes physisches Helligkeitsmaximum.

## Originalpfad

- `5061A0`: sign-extended `CX` → Float32 → Division durch originale Konstante50 → Tailcall `1268C0`.
- `1268C0`: `adjustment=level/50` nach `GX+716`; `inverseGamma=2.2/(adjustment+2.2)` nach `GX+23360`. Kein Wertclamp, keine indizierte Speicheradressierung anhand der Helligkeit.
- `111AE0`: vergleicht/kopiert den 80-Byte-PS-Konstantenblock ab `GX+23300`, einschließlich Gamma bei Offset60; bindet die GPU-Kopie an Rootparameter3. Ein besonderer Flush oder weiterer Dirty-Write ist nicht nötig.
- Frische vollständige Codebereiche `11F96C..11F9A4` und `11FDFF..11FE4A` verbinden Pixelblob `5A4550` mit Slot20 (`GX+31720`) und Program47 (`GX+31736+552*47`, Pixelzeiger+8). Die vollständige historische Präsentationsroutine `1219F0` wählt Target5/Program47.
- Das originale 9988-Byte-DXBC wurde offline mit Microsoft `D3DDisassemble` erneut dekodiert. Es liest Gamma aus `cb6[3].w` und führt `log RGB → multiply gamma → exp RGB` aus. Alpha wird nicht mit Gamma verändert. Die optionale Farbkorrektur folgt danach und benutzt weiterhin nur ihre separaten Modus-/Stärkefelder.

Die Shaderinstruktionen arbeiten zur Basis2; zusammen ergibt sich `RGB^inverseGamma`. Null wird über `log(0)=-∞` und `exp(-∞)=0` wieder null. Das entspricht den dokumentierten [log](https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/log--sm4---asm-)- und [exp](https://learn.microsoft.com/en-us/windows/win32/direct3dhlsl/exp--sm4---asm-)-Grenzfällen. Die Modellwerte unten sind ideale Arithmetik mit dem originalen Float32-Gamma, keine GPU- oder Bildschirmmessung.

## Wirkung und Grenzen

| Level | Gamma | Eingang0,01 | Eingang0,1 | Eingang0,5 |
|---:|---:|---:|---:|---:|
| 50 | 0,6875 | 0,0422 | 0,2054 | 0,6209 |
| 1000 | 0,09910 | 0,6336 | 0,7960 | 0,9336 |
| **5000** | **0,02153** | **0,9056** | **0,9516** | **0,9852** |
| 32767 | 0,003346 | 0,9847 | 0,9923 | 0,9977 |

5000 hebt auch dunkle, positive Farbwerte deutlich an. Es garantiert kein flächiges Weiß: Schwarz bleibt schwarz, sehr kleine Werte bleiben unterscheidbar, und nachgeschaltete Farbkorrektur kann das Resultat ändern. Es verändert die finale Bildkorrektur einschließlich UI, nicht Szenenlicht, HDR-Nits oder eine zusätzliche weiße Overlayfläche.

Für alle nichtnegativen signed-short-Werte bis32767 liegt der Nenner zwischen ungefähr2,2 und657,54 und Gamma bleibt positiv/endlich. 32767 ist lediglich die technische positive ABI-Grenze. Ab32768 würde ein ungeprüfter Shortcast negativ umbrechen. Auf der negativen Seite liegt die Singularität bei Level-110; die bestehende Produktuntergrenze-50 bleibt davon entfernt. Der empfohlene Bereich[-50,5000] hält `adjustment` in[-1,100] und Gamma ungefähr in[0,0215264,1,8333333]. Die bestehenden Lebensdauer-, Thread-, Signatur-, Konstanten- und Mutexprüfungen bleiben erforderlich.

## Produktanschlüsse für Root

1. Command304 akzeptiert nur ganze, endliche Werte[-50,5000]. Flashbang fordert einmal5000 an; Dauer und bestehende Rücknahme bleiben erhalten.
2. Snapshot304 muss den erweiterten Adjustmentbereich bis100 unterstützen. Sonst verschwindet der aktuelle Wert während des Effekts und die bestehende Rücknahme kann ihren Besitzvergleich nicht durchführen. Die Rücklesung soll einen exakten Integer nur dann veröffentlichen, wenn der native Float genau der erwarteten `float(level)/50`-Repräsentation entspricht.
3. Loaded-Settings können weiter gesondert auf den tatsächlichen Menübereich[-50,50] begrenzt bleiben. Die Erweiterung braucht weder Settingswrites noch geänderte Farbkorrektur.
4. Native-/Managed-/Twitch-Tests sollen5000, beide neuen Grenzen, Brüche/NaN/Inf und Rücknahme nach dem Effekt prüfen. Diese Notiz ersetzt den separaten Implementierungsreview nicht.

## Evidenzqualität / Reproduktion

Vier vollständige historische Bodies sind gegen das originale PE neu dekodiert: 576 Instruktionen /2638 Bytes. Zwei frische IDA-Instruktionsqueries sind vollständig:11+17 Instruktionen /131 Bytes. Shader-SHA256: `da4cdaa946e6d7c74e2d27d52931eb29b39fb97e13ed4fc835eda447b39d428e`. Sieben ausgewählte Arithmetikfälle und die zwei ABI-/Singularitätsgrenzen werden reproduziert.

Sowohl die historische als auch die frische normale `11E1D0`-Disasmantwort melden1903 Instruktionen und `cursor.done`, enthalten aber nur10 ASM-Zeilen. Beide bleiben als Toolbefund erhalten und werden **nicht** als vollständiger Funktionskörper gezählt. Die beiden gezielten Queries schließen ausschließlich den benötigten Shaderanschluss. Die historische Pseudocodepaginierung ist separat vollständig; globale IDA-Autoanalyse war laut Root weiterhin nicht bereit. Keine IDB-Änderung und kein Erzwingen von Analyse.

```powershell
py -3 -B artifacts/flashbang-brightness-review-20261011/verify.py --check
py -3 -B artifacts/flashbang-brightness-review-20261011/freeze.py --check
```

Keine Spielaufrufe, GPU-Ausführung, Prozesszugriffe, Produktedits oder visuelle Liveprüfung. Der Windows-Disassembler wird ausschließlich als Offlineparser für Originalbytes verwendet.
