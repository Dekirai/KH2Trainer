"""Independent original-PE review. Writes only this review directory."""
from pathlib import Path
import hashlib,json,struct
from capstone import Cs,CS_ARCH_X86,CS_MODE_64
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
STUDY=ROOT/'artifacts/actor-contact-retirement-20261013'
ORIGINAL=Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
raw=ORIGINAL.read_bytes();original_hash=sha(raw)
assert original_hash=='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
pe=struct.unpack_from('<I',raw,0x3c)[0];opt=pe+24
assert raw[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',raw,opt)[0]==0x20b
base=struct.unpack_from('<Q',raw,opt+24)[0];assert base==0x140000000
section_count=struct.unpack_from('<H',raw,pe+6)[0]
sections_at=opt+struct.unpack_from('<H',raw,pe+20)[0]
sections=[struct.unpack_from('<IIII',raw,sections_at+40*i+8) for i in range(section_count)]
def read(rva,size):
    for _,start,n,offset in sections:
        if start<=rva and rva+size<=start+n:
            data=raw[offset+rva-start:offset+rva-start+size]
            assert len(data)==size
            return data
    raise AssertionError((hex(rva),size))
evidence=load(STUDY/'evidence.json');claimed=load(STUDY/'verification.json')
assert evidence['originalSha256']==claimed['originalSha256']==original_hash
assert len(evidence['functions'])==len({f['addr'] for f in evidence['functions']})==30
decoder=Cs(CS_ARCH_X86,CS_MODE_64)
records=[];fresh_capture_hashes={}
for f in evidence['functions']:
    addr=int(f['addr'],16);size=f['size'];data=read(addr-base,size)
    assert bytes.fromhex(f['originalBytes'])==data and f['sha256']==sha(data)
    assert not f['noncode']
    decoded=list(decoder.disasm(data,addr))
    assert sum(i.size for i in decoded)==size and len(decoded)==len(f['instructions'])
    assert [i.address for i in decoded]==[int(i['addr'],16) for i in f['instructions']]
    assert [i.bytes.hex() for i in decoded]==[i['bytes'] for i in f['instructions']]
    assert [i.mnemonic+' '+i.op_str for i in decoded]==[i['instruction'] for i in f['instructions']]
    if f['captureKind']=='fresh':
        query_path=STUDY/f['origin'];query=load(query_path)['result'][0]
        assert query['cursor']=={'done':True} and not query.get('truncated') and not query.get('error')
        assert query['count']==query['scanned']==len(decoded)
        assert [int(i['addr'],16) for i in query['matches']]==[i.address for i in decoded]
        assert query['ranges']==[{'start':hex(addr),'end':hex(addr+size)}]
        fresh_capture_hashes[str(query_path.relative_to(STUDY))]=sha(query_path.read_bytes())
    records.append({'addr':f['addr'],'captureKind':f['captureKind'],'bytes':size,'instructions':len(decoded),'sha256':sha(data)})
for dependency in evidence['dependencies']:
    assert sha((ROOT/dependency['path']).read_bytes())==dependency['sha256']
groups={}
for kind in ('fresh','reused'):
    fs=[x for x in records if x['captureKind']==kind]
    groups[kind]={'functions':len(fs),'instructions':sum(x['instructions'] for x in fs),'bodyBytes':sum(x['bytes'] for x in fs),'instructionBytes':sum(x['bytes'] for x in fs),'noninstructionBytes':0}
assert groups==claimed['counts']
tables=load(STUDY/'original-tables.json')
assert tables['originalSha256']==original_hash
assert tables['tables']==evidence['tables']
for t in tables['tables']:
    data=read(int(t['rva'],16),t['size'])
    assert data==bytes.fromhex(t['bytes'])
    assert [{'offset':hex(i*8),'value':hex(v[0])} for i,v in enumerate(struct.iter_unpack('<Q',data))]==t['cells']
assert sum(t['size'] for t in tables['tables'])==claimed['dataBytes']==360
for rva in (0x5c5ef0,0x5c60a0,0x5c6250):
    for offset,target in ((0,0x3d2720),(56,0x3d2850),(64,0x3d28b0),(72,0x3d28c0)):
        assert int.from_bytes(read(rva+offset,8),'little')==base+target
assert int.from_bytes(read(0x74c380,8),'little')==base+0x5c6250
# The attack vtable binding is an existing explicit dependency, not another
# function claim or an addition to the study's360 data-byte count.
prior=load(ROOT/'docs/research/attack-object-ownership-20261011/evidence.json')
atk=next(x for x in prior['data'] if int(x['addr'],16)==base+0x5ce6c0)
attack_table=read(0x5ce6c0,32)
assert bytes.fromhex(atk['originalBytes'])==attack_table and atk['sha256']==sha(attack_table)
assert int.from_bytes(attack_table[:8],'little')==base+0x40f4c0
for rva in (0x39c83e,0x3bf92b):
    call=read(rva,5)
    assert call[0]==0xe8 and rva+5+struct.unpack_from('<i',call,1)[0]==0x3cfed0
manifest_path=STUDY/'manifest.json';manifest=load(manifest_path)
manifest_sha=sha(manifest_path.read_bytes())
assert manifest_sha=='88493aa0b4b8ad402421a24d696fd71a51249d74eeb29af0e141412b9f4da2c7'
assert manifest['selfExcluded'] and len(manifest['files'])==48
for row in manifest['files']:
    path=(STUDY/row['path']).resolve()
    assert path.is_relative_to(STUDY.resolve())
    data=path.read_bytes();assert len(data)==row['size'] and sha(data)==row['sha256']
assert {r['path'] for r in manifest['files']}=={str(p.relative_to(STUDY)).replace('\\','/') for p in STUDY.rglob('*') if p.is_file() and p!=manifest_path}
final_report=load(STUDY/'report.json')
assert len(final_report['claims'])==6 and all(all(k in c for k in ('Finding','Evidence','Limitations')) for c in final_report['claims'])
assert final_report['verification']['total']=={'functions':30,'instructions':1519,'bodyBytes':6159,'noninstructionBytes':0}
assert final_report['verification']['semanticAnchors']==claimed['semanticAnchors']==len(evidence['anchors'])==20
review={
 'status':'PASS','scope':'Independent original-byte and data-cell comparison plus manual bounded dataflow review. No semantic VM, native execution or complete lifetime claim.',
 'originalSha256':original_hash,'counts':groups,'functionCount':len(records),'bodyBytes':sum(x['bytes'] for x in records),'instructions':sum(x['instructions'] for x in records),'dataBytes':360,
 'authorManifestSha256':manifest_sha,'authorManifestFileCount':48,'finalStructuredClaimCount':6,'unresolvedFindings':[],
 'functions':records,'freshCaptureHashes':fresh_capture_hashes,
 'dependencyHashes':evidence['dependencies'],'sourceHashes':{str(p.relative_to(STUDY)).replace('\\','/'):sha(p.read_bytes()) for p in STUDY.rglob('*') if p.is_file()},
 'semanticReview':[
  {'claim':'Mark consumer and decrement path','finding':'The first contact-list pass saves Decode(object+196), tests bit11 at object+8, and calls virtual0(object,1) for marked entries. Original ATTACK_OBJ table5CE6C0 slot0=40F4C0; that body clears QWORD[QWORD(object+720)], calls3CFB10 and for flag1 dispatches152570. Base cleanup decrements nonnull decoded object+12 and+20 at Actor+1464 and unlinks the contact. These are distinct local operations, not a universal lease protocol.'},
  {'claim':'Counter0 eligibility precedes normal retirement flag','finding':'3BFD30 only calls descriptor+72 after descriptor+64 returns nonzero while bit28 at Actor+288 is set. Original5C6250 slots route via3D28B0 to3DAC30 then3B4420: after optional VM/motion work, Actor DWORD+1464 must equal0. Both +128 and+152 nonnull jointly reject; voice may also reject. 3D28C0 then3B45C0 clears bit28 and sets bit19/0x80000. No second counter test occurs in that flag writer or the dead-list consumer.'},
  {'claim':'Selected descriptor identity and later dead-list destruction','finding':'3D2DA0 encodes original descriptor74C380 into Actor DWORD0, after manager initialization; original74C380 QWORD0=5C6250 and slot0=3D2720. 3BF300 processes the prior dead list through descriptor0 before moving flagged active actors into the new dead list. An actor newly moved by this invocation is not freed by the earlier loop of the same invocation. Later calls, including3BF4C0 calling twice, preclude a blanket full-frame delay claim. Final derived descriptors and arbitrary direct/bulk paths remain separate.'},
  {'claim':'Task publication and dispatch','finding':'3D0110 passesflags1,priority21000,callback3CFF40 to1506B0, which forwards with manager716868 to14F770. The task stores callback+0,flags+96,priority+100 and nullcontext+112; list insertion is ascending by signed priority. 14FD60 applies its flag filter before directly calling tasks with nullcontext; nonnull context follows the separate fiber branch. Registration does not by itself prove an uninterrupted callback schedule.'},
  {'claim':'Later callback receiver exchange','finding':'3D06E0 traverses the contact list, compares Decode(object+16) to old, and writes Encode(new) only for matches. Its body has no writes to object+12/+20 or Actor+1464.40D000 directly invokes it at40D448 using context oldactor and RDI newactor, before the wait loop checking oldactor membership. Opaque callees and arbitrary later writes remain outside the claim.'},
 ],
 'limits':['The descriptor/callee sequence assumes the documented original table bindings remain current; derived or changed descriptors are not generalized.','Global/free/heap teardown, task cancellation, concurrency, all counter writers and owner-cell reuse identity are not proven.','Task flags and scheduler progress are prerequisites; no fixed delay in milliseconds or frames is proved.','No product, docs, package, IDB, game, injection, save or Twitch mutation was performed.'],
 'verificationAssessment':'Study verify.py verifies original bytes, IDA boundaries/mnemonics, explicit dependency hashes, data cells and selected static anchors. These checks do not execute branch scenarios or prove global semantic safety.'}
(HERE/'review.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:review[k] for k in ['status','functionCount','bodyBytes','instructions','dataBytes']}))
