# Review: Kontaktmarkierung und spätere Actorfreigabe

**Die untersuchte normale Descriptorfolge ist belegt.** Sie begründet keine allgemeine Freigabesicherheit.

Der unabhängige Prüfer liest die Original-EXE direkt. Alle **30 Körper mit 1.519 Instruktionen und 6.159 Bytes** stimmen mit der Evidenz überein: 14 frische Körper mit 433 Instruktionen/1.828 Bytes sowie 16 wiederverwendete Körper mit 1.086 Instruktionen/4.331 Bytes. Die **360 Bytes** der aufgenommenen Tabellen und Descriptorzelle stimmen ebenfalls. Die bereits vorher aufgenommene `ATTACK_OBJ`-Vtable wurde zusätzlich gegen die ursprüngliche Abhängigkeit und Original-PE geprüft.

## Bestätigte Zusammenhänge

- `3CFF40` bewahrt den nächsten Kontaktlink, prüft `0x800` und ruft für markierte Kontakte `virtual0(object,1)` auf. Die ursprüngliche `ATTACK_OBJ`-Tabelle führt zu `40F4C0`. Dieser Pfad leert die gespeicherte äußere Zelle und ruft `3CFB10` auf; dort werden die beiden nichtnull dekodierten Actorreferenzen bei `+1464` dekrementiert. Aliasing führt lokal zu zwei Dekrementen.
- `3BFD30` ruft Slot+72 nur nach erfolgreichem Slot+64 auf. Für `74C380 → 5C6250` führt die Zulassung über `3D28B0` und `3DAC30` zu `3B4420`. Nach möglicher VM-/Motionarbeit muss der Zähler null sein. Wenn **beide** Bindungen bei +128 und +152 vorhanden sind, wird ebenfalls abgelehnt. Eine aktive Voice kann zusätzlich verzögern.
- Der zugelassene Pfad setzt schließlich `0x80000`. `3BF300` verarbeitet die bisherige Dead-List vor dem Verschieben neuer markierter Actors. Damit entsteht eine Reihenfolge zwischen Aufrufen, keine garantierte Wartezeit in Frames. Insbesondere ruft `3BF4C0` denselben Verbraucher zweimal auf.
- Die statische Descriptorzelle, ihr Store in `3D2DA0` und Slot0→`3D2720` passen zusammen. Für später ersetzte oder abgeleitete Descriptoren ist diese Gleichsetzung nicht automatisch zulässig.
- Der Kontaktcallback wird mit Flags1/Priorität21000 in den Feld-Taskmanager eingetragen. Der Task startet ohne Fiberkontext. Der Scheduler kann passende Tasks ohne Kontext direkt aufrufen; sein Flagfilter und tatsächlicher Fortschritt bleiben Voraussetzungen.
- `3D06E0` ersetzt passende dekodierte Verweise bei Kontakt+16. Es verändert lokal weder +12/+20 noch Actor+1464. Der Drivepfad ruft es mit dem bisherigen und dem neu konstruierten Actor auf, bevor er auf das Ausscheiden des alten Actors wartet.

## Aussagegrenzen

Eine frühere Markierungsanforderung allein beweist keine erfolgte Markierung. Der Zählernulltest liegt auf dem beschriebenen Updatepfad; der Destruktor, der finale Flagwriter und der Dead-List-Verbraucher testen ihn nicht erneut. Andere direkte Pfade, ganze Heapfreigaben, zwischenzeitliche Writer, Taskabbrüche und Zellwiederverwendung sind dadurch nicht abgesichert.

Die Verifikation bindet Originalbytes, Instruktionsgrenzen und statische Belege. Sie führt keine semantische VM aus und beweist weder sämtliche Aufrufer noch globale Lebensdauerregeln. Kein Use-after-free wird aus diesen Befunden behauptet und keine rohe Löschfunktion wird zur Implementierung freigegeben.

Nur dieser Reviewordner wurde verändert. Produkt, Paket, Dokumentation, IDB und Spiel blieben unverändert. Die geprüften Quellenhashes stehen in `review.json`.

## Abschluss

Die sechs finalen strukturierten Aussagen und die korrigierten Formulierungen wurden akzeptiert. Es verbleiben keine Review-Findings. Der eigene Originalvergleich und `verify.py --check` der Studie endeten beide mit PASS. Alle 48 Dateien des eingefrorenen Autorenmanifests wurden auf Größe und Hash geprüft; sein SHA-256 lautet `88493aa0b4b8ad402421a24d696fd71a51249d74eeb29af0e141412b9f4da2c7`.
