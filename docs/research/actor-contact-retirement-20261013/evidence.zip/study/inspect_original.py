import hashlib, json, struct
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
SHA='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
raw=SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest()==SHA
nt=struct.unpack_from('<I',raw,0x3c)[0]
opt=nt+24
base=struct.unpack_from('<Q',raw,opt+24)[0]
sections=[struct.unpack_from('<IIII',raw,opt+struct.unpack_from('<H',raw,nt+20)[0]+40*i+8)
          for i in range(struct.unpack_from('<H',raw,nt+6)[0])]
def read(rva,size):
    for virtualsize,start,rawsize,offset in sections:
        if start<=rva and rva+size<=start+rawsize:
            return raw[offset+rva-start:offset+rva-start+size]
    raise ValueError(hex(rva))

if __name__=='__main__':
    tables=[]
    for rva,size in ((0x5C5EF0,0x58),(0x5C60A0,0x58),(0x5C6250,0x58),(0x5C4F10,0x58),(0x74C380,8)):
        data=read(rva,size)
        tables.append({'rva':hex(rva),'size':size,'bytes':data.hex(' '),
                       'cells':[{'offset':hex(i*8),'value':hex(x[0])} for i,x in enumerate(struct.iter_unpack('<Q',data))]})
    (HERE/'original-tables.json').write_text(json.dumps({'originalSha256':SHA,'tables':tables},indent=2)+'\n')
    print(json.dumps(tables,indent=2))
