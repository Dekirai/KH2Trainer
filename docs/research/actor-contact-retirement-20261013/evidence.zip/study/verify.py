"""Bounded original-instruction and data verification; no native execution."""
import argparse, hashlib, json, re
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_64
from inspect_original import ROOT, HERE, SHA, base, read

parser=argparse.ArgumentParser()
parser.add_argument('--check',action='store_true')
options=parser.parse_args()
load=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
number=lambda x:int(x,16) if isinstance(x,str) else x
def octets(s):
    return bytes(int(x,16) for x in s.split()) if '0x' in s else bytes.fromhex(s)
def output(name,value):
    data=(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
    path=HERE/name
    if options.check:assert path.read_bytes()==data,name
    else:
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)

decoder=Cs(CS_ARCH_X86,CS_MODE_64)
aliases={'retn':'ret','jz':'je','jnz':'jne','jnb':'jae','jna':'jbe','jnl':'jge','jng':'jle',
         'cmovz':'cmove','cmovnz':'cmovne','setz':'sete','setnz':'setne','setnb':'setae','sal':'shl'}
inventory={number(x['address']):x for line in (ROOT/'docs/research/coverage/function_status.jsonl').read_text().splitlines()
           if (x:=json.loads(line))['domain']=='native'}
functions=[]
def validate(addr,size,data,rows,origin,kind):
    assert len(data)==size and read(addr-base,size)==data,(hex(addr),'original bytes')
    assert inventory[addr]['size']==size,(hex(addr),'inventory extent')
    instructions=[];noncode=[]
    assert number(rows[0]['addr'])==addr
    for index,row in enumerate(rows):
        position=number(row['addr'])
        end=number(rows[index+1]['addr']) if index+1<len(rows) else addr+size
        assert addr<=position<end<=addr+size
        text=row.get('disasm',row.get('instruction'))
        mnemonic=text.split()[0]
        original=data[position-addr:end-addr]
        if mnemonic in ('align','db','dw','dd','dq'):
            noncode.append({'addr':hex(position),'size':len(original),'bytes':original.hex(),'ida':text})
            continue
        insn=next(decoder.disasm(original,position,count=1))
        assert insn.size==len(original),(hex(position),text,insn.size,len(original))
        alias_nop=mnemonic=='xchg' and original==b'\x66\x90' and insn.mnemonic=='nop'
        assert alias_nop or aliases.get(mnemonic,mnemonic)==insn.mnemonic,(hex(position),text,insn.mnemonic)
        instructions.append({'addr':hex(position),'bytes':original.hex(),'instruction':insn.mnemonic+' '+insn.op_str,'ida':text})
    assert sum(len(bytes.fromhex(x['bytes'])) for x in instructions+noncode)==size
    functions.append({'addr':hex(addr),'size':size,'sha256':sha(data),'origin':origin,'captureKind':kind,
                      'originalBytes':data.hex(),'instructions':instructions,'noncode':noncode})

capture=HERE/'root-capture'
captured={}
for path in sorted(capture.glob('*bytes.json')):
    for row in load(path)['result']:
        addr=number(row['addr']);data=octets(row['data'])
        if addr in captured:assert captured[addr]==data
        captured[addr]=data
for path in sorted(capture.glob('*-insns*.json')):
    query=load(path)['result'][0]
    assert query['cursor']=={'done':True} and not query.get('truncated') and not query.get('error')
    assert query['count']==query['scanned']==len(query['matches'])
    assert len(query['ranges'])==1
    span=query['ranges'][0];addr=number(span['start']);size=number(span['end'])-addr
    assert addr in captured
    validate(addr,size,captured[addr],query['matches'],str(path.relative_to(HERE)),'fresh')

reuses={
    'actor-lifetime-20261007':[0x3BF300,0x3B4E80,0x3D2DA0,0x40D000],
    'voice-request-lifecycle-20261008':[0x3DAC30,0x3B4420,0x3BFD30,0x14F770,0x14FC20,0x14FD60],
    'attack-owner-cell-20261013':[0x3D2720,0x3D24B0,0x3D0EB0],
    'attack-object-ownership-20261011':[0x40F4C0,0x40F4A0,0x3CFB10],
}
dependencies=[]
for study,rvas in reuses.items():
    path=ROOT/'docs/research'/study/'evidence.json'
    evidence=load(path)
    selected=[f for f in evidence['functions'] if number(f['addr'])-base in rvas]
    assert len(selected)==len(rvas),study
    for f in selected:
        addr=number(f['addr']);size=f['size']
        if 'original_bytes' in f:
            data=b''.join(octets(x['data']) for x in f['original_bytes'])
        else:data=octets(f['originalBytes'])
        if 'asm' in f:rows=f['asm']['lines']
        elif 'disassembly' in f:rows=f['disassembly']['asm']['lines']
        else:rows=[r for p in f['pages'] for r in p['asm']['lines']]
        validate(addr,size,data,rows,f'docs/research/{study}/evidence.json#functions[addr={hex(addr)}]','reused')
    dependencies.append({'path':str(path.relative_to(ROOT)).replace('\\','/'),'sha256':sha(path.read_bytes()),
                         'functions':[hex(base+x) for x in rvas]})

tables=load(HERE/'original-tables.json')
assert tables['originalSha256']==SHA
for table in tables['tables']:
    assert read(number(table['rva']),table['size'])==bytes.fromhex(table['bytes'])
for rva in (0x5C5EF0,0x5C60A0,0x5C6250):
    assert int.from_bytes(read(rva,8),'little')==base+0x3D2720
    assert int.from_bytes(read(rva+56,8),'little')==base+0x3D2850
    assert int.from_bytes(read(rva+64,8),'little')==base+0x3D28B0
    assert int.from_bytes(read(rva+72,8),'little')==base+0x3D28C0
assert int.from_bytes(read(0x74C380,8),'little')==base+0x5C6250

instructions={int(i['addr'],16):i for f in functions for i in f['instructions']}
requirements={
    0x3B2EBC:('cmp', '0x5b8'),0x3B444C:('cmp','0x5b8'),
    0x3BFD6B:('call','0x40'),0x3BFD83:('call','0x48'),
    0x3B46E9:('mov','0x120'),0x3BF34B:('call','[r8]'),
    0x3BF3BB:('je',''),0x3CFFF9:('call','[rax]'),0x3D0002:('call','0x18'),
    0x3D013D:('call','0x1401506b0'),0x40D448:('call','0x1403d06e0'),
    0x3CFB41:('dec','0x5b8'),0x3CFB5C:('dec','0x5b8'),
    0x3D286D:('call','0x1403d24b0'),0x3D28AA:('jmp','0x1403b4700'),
    0x3BF4C6:('call','0x1403bf300'),0x3BF4D1:('jmp','0x1403bf300'),
    0x3BF81D:('mov','0x4e20'),0x3BF877:('mov','0x16378'),
    0x3BF88D:('mov','0x68'),
}
anchors=[]
for rva,(mnemonic,operand) in requirements.items():
    i=instructions[base+rva]
    assert i['instruction'].split()[0]==mnemonic and operand in i['instruction'],i
    anchors.append(i)

groups={}
for kind in ('fresh','reused'):
    fs=[f for f in functions if f['captureKind']==kind]
    groups[kind]={'functions':len(fs),'instructions':sum(len(f['instructions']) for f in fs),
                  'bodyBytes':sum(f['size'] for f in fs),
                  'instructionBytes':sum(len(bytes.fromhex(i['bytes'])) for f in fs for i in f['instructions']),
                  'noninstructionBytes':sum(x['size'] for f in fs for x in f['noncode'])}
output('evidence.json',{'schema':1,'originalSha256':SHA,'functions':functions,'dependencies':dependencies,'tables':tables['tables'],'anchors':anchors})
output('verification.json',{'status':'PASS','scope':'Full original-PE/IDA instruction comparison of selected bodies, explicit reused dependencies and original data cells. No native/game execution or global lifetime proof.',
                          'originalSha256':SHA,'counts':groups,'dataBytes':sum(x['size'] for x in tables['tables']),
                          'semanticAnchors':len(anchors),'rootSession':'9d62332c','reviewerSession':'not available; root captures used',
                          'autoAnalysisReady':'Not independently observed for this subtask; the prior owner-cell study recorded false. No complete global autoanalysis claim.'})
print(json.dumps({'status':'PASS','counts':groups,'anchors':len(anchors)}))
