"""Bounded resource-alias original-byte and capture-integrity verification."""
import argparse, hashlib, json, runpy, struct
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=0x140000000
PIN='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
EXE=Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
num=lambda v:int(v,16) if isinstance(v,str) else v
octets=lambda s:bytes(int(v,16) for v in s.split()) if '0x' in s else bytes.fromhex(s)

def main(check=False):
    raw=EXE.read_bytes();assert sha(raw)==PIN
    nt=struct.unpack_from('<I',raw,60)[0];op=nt+24
    assert struct.unpack_from('<Q',raw,op+24)[0]==BASE
    sections=[struct.unpack_from('<IIII',raw,op+struct.unpack_from('<H',raw,nt+20)[0]+40*i+8)
              for i in range(struct.unpack_from('<H',raw,nt+6)[0])]
    def pe(a,n):
        r=a-BASE
        for vs,va,rs,off in sections:
            if va<=r and r+n<=va+rs:return raw[off+r-va:off+r-va+n]
        raise AssertionError(hex(a))
    def emit(name,obj):
        b=(json.dumps(obj,indent=2,ensure_ascii=False)+'\n').encode()
        if check:assert (HERE/name).read_bytes()==b,name
        else:(HERE/name).write_bytes(b)
    inv={num(f['address']):f['size'] for line in (ROOT/'docs/research/coverage/function_status.jsonl').read_text().splitlines()
         if (f:=json.loads(line))['domain']=='native'}
    cs=Cs(CS_ARCH_X86,CS_MODE_64);cs.detail=True
    functions=[];dependencies=[];instructions={}
    aliases={'retn':'ret','jz':'je','jnz':'jne','jnb':'jae','jna':'jbe','jnl':'jge','jng':'jle',
             'cmovz':'cmove','cmovnz':'cmovne','setz':'sete','setnz':'setne','setnb':'setae','sal':'shl'}
    def validate(a,n,b,rows,source,fresh):
        assert len(b)==n==inv[a] and b==pe(a,n),(hex(a),'bytes/extent')
        assert num(rows[0]['addr'])==a
        out=[];padding=[]
        for k,row in enumerate(rows):
            at=num(row['addr']);end=num(rows[k+1]['addr']) if k+1<len(rows) else a+n
            text=row.get('disasm',row.get('instruction'));mn=text.split()[0];original=b[at-a:end-a]
            if mn in ['align','db','dw','dd','dq']:
                padding.append({'addr':hex(at),'size':end-at,'originalBytes':original.hex(),'ida':text});continue
            i=next(cs.disasm(original,at,count=1));assert i.size==end-at,(hex(at),i.size,end-at)
            normalized_mn=' '.join(text.split()[:2]) if mn in ['rep','repe','repne'] else aliases.get(mn,mn)
            assert normalized_mn==i.mnemonic or (text=='xchg ax, ax' and i.mnemonic=='nop'),(hex(at),text,i.mnemonic)
            instructions[at]=i
            out.append({'addr':hex(at),'originalBytes':bytes(i.bytes).hex(),'instruction':i.mnemonic+' '+i.op_str,'ida':text})
        functions.append({'addr':hex(a),'size':n,'complete':True,'originalBytes':b.hex(),'sha256':sha(b),
                          'sourceMetadata':{'freshCapture':fresh,'source':source},'instructions':out,'nonInstructionSpans':padding})
    cap=HERE/'root-capture'
    bytefiles=sorted(cap.glob('*-bytes.json'))
    allbytes={num(r['addr']):octets(r['data']) for f in bytefiles for r in load(f)['result']}
    for path in sorted(cap.glob('*-instructions-complete.json')):
        for q in load(path)['result']:
            assert q['cursor']=={'done':True} and not q.get('truncated') and not q.get('error')
            assert q['count']==q['scanned']==len(q['matches']), (path.name,q['count'],len(q['matches']))
            assert len(q['ranges'])==1
            a=num(q['ranges'][0]['start']);n=num(q['ranges'][0]['end'])-a
            validate(a,n,allbytes[a],q['matches'],path.relative_to(HERE).as_posix(),True)
    expected={0x12A200,0x12A7C0,0x12AA20,0x12B1C0,0x12B770,0x12BA80,0x12C5A0,
              0x12A4C0,0x14BB10,0x12AD50,0x12C220,0x12C530,0x1186E0,0x118A60,
              0x129AE0,0x12B650,0x12C4E0}
    assert {num(f['addr'])-BASE for f in functions}==expected
    study='motion-provider-write-closure-20261011'
    src=ROOT/'docs/research'/study/'evidence.json'
    chosen={0x12E180,0x12E230,0x12DDA0,0x12CD80,0x12E460,0x12D8E0}
    selected=[f for f in load(src)['functions'] if num(f['addr'])-BASE in chosen]
    assert len(selected)==len(chosen)
    dependencies.append({'path':src.relative_to(ROOT).as_posix(),'sha256':sha(src.read_bytes()),'functions':[f['addr'] for f in selected]})
    for f in selected:
        rows=f['disassembly']['asm']['lines']
        validate(num(f['addr']),num(f['size']),octets(f['originalBytes']),rows,src.relative_to(ROOT).as_posix()+'#functions[addr='+f['addr']+']',False)
    for path in cap.glob('*-decompile.json'):
        d=load(path);assert d['cursor']=={'done':True} and not d.get('truncated') and d['line_count']==d['total_lines'],path.name
    xrefs=[]
    for path in cap.glob('*-xrefs.json'):
        for q in load(path)['result']:
            assert not q.get('more') and q['xref_count']==len(q['xrefs'])
            xrefs.append({'addr':q['addr'].lower(),'code':sum(x['type']=='code' for x in q['xrefs']),
                          'data':sum(x['type']=='data' for x in q['xrefs'])})
    calls=[x for q in load(cap/'entry-xrefs.json')['result'] if num(q['addr'])==BASE+0x12E180 for x in q['xrefs']]
    assert len(calls)==7 and all(c['type']=='code' for c in calls)
    edges=[]
    for c in calls:
        i=instructions[num(c['addr'])]
        assert i.mnemonic in ['call','jmp'] and i.op_str=='0x14012e180'
        edges.append({'addr':hex(i.address),'instruction':i.mnemonic+' '+i.op_str})
    # Argument-zero anchors are filled from exact full caller assembly, never pseudocode alone.
    config=load(HERE/'anchors.json') if (HERE/'anchors.json').exists() else {'expected':[],'zeroArgumentEdges':[]}
    anchors=[]
    for row in config['expected']:
        i=instructions[num(row['addr'])];text=i.mnemonic+' '+i.op_str
        assert text==row['instruction'],(row,text)
        anchors.append({'addr':hex(i.address),'originalBytes':bytes(i.bytes).hex(),'instruction':text})
    assert len(config['zeroArgumentEdges'])==7
    for edge in config['zeroArgumentEdges']:
        start,zero,call=map(num,[edge['function'],edge['zero'],edge['edge']])
        assert instructions[zero].mnemonic+' '+instructions[zero].op_str=='xor edx, edx'
        assert zero < call and instructions[call].op_str=='0x14012e180'
        for at in sorted(instructions):
            if zero < at < call:
                i=instructions[at]
                assert i.mnemonic not in ['call','jmp','ret'] and not i.mnemonic.startswith('j')
                assert not {i.reg_name(r) for r in i.regs_access()[1]} & {'rdx','edx','dx','dl','dh'}
        # No direct intra-body branch may skip the zero assignment and enter this straight-line suffix.
        f=next(f for f in functions if num(f['addr'])==start)
        for row in f['instructions']:
            i=instructions[num(row['addr'])]
            if i.mnemonic.startswith('j') and i.op_str.startswith('0x'):
                assert not zero < int(i.op_str,16) <= call, (edge,row)
    emit('evidence.json',{'schema':1,'originalSha256':PIN,'functions':functions,'dependencies':dependencies,
                          'directLookupEdges':edges,'anchors':anchors,'zeroArgumentEdges':config['zeroArgumentEdges']})
    groups={}
    for fresh,key in [(True,'fresh'),(False,'reused')]:
        fs=[f for f in functions if f['sourceMetadata']['freshCapture']==fresh]
        groups[key]={'functions':len(fs),'instructions':sum(len(f['instructions']) for f in fs),
                     'bodyBytes':sum(f['size'] for f in fs),'noninstructionBytes':sum(r['size'] for f in fs for r in f['nonInstructionSpans'])}
    report=load(HERE/'report.json') if (HERE/'report.json').exists() else {'claims':[]}
    parser=runpy.run_path(str(ROOT/'scripts/update-analysis-coverage.py'),run_name='resource_alias_reference_check')
    refs=0
    for claim in report['claims']:
        assert {'addr','Finding','Evidence','Limitations'}<=claim.keys()
        for ref in claim['Evidence']:
            assert parser['resolve_reference'](HERE/'report.json',ref).get('status')=='exists',ref
            refs+=1
    emit('verification.json',{'status':'PASS','originalSha256':PIN,'counts':groups,'anchors':len(anchors),
                              'directLookupEdges':len(edges),'claims':len(report['claims']),'references':refs,'xrefCounts':xrefs,
                              'nativeExecution':False,'modelCases':0,
                              'scope':'Selected direct lookup consumers and exact downstream helpers; no all-indirect-call, concurrency or global alias-lifetime claim.',
                              'readiness':'Root IDA captures; global readiness not independently observed.'})
    if check and (HERE/'manifest.json').exists():
        rows=load(HERE/'manifest.json')['files']
        assert {r['path'] for r in rows}=={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and p.name!='manifest.json'}
        for r in rows:
            b=(HERE/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
    print(json.dumps({'status':'PASS','counts':groups,'anchors':len(anchors),'claims':len(report['claims']),'references':refs}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');main(p.parse_args().check)
