"""Independent static review of complete captures against original PE bytes."""
from pathlib import Path
import argparse, hashlib, json, re, struct
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
STUDY=ROOT/'artifacts/resource-retained-aliases-20261013'
EXE=Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
load=lambda p:json.loads(p.read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
num=lambda x:int(x,16) if isinstance(x,str) else x
octets=lambda s:bytes(int(x,16) for x in s.split()) if '0x' in s else bytes.fromhex(s)
def pin(p):
    b=p.read_bytes();return {'path':p.relative_to(ROOT).as_posix(),'bytes':len(b),'sha256':sha(b)}

parser=argparse.ArgumentParser()
parser.add_argument('--author-manifest',help='Expected SHA256 of the explicitly frozen author manifest; required for final acceptance.')
args=parser.parse_args()
author_manifest=None
if args.author_manifest:
    author_manifest=pin(STUDY/'manifest.json')
    assert author_manifest['sha256']==args.author_manifest
    members=load(STUDY/'manifest.json')['files']
    assert {r['path'] for r in members}=={p.relative_to(STUDY).as_posix() for p in STUDY.rglob('*') if p.is_file() and p.name!='manifest.json'}
    for r in members:
        b=(STUDY/r['path']).read_bytes()
        assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path']

raw=EXE.read_bytes()
assert sha(raw)=='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
nt=struct.unpack_from('<I',raw,60)[0]
assert raw[nt:nt+4]==b'PE\0\0'
base=struct.unpack_from('<Q',raw,nt+48)[0]
assert base==0x140000000
table=nt+24+struct.unpack_from('<H',raw,nt+20)[0]
sections=[struct.unpack_from('<IIII',raw,table+i*40+8) for i in range(struct.unpack_from('<H',raw,nt+6)[0])]
def pe(a,n):
    for _,start,size,offset in sections:
        if start<=a-base and a-base+n<=start+size:
            return raw[offset+a-base-start:offset+a-base-start+n]
    raise AssertionError(hex(a))

cap=STUDY/'root-capture'
md=Cs(CS_ARCH_X86,CS_MODE_64);md.detail=True
functions={};instructions={};decoded=[]
def check_body(a,b,rows,origin):
    assert a not in functions and b==pe(a,len(b))
    assert num(rows[0]['addr'])==a
    out=[];non=[]
    for k,row in enumerate(rows):
        at=num(row['addr']);end=num(rows[k+1]['addr']) if k+1<len(rows) else a+len(b)
        assert a<=at<end<=a+len(b)
        data=b[at-a:end-a]
        text=row.get('disasm',row.get('instruction'))
        if text.split()[0] in ['align','db','dw','dd','dq']:
            non.append({'address':hex(at),'size':len(data),'bytes':data.hex(),'ida':text})
            continue
        ins=list(md.disasm(data,at));assert len(ins)==1 and ins[0].size==len(data),(hex(at),text)
        i=ins[0];instructions[at]=i
        out.append({'address':hex(at),'bytes':data.hex(),'text':i.mnemonic+' '+i.op_str})
    assert sum(len(bytes.fromhex(r['bytes'])) for r in out)+sum(r['size'] for r in non)==len(b)
    f={'address':hex(a),'size':len(b),'sha256':sha(b),'origin':origin,'instructions':out,'nonInstructionSpans':non}
    functions[a]=f;decoded.append(f)

fresh=set()
for prefix in ['caller','helper','escape-helper']:
    bs={num(r['addr']):octets(r['data']) for r in load(cap/(prefix+'-bytes.json'))['result']}
    look={num(r['fn']['addr']):num(r['fn']['size']) for r in load(cap/(prefix+'-lookup.json'))['result']}
    path=cap/(prefix+'-instructions-complete.json')
    for q in load(path)['result']:
        assert q['cursor']=={'done':True} and not q.get('truncated') and not q.get('error')
        assert len(q['ranges'])==1 and q['count']==q['scanned']==len(q['matches'])
        a=num(q['ranges'][0]['start']);n=num(q['ranges'][0]['end'])-a
        assert n==look[a]==len(bs[a])
        check_body(a,bs[a],q['matches'],path.relative_to(ROOT).as_posix());fresh.add(a)
assert len(fresh)==17
prior_path=ROOT/'docs/research/motion-provider-write-closure-20261011/evidence.json'
prior=load(prior_path)
chosen={base+x for x in [0x12e180,0x12e230,0x12dda0,0x12cd80,0x12e460,0x12d8e0]}
for f in prior['functions']:
    a=num(f['addr'])
    if a not in chosen:continue
    b=octets(f['originalBytes']);assert len(b)==num(f['size'])
    check_body(a,b,f['disassembly']['asm']['lines'],prior_path.relative_to(ROOT).as_posix())
assert len(functions)==23
evidence=load(STUDY/'evidence.json')
assert {num(f['addr']) for f in evidence['functions']}==set(functions)
for f in evidence['functions']:
    a=num(f['addr']);ind=functions[a]
    assert sha(octets(f['originalBytes']))==f['sha256']==ind['sha256']
    assert f['complete'] and f['size']==ind['size']
    assert len(f['instructions'])==len(ind['instructions'])
    for actual,review in zip(f['instructions'],ind['instructions']):
        assert num(actual['addr'])==num(review['address']) and actual['originalBytes']==review['bytes']
        assert actual['instruction']==review['text']
    assert sum(r['size'] for r in f['nonInstructionSpans'])==sum(r['size'] for r in ind['nonInstructionSpans'])
for p in cap.glob('*-decompile.json'):
    d=load(p);assert d['cursor']=={'done':True} and not d.get('truncated') and d['line_count']==d['total_lines']

counts={'fresh':{},'reused':{}}
for group,selected in [('fresh',fresh),('reused',chosen)]:
    fs=[functions[a] for a in selected]
    counts[group]={'functions':len(fs),'instructions':sum(len(f['instructions']) for f in fs),
                   'bodyBytes':sum(f['size'] for f in fs),'noninstructionBytes':sum(r['size'] for f in fs for r in f['nonInstructionSpans'])}

anchors=[]
def exact(rva,text):
    i=instructions[base+rva]
    assert i.mnemonic+' '+i.op_str==text,(hex(i.address),i.mnemonic+' '+i.op_str,text)
    anchors.append({'address':hex(i.address),'bytes':bytes(i.bytes).hex(),'instruction':text})

# Seven captured direct callers pass EDX=0. Check dominance within each complete
# body: no direct edge can enter after the zero, and the suffix neither clobbers
# RDX nor calls elsewhere. This is intentionally not all-indirect-call closure.
edges=[(0x12a200,0x12a362,0x12a367),(0x12a7c0,0x12a7fe,0x12a800),
       (0x12aa20,0x12aa5b,0x12aa6f),(0x12b1c0,0x12b2a5,0x12b343),
       (0x12b770,0x12b7e0,0x12b7e2),(0x12ba80,0x12bb44,0x12bb46),
       (0x12c5a0,0x12c5a0,0x12c5a2)]
xref=next(q for q in load(cap/'entry-xrefs.json')['result'] if num(q['addr'])==base+0x12e180)
assert not xref['more'] and xref['xref_count']==7
assert {num(x['addr'])-base for x in xref['xrefs']}=={c for _,_,c in edges}
for fn,zero,call in edges:
    exact(zero,'xor edx, edx')
    i=instructions[base+call];assert i.mnemonic in ['call','jmp'] and i.op_str=='0x14012e180'
    for row in functions[base+fn]['instructions']:
        i=instructions[num(row['address'])]
        if base+zero<i.address<base+call:
            assert i.mnemonic not in ['call','jmp','ret'] and not i.mnemonic.startswith('j')
            assert not {i.reg_name(r) for r in i.regs_access()[1]} & {'rdx','edx','dx','dl','dh'}
        if i.mnemonic.startswith('j') and i.op_str.startswith('0x'):
            assert not base+zero<int(i.op_str,16)<=base+call
    exact(call,('jmp' if call==0x12c5a2 else 'call')+' 0x14012e180')

# Persisted raw Primary-range argument versus copied two-QWORD token values.
exact(0x12e1a5,'mov rcx, qword ptr [r8 + 0x658]')
exact(0x12e1b1,'mov eax, dword ptr [r8 + 0x640]')
exact(0x12e1ce,'test edx, edx');exact(0x12e1d0,'je 0x14012e21d')
exact(0x12a4da,'mov r15, r8');exact(0x12a51b,'lea r12, [r14 + 0x208]')
exact(0x12a623,'mov r9, r15');exact(0x12a637,'mov qword ptr [rsp + 0x30], r12')
exact(0x12a645,'call 0x140129ae0')
exact(0x129b2f,'mov qword ptr [rsp + 0x30], r9')
exact(0x129b14,'mov qword ptr [rsp + 0x48], rax')
exact(0x129b49,'call 0x14012b650')
exact(0x12a721,'mov qword ptr [rsp + 0x48], r12')
exact(0x12a72e,'mov qword ptr [rsp + 0x30], r15')
exact(0x12a747,'call 0x14012b650')
exact(0x12b6b2,'mov rax, qword ptr [rsp + 0x60]')
exact(0x12b6b7,'mov qword ptr [rbx + 0x68], rdi')
exact(0x12b6c2,'mov qword ptr [rbx + 0x80], rax')
exact(0x12b6a0,'mov rcx, qword ptr [rsp + 0x78]')
exact(0x12b734,'mov rax, qword ptr [rcx]')
exact(0x12b737,'mov qword ptr [rbx + 0x58], rax')
exact(0x12b73b,'mov rax, qword ptr [rcx + 8]')
exact(0x12b73f,'mov qword ptr [rbx + 0x60], rax')
exact(0x12a772,'mov qword ptr [rsi + 0x18], rbx')
exact(0x12a77f,'mov qword ptr [rax + 8], rbx')
exact(0x12a786,'mov qword ptr [rsi + 0x20], rbx')
exact(0x12a791,'mov qword ptr [r13 + 0x70], rbx')
exact(0x12a798,'mov qword ptr [r13 + 0x60], r14')
exact(0x14befb,'mov rax, qword ptr [r14]')
exact(0x14befe,'mov qword ptr [rdi + 0x80], rax')
exact(0x14bf05,'mov rax, qword ptr [r14 + 8]')
exact(0x14bf09,'mov qword ptr [rdi + 0x88], rax')
exact(0x12b2d6,'mov rax, qword ptr [rbp + 0x80]')
exact(0x12b2dd,'mov qword ptr [rbx + 0x80], rax')
exact(0x12b30e,'mov byte ptr [rbx + 0x98], 1')
exact(0x12b330,'mov qword ptr [rbx + 0x58], rax')
exact(0x12b338,'mov qword ptr [rbx + 0x60], rax')
exact(0x12b33c,'mov rcx, qword ptr [rbx + 0x80]')

# Borrowed in-entry string pointer and downstream wrappers; no GPU completion
# or read-only-contract conclusion is drawn from forwarding alone.
exact(0x12a814,'lea rcx, [rax + 0x10]')
exact(0x12a81b,'call 0x14012c220')
exact(0x12c23e,'lea rax, [rcx + 0x10]')
exact(0x12c4a6,'lea rsi, [rbx + 0x50]')
exact(0x1186ee,'xor r8d, r8d');exact(0x1186fc,'jmp 0x140118a90')
exact(0x118a6e,'mov r8d, 1');exact(0x118a7f,'jmp 0x140118a90')

# Conditional cleanup uses token and range lookups, then delayed texture
# teardown. No barrier, reference acquisition or immediate revocation follows.
exact(0x12e250,'cmp qword ptr [r8 + 0x208], r9')
exact(0x12e25d,'cmp qword ptr [r8 + 0x210], rax')
exact(0x12b7c8,'call 0x14012e230');exact(0x12b7e7,'cmp rax, rdi')
exact(0x12bb2c,'call 0x14012e230');exact(0x12bb4b,'cmp rax, rdi')
exact(0x12bc0e,'mov rdx, rbx')
exact(0x12bc14,'call 0x14012ad50')
exact(0x12ad63,'cmp byte ptr [rdx + 0x98], 0')
exact(0x12ad72,'mov rcx, qword ptr [rdx + 0x68]')
exact(0x12ad81,'mov qword ptr [rbx + 0x68], 0')
exact(0x12ad8d,'call 0x140119a40');exact(0x12ad9d,'call 0x14012c930')
exact(0x12aded,'mov edx, 1');exact(0x12adf5,'call qword ptr [rax]')
exact(0x12e509,'mov dword ptr [rax + 0xb0], 0xa')
exact(0x12e513,'mov dword ptr [rax + 0xb4], 1')
exact(0x12e58c,'call qword ptr [rax]')
exact(0x12d992,'call qword ptr [r8]');exact(0x12da0f,'call 0x14012d5a0')
for rva in [0x12c530,0x12c4e0]:
    for row in functions[base+rva]['instructions']:
        i=instructions[num(row['address'])]
        assert i.mnemonic!='call'
        assert not any(op.type==3 and op.access & 2 for op in i.operands)

(HERE/'decoded.json').write_text(json.dumps(decoded,indent=2)+'\n',encoding='utf-8')
(HERE/'byte-verification.json').write_text(json.dumps({'status':'BYTE_MATCH','originalSha256':sha(raw),'counts':counts,
 'dependency':pin(prior_path),'evidence':pin(STUDY/'evidence.json'),'semanticAnchors':anchors,
 'scope':'Complete raw capture byte and instruction-boundary comparison, no native execution.'},indent=2)+'\n',encoding='utf-8')
if author_manifest:
    report=load(STUDY/'report.json')
    assert len(report['claims'])==13
    assert report['captureIntegrity']['replacement']=='root-capture/caller-instructions-complete.json'
    assert report['captureIntegrity']['superseded']=='root-capture/caller-instructions.json'
    refs=0
    for c in report['claims']:
        assert num(c['addr']) in functions and c['Finding'] and c['Limitations']
        for ref in c['Evidence']:
            path,sep,fragment=ref.partition('#')
            p=STUDY/path;assert p.is_file(),ref
            if sep:
                m=re.fullmatch(r'functions\[addr=(0x[0-9a-fA-F]+)\]',fragment);assert m,ref
                assert any(num(f['addr'])==num(m[1]) for f in load(p)['functions']),ref
            refs+=1
    assert refs==52
    wrapper=next(c for c in report['claims'] if c['addr']=='0x1401186e0')['Finding']
    assert 'saves the incoming texture in RBX' in wrapper and 'no claim is made that11C150 consumes' in wrapper
    markdown=(STUDY/'report.md').read_text(encoding='utf-8')
    assert 'zeitlich begrenzten Listenrunde' not in markdown
    assert pin(STUDY/'manifest.json')==author_manifest
    receipt={'status':'ACCEPTED','openFindings':[],
      'resolvedBeforeFreeze':['Wrapper wording no longer infers a consumed 11C150 parameter from unchanged RCX.',
                              'Time-gated list iteration is no longer described as having a bounded runtime.'],
      'authorManifest':author_manifest,'authorReport':pin(STUDY/'report.json'),
      'authorMarkdown':pin(STUDY/'report.md'),'authorEvidence':pin(STUDY/'evidence.json'),
      'authorVerifier':pin(STUDY/'verify.py'),'dependency':pin(prior_path),
      'originalSha256':sha(raw),'manifestMembers':len(members),'claims':len(report['claims']),
      'references':refs,'counts':counts,'directLookupEdges':len(edges),'semanticAnchors':len(anchors),
      'scope':'Independent original-byte/capture completeness, full relevant-body argument and cleanup review. Static only.',
      'limits':['No all-indirect-call or global retained-alias closure.',
                'No MSET-specific consumer or production Motion admission.',
                'Copied identifier values, borrowed names, raw buffers and entry objects have distinct local lifetimes.',
                'No GPU completion, concurrency, transitive ownership, use-after-free or live-game claim.']}
    (HERE/'review.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'ACCEPTED','manifestMembers':len(members),'claims':len(report['claims']),
                      'references':refs,'directLookupEdges':len(edges),'semanticAnchors':len(anchors)}))
print(json.dumps(counts))
