# Independent review: retained resource aliases

Status: **ACCEPTED**, no open findings. Reviewed all 13 claims against the
complete relevant bodies and the original executable. Two wording issues were
resolved before the final author freeze.

## Independent evidence

The complete captures match the pinned original executable. There are 17 fresh
bodies (1889 instructions, 7298 bytes) and six explicitly reused bodies (791
instructions, 3045 bytes). Of the fresh body bytes, 66 are separately identified
alignment/switch data rather than instructions. The original executable SHA256
is `9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed`.

The comparison starts from raw complete captures and the PE section map, then
checks the normalized study evidence. The preview-only first caller capture is
not used for full instruction evidence. The seven direct lookup call/jump edges
are independently checked for EDX=0, intervening register writes and same-body
direct branches that could skip that assignment.
The final audit also verifies all 35 frozen author files, 52 evidence references
and 80 exact semantic anchors. The author's `verify.py --check` passes separately.

## Reviewed behavior

- `12A7C0` and `12AA20` pass a raw pointer found inside the registered Primary
  range to `12A4C0`. The constructor chain stores it in Texture+128, and the
  texture is published in a persistent list. This pointer may be interior to the
  buffer. The evidence does not establish a resource lifetime reference.
- Entry+520/+528 supply two copied QWORD values at Texture+88/+96. The input
  address Entry+520 is not itself retained in those slots. Neither equal values
  nor equal results from two later lookups prove a generation or lifetime lock.
- `14BB10` stores the original descriptor pointers in result+128/+136 even on
  paths that used temporary conversion buffers. `12A200` can use an explicit
  lookup override that differs from the retained descriptor pointer.
- `12B1C0` copies buffer aliases into another texture object and marks byte+152.
  The clone/name counter at Entry+1616 is not a local release gate in `12E460`.
- `12C220` receives the metadata view Entry+16. It can return borrowed name or
  scratch storage at Entry+32/+96 and can mutate the count/table at
  Entry+536/+540. Those fields are distinct from the two identifier QWORDs.
- `12A4C0` places the replacement payload in Texture+104 and clears the source
  replacement field after the selected upload call returns. `12AD50` conditionally
  frees Texture+104 according to byte+152, invokes further cleanup, unlinks the
  texture and dispatches its virtual destructor. Its local free arguments do
  not include +128/+136; opaque helpers remain outside that conclusion.
- Entry retirement can mark referenced textures for later removal before
  unlinking/destructing the entry. The study does not turn this separation into
  a use-after-free finding or assert when the underlying Primary buffer is freed.

No MSET-specific retaining consumer, all-indirect-call closure, GPU completion,
global lifetime safety or production Motion admission follows from this study.
No product/docs/coverage edits, builds, game execution, GUI or Twitch actions
were performed for this review.

## Corrections resolved before freeze

The initial wrapper claim treated the unchanged RCX register at the `11C150`
call as a proven consumed texture argument. Requested exact local wording:
save the incoming texture in RBX, call `11C150`, then forward its return in RCX,
the texture in RDX and mode 0/1 in R8D to `118A90`. This avoids inferring a
callee parameter from a surviving register alone.

The Markdown initially called the `12BA80` list pass time-bounded. It now says
the iteration starts after a time comparison. The captured body proves a time
gate, without proving a bound on the whole iteration's runtime. Both changes
are present in the frozen report.

## Reproduction

```powershell
py -3 -B artifacts/review-resource-retained-aliases-20261013/audit.py --author-manifest cba467eacb3d1758a8a59e60dbb7fd037e376d339f63d2aee0370e0f7347700f
```

`decoded.json` contains the independent full decoding. `byte-verification.json`
contains counts, evidence/dependency pins and selected exact semantic anchors.
`review.json` records final acceptance and the exact frozen author pins.

- Author manifest: `cba467eacb3d1758a8a59e60dbb7fd037e376d339f63d2aee0370e0f7347700f`
- Author report JSON: `8bd02fe988e61ecef835ac218ec0e3116b373d6f85c30d4070a0e2bac03dc9dc`
- Author report Markdown: `7875756cb798bdc29de97824be7352775e434ab297b8b88712d33ba42026f057`
- Author evidence: `1c0dabf4bddaf7ce419fe3d4ef662ee1679748b276665645e91f6d7e527c569f`
