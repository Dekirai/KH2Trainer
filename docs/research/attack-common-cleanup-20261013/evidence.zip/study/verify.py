"""Verify bounded cleanup/allocator evidence against the immutable original PE.

This is byte and instruction-boundary verification, not a semantic emulator.
"""
import argparse, hashlib, json, runpy, struct
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

H = Path(__file__).resolve().parent
ROOT = H.parents[1]
B = 0x140000000
PIN = '9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
SOURCE = Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_bytes())
num = lambda n: int(n, 16) if isinstance(n, str) else n
def octets(s):
    return bytes(int(t, 16) for t in s.split()) if '0x' in s else bytes.fromhex(s)

REUSE = {
    'attack-object-ownership-20261011': [0x3CF190, 0x3CF7F0, 0x3CFB10, 0x40F4C0],
    'attack-slot-reuse-20261013': [0x3D25D0],
    'app-timer-dispatch-20261008': [0x3BAA80],
    'actor-lifetime-20261007': [0x152430, 0x152570, 0x4AD240, 0x4AD270, 0x4AD2C0, 0x4AD390, 0x4AD3F0],
    'allocator-blocks-20261008': [0x19C2B0, 0x19C3A0, 0x19C470],
    'actor-free-closure-20261008': [0x3A08F0],
}

def main(check):
    raw = SOURCE.read_bytes()
    assert sha(raw) == PIN
    nt = struct.unpack_from('<I', raw, 0x3c)[0]
    opt = nt + 24
    assert struct.unpack_from('<Q', raw, opt + 24)[0] == B
    sections = [struct.unpack_from('<IIII', raw, opt + struct.unpack_from('<H', raw, nt + 20)[0] + 40*i + 8)
                for i in range(struct.unpack_from('<H', raw, nt + 6)[0])]
    def pe(at, size):
        rva = at - B
        for vs, start, rs, offset in sections:
            if start <= rva and rva + size <= start + rs:
                return raw[offset + rva - start:offset + rva - start + size]
        raise AssertionError(hex(at))
    def emit(name, value):
        data = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode()
        if check:
            assert (H/name).read_bytes() == data, name
        else:
            (H/name).write_bytes(data)
    inventory = {num(f['address']): f['size'] for line in (ROOT/'docs/research/coverage/function_status.jsonl').read_text().splitlines()
                 if (f := json.loads(line))['domain'] == 'native'}
    cs = Cs(CS_ARCH_X86, CS_MODE_64)
    cs.detail = True
    aliases = {'retn':'ret','jz':'je','jnz':'jne','jnb':'jae','jna':'jbe','jnl':'jge','jng':'jle',
               'cmovz':'cmove','cmovnz':'cmovne','setz':'sete','setnz':'setne','setnb':'setae','sal':'shl'}
    functions, dependencies, ins = [], [], {}
    def validate(addr, size, data, rows, origin, fresh):
        assert len(data) == size == inventory[addr] and data == pe(addr, size), hex(addr)
        assert num(rows[0]['addr']) == addr
        normalized, gaps = [], []
        for n, row in enumerate(rows):
            at = num(row['addr'])
            end = num(rows[n+1]['addr']) if n+1 < len(rows) else addr + size
            text = row.get('disasm', row.get('instruction'))
            assert at < end <= addr+size
            if text.split()[0] in ('align', 'db', 'dw', 'dd', 'dq'):
                gaps.append({'addr':hex(at),'size':end-at,'originalBytes':data[at-addr:end-addr].hex(' '),'ida':text})
                continue
            i = next(cs.disasm(data[at-addr:end-addr], at, count=1))
            prefix = text.split()[0]
            actual = {'movabs':'mov'}.get(i.mnemonic.split()[0], i.mnemonic.split()[0])
            assert aliases.get(prefix, prefix) == actual or (text == 'xchg ax, ax' and actual == 'nop'), (hex(at), text, i.mnemonic)
            assert at+i.size <= end
            ins[at] = i
            normalized.append({'addr':hex(at),'originalBytes':bytes(i.bytes).hex(' '),'instruction':i.mnemonic+' '+i.op_str,'ida':text})
            if at+i.size < end:
                gaps.append({'addr':hex(at+i.size),'size':end-at-i.size,'originalBytes':data[at+i.size-addr:end-addr].hex(' '),'ida':'unlisted span between captured heads'})
        assert sum(len(octets(x['originalBytes'])) for x in normalized)+sum(x['size'] for x in gaps)==size
        functions.append({'addr':hex(addr),'size':size,'complete':True,'originalBytes':data.hex(' '),'sha256':sha(data),
                          'sourceMetadata':{'freshCapture':fresh,'source':origin},'instructions':normalized,'nonInstructionSpans':gaps})
    for stem in ['', 'iterator-']:
        captures = {num(r['addr']):octets(r['data']) for r in load(H/'root-capture'/f'{stem}bytes.json')['result']}
        for q in load(H/'root-capture'/f'{stem}instructions.json')['result']:
            assert q['cursor']=={'done':True} and not q.get('truncated') and not q.get('error')
            assert q['count']==q['scanned']==len(q['matches']) and len(q['ranges'])==1
            at = num(q['ranges'][0]['start'])
            size = num(q['ranges'][0]['end'])-at
            validate(at,size,captures[at],q['matches'],f'root-capture/{stem}instructions.json',True)
    assert {num(f['addr'])-B for f in functions} == {0x3D2E50,0x3CF3A0,0x31DD0,0x3BF4F0}
    for p in (H/'root-capture').glob('*-decompile.json'):
        d=load(p)
        assert d['cursor']=={'done':True} and not d.get('truncated') and d['line_count']==d['total_lines']
    for study, rvas in REUSE.items():
        path=ROOT/'docs/research'/study/'evidence.json'
        evidence=load(path)
        selected=[f for f in evidence['functions'] if num(f['addr'])-B in rvas]
        assert len(selected)==len(rvas)
        dependencies.append({'path':path.relative_to(ROOT).as_posix(),'sha256':sha(path.read_bytes()),'functions':[hex(B+r) for r in rvas]})
        for f in selected:
            asm=f.get('asm') or f.get('disassembly',{}).get('asm')
            rows=asm['lines'] if asm else [r for p in f['pages'] for r in p['asm']['lines']]
            data=f.get('originalBytes')
            if data is None:
                blocks=f['original_bytes']
                assert len(blocks)==1 and num(blocks[0]['addr'])==num(f['addr'])
                data=blocks[0]['data']
            validate(num(f['addr']),num(f['size']),octets(data),rows,path.relative_to(ROOT).as_posix()+'#functions[addr='+f['addr']+']',False)
    table_source=load(ROOT/'docs/research/allocator-blocks-20261008/evidence.json')['data'][0]
    assert num(table_source['addr'])==B+0x5B2BB0
    table=octets(table_source['data'])[:24]
    assert table==pe(B+0x5B2BB0,24)
    assert struct.unpack('<QQQ',table)==(B+0x19C0C0,B+0x19C2B0,B+0x19C470)
    data=[{'addr':hex(B+0x5B2BB0),'size':24,'originalBytes':table.hex(' '),'qwords':[hex(v) for v in struct.unpack('<QQQ',table)],'source':'docs/research/allocator-blocks-20261008/evidence.json#data[0]'}]
    anchor_rvas=[0x40F4D9,0x40F4FB,0x40F513,0x3CFC09,0x3CFC42,0x3CFC82,
                 0x3BF505,0x3BF50E,0x3BF524,0x3BAA80,0x3D2E61,0x3CF3BD,
                 0x3CF7F0,0x3CF810,0x3CF21C,0x3D26A0,0x3D26AE,
                 0x152430,0x152570,0x19C3E8,0x19C3FA,0x19C2D5,0x19C2DD,
                 0x19C352,0x19C37C,0x19C491,0x19C494,0x19C49E,0x19C4B4,
                 0x19C4C5,0x19C4D0,0x19C4D3,0x19C4D6,0x19C4E2,0x19C4E7,0x19C4E9,
                 0x31DD0,0x4AD3D7,0x4AD416]
    anchors=[]
    for rva in anchor_rvas:
        i=ins[B+rva]
        anchors.append({'addr':hex(i.address),'originalBytes':bytes(i.bytes).hex(' '),'instruction':i.mnemonic+' '+i.op_str})
    groups={}
    for fresh,name in [(True,'fresh'),(False,'reused')]:
        fs=[f for f in functions if f['sourceMetadata']['freshCapture']==fresh]
        groups[name]={'functions':len(fs),'instructions':sum(len(f['instructions']) for f in fs),'bodyBytes':sum(f['size'] for f in fs),
                      'noninstructionBytes':sum(s['size'] for f in fs for s in f['nonInstructionSpans'])}
    emit('evidence.json',{'schema':1,'originalSha256':PIN,'functions':functions,'data':data,'dependencies':dependencies,'anchors':anchors})
    claims=load(H/'report.json')['claims'] if (H/'report.json').exists() else []
    references=0
    if claims:
        parser=runpy.run_path(str(ROOT/'scripts/update-analysis-coverage.py'),run_name='cleanup_reference_check')
        for claim in claims:
            assert {'addr','Finding','Evidence','Limitations'}<=claim.keys()
            for ref in claim['Evidence']:
                assert parser['resolve_reference'](H/'report.json',ref).get('status')=='exists',ref
                references+=1
    emit('verification.json',{'status':'PASS','originalSha256':PIN,'counts':groups,'dataBytes':24,'anchors':len(anchors),'claims':len(claims),'resolvedEvidenceReferences':references,
                             'nativeExecution':False,'modelCases':0,'scope':'Full selected bodies and original allocator table; manual bounded dataflow. Not all writers, all callers, all allocators, complete runtime ownership, or arbitrary invalid-memory behavior.',
                             'readiness':'Root-provided IDA captures; global autoanalysis completion not independently observed.'})
    if check and (H/'manifest.json').exists():
        manifest=load(H/'manifest.json')
        actual={p.relative_to(H).as_posix() for p in H.rglob('*') if p.is_file() and p.name!='manifest.json'}
        assert actual=={r['path'] for r in manifest['files']}
        for row in manifest['files']:
            b=(H/row['path']).read_bytes()
            assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
    print(json.dumps({'status':'PASS','counts':groups,'dataBytes':24,'anchors':len(anchors),'claims':len(claims),'references':references}))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--check',action='store_true')
    main(p.parse_args().check)
