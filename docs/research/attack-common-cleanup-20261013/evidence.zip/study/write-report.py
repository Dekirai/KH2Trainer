"""Build the bounded, manually reviewed semantic report."""
import json
from pathlib import Path
H=Path(__file__).resolve().parent
claims=[]
def add(rva,finding,limitations,*support):
    addresses=[rva,*support]
    claims.append({'addr':hex(0x140000000+rva),'Finding':finding,
                   'Evidence':['evidence.json#functions[addr='+hex(0x140000000+a)+']' for a in addresses],
                   'Limitations':limitations})
add(0x3BF4F0,
    'The iterator starts at QWORD global 0x142A171C8 for a null input, otherwise advances through packed DWORD Actor+2704. It skips candidates for which 3BAA80 returns true; the verified predicate is DWORD Actor+288 & 0x10080000. A candidate with either mask bit set is skipped, and null terminates iteration.',
    'This establishes the selected head/link and predicate, not global membership invariants, all Actor lists, eventual termination for malformed links, or a runtime Actor lifetime.',0x3BAA80,0x4AD270,0x4AD3F0)
add(0x3D2E50,
    'This wrapper repeatedly invokes 3BF4F0 until null or until DWORD candidate+1736 has mask 0x2 set. Consequently the 3CFB10 cleanup sweep is filtered by both Actor+288 mask 0x10080000 being clear and Actor+1736 mask 0x2 being set, rather than visiting every object.',
    'No semantic name for the two predicates is inferred from IDA labels. The wrapper itself only reads these fields; this is not proof of exhaustive cleanup across all Actor types or lists.',0x3BF4F0,0x3BAA80,0x3CFB10)
add(0x3CF3A0,
    'The leaf clears exactly the selected bit in DWORD [0x142A24AD0 + 4*(uint32(id)>>5)], with mask ~(1u << (id&31)). It is called with contact DWORD+32 by 3CFB10 after the unmasked sweep. It performs no calls and does not load an external owner-cell pointer.',
    'There is no local ID bounds check. This proves the bit-clear arithmetic, not the valid ID range, allocation availability, or safety of arbitrary IDs.',0x3CFB10)
add(0x3CF7F0,
    'The helper takes id=DWORD contact+32 and clears bit id&31 at table+4+4*(uint32(id)>>5). Common cleanup supplies Actor+3224 for selected Actors and otherContact+60 for surviving contacts. It does not compare or republish the QWORD external owner cell used by 40F4C0.',
    'The arithmetic has no local bounds check. Claims about intended bitmap storage assume valid native IDs and tables; arbitrary IDs can address unrelated storage.',0x3CFB10)
add(0x3CFB10,
    'Base cleanup decrements Actor+1464 for the two nonnull decoded fields contact+12 and contact+20, unlinks the contact from head/tail 0x142A24B40/48 using packed next+196, and zeros that next field. If contact+8 mask 0x400 is clear it runs the filtered Actor sweep, clears matching Actor+3320 by pointer identity, clears contact-ID bits in the selected Actor/contact tables, and releases the ID bit. It always tail-calls 3CF190(contact+60). The matching-pointer clear at Actor+3320 is distinct from the earlier unconditional owner-cell clear in 40F4C0.',
    'Requires valid list membership, links, IDs and referenced Actors. Mask 0x400 skips the sweep and ID release, not the counter decrements or list removals. No idempotence, all-transitive-writer closure or general lifetime safety is proved. Pointer codec initialization may write its own global region table.',0x3D2E50,0x3CF7F0,0x3CF3A0,0x3CF190,0x40F4C0)
add(0x3CF190,
    'The tail-called helper removes its input node from the separate head/tail globals 0x142A24AC0/8 through packed next node+80. It updates head or predecessor, adjusts tail if the node was the tail, and encodes null into node+80. With the base-cleanup input contact+60 this last local field is contact+140.',
    'It assumes membership in a well-formed list and does not safely handle an absent or already removed node. The pointer codecs can initialize global codec state; this is not an all-transitive-no-write claim.',0x3CFB10,0x4AD240,0x4AD270)
add(0x31DD0,
    'The entire three-byte original function is C2 00 00 (RET 0). It makes no memory write or call and performs no allocation release. In 40F4C0 it is reached only when flags&1 and flags&4, with this and size 728; flag4 alone does not enter either release branch.',
    'This describes this selected destructor branch only. Caller intent, custom allocation conventions and whole-program leak behavior are not established.',0x40F4C0)
add(0x152570,
    'The ordinary free forwarder passes the payload as RDX, loads the allocator currently at global 0x1409BA920, and tail-jumps through vtable slot +16. For the original table 0x1405B2BB0 installed by 19C3A0, slot+16 is 19C470; allocation through 152430 analogously selects slot+8, whose original target is 19C2B0.',
    'The free dispatch does not select the allocator from the allocation header. Binding therefore depends on the current global allocator, original table and matching allocation provenance. Other allocators and changed globals/tables are outside this result.',0x152430,0x19C3A0,0x19C470,0x19C2B0)
claims[-1]['Evidence'].append('evidence.json')
add(0x19C2B0,
    'On successful allocation the requested payload size is rounded up to 16 bytes, 48 bytes are added to the stored block size, and the returned payload is header+32. The selected manager 3D25D0 requests 728 bytes: under this allocator the rounded payload is 736 and the block size is 784. That block includes all eight bytes of the stored owner-cell pointer at payload+720.',
    'This arithmetic is conditional on successful valid allocation through this allocator. It does not fix the manager no-empty-slot or allocation-failure paths and is not a claim that the global allocator always has this type.',0x3D25D0,0x152430)
add(0x19C470,
    'For a nonnull valid payload, regular free derives header=payload-32 and the stored block size from payload-16, calls 3A08F0(header,header+size), unlinks the allocation, adjusts used bytes and the last-allocation pointer, fills floor(size/4) DWORDs from the header with 0xEFACCAFE, then zeros header+8. Thus a matching 728-byte request yields a 784-byte fill that overwrites the old object+720 field after the destructor has already zeroed the external cell and run common cleanup. The allocator body has no access through that owner-cell pointer and does not republish a replacement attack into the external cell.',
    'Assumes matching allocator, valid header, links and nonoverlapping allocations. Freeing the old allocation is not a repair of the separate manager registration. This does not prove whether or when the manager-owning Actor is freed, all allocator implementations, concurrency safety, or writes inside opaque semaphore/CRT runtime helpers.',0x19C2B0,0x3A08F0,0x40F4C0,0x152570)
add(0x3A08F0,
    'The helper called before block unlinking ignores its incoming start/end values. Its body traverses QWORD head 0x142A0D628, repeatedly decoding the DWORD at each node through 4AD270, until null. It does not compare allocation bounds, invoke a per-node callback, write the traversed nodes, or load an attack owner-cell pointer.',
    'Assumes a terminating valid list. The decoder can initialize the global pointer-region table through 4AD2C0, whose CRT guard calls remain opaque here; therefore this is a local traversal statement, not proof that every transitive runtime helper is write-free.',0x19C470,0x4AD270,0x4AD3F0,0x4AD2C0)
report={'schema':1,'title':'Attack common cleanup and regular allocator boundary','date':'2026-10-13',
        'originalSha256':'9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed',
        'scope':'Four fresh complete IDA bodies plus seventeen reused complete bodies and 24 original allocator-table bytes. Static bounded study; no runtime execution or new broad scan.',
        'claims':claims,
        'Conclusion':'The newly expanded local cleanup chain clears collision references and recycles the ID when contact+8 mask0x400 is clear. With deletion flags&1 and !(flags&4), a matching regular allocator destroys the old allocation. The inspected local bodies contain no manager-cell identity repair or replacement publication. The alternative size-728 leaf is empty. No global Actor-owner lifetime, actual crashing schedule or all-transitive-writer result is claimed.',
        'OpenBoundaries':['Whether and when the manager-owning Actor is physically destroyed is handled by the separate Actor-destruction study, not proved here.',
                          'The current global allocator must match the allocation provenance; other virtual implementations are not covered.',
                          'Native valid ID/list/pointer invariants, CRT guard internals and semaphore implementation remain explicit assumptions or boundaries.',
                          'No universal use-after-free, observed game crash, all callers or all writers conclusion.']}
(H/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
