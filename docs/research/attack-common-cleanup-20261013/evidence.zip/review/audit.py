"""Independent raw-PE audit; no game execution or source artifact mutation."""
import argparse, hashlib, json, struct
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STUDY = ROOT / 'artifacts/attack-common-cleanup-20261013'
EXE = Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
PIN = '9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_bytes())

def audit():
    raw = EXE.read_bytes()
    assert sha(raw) == PIN
    offset = struct.unpack_from('<I', raw, 60)[0]
    optional = offset + 24
    base = struct.unpack_from('<Q', raw, optional + 24)[0]
    table = optional + struct.unpack_from('<H', raw, offset + 20)[0]
    sections = [struct.unpack_from('<IIII', raw, table + 40*i + 8)
                for i in range(struct.unpack_from('<H', raw, offset+6)[0])]
    def read(addr, size):
        rva = addr-base
        for virtual_size, virtual_start, raw_size, raw_start in sections:
            if virtual_start <= rva and rva+size <= virtual_start+raw_size:
                return raw[raw_start+rva-virtual_start:raw_start+rva-virtual_start+size]
        raise AssertionError(hex(addr))
    evidence = load(STUDY/'evidence.json')
    assert evidence['originalSha256'] == PIN
    dis = Cs(CS_ARCH_X86, CS_MODE_64)
    count = bytecount = padding = 0
    for f in evidence['functions']:
        start, size = int(f['addr'], 16), f['size']
        original = bytes.fromhex(f['originalBytes'])
        assert original == read(start, size) and sha(original) == f['sha256'] and f['complete']
        covered = set()
        for row in f['instructions']:
            addr = int(row['addr'], 16)
            b = bytes.fromhex(row['originalBytes'])
            assert b == read(addr, len(b))
            decoded = list(dis.disasm(b, addr))
            assert len(decoded) == 1 and decoded[0].size == len(b)
            ins = decoded[0]
            assert ins.mnemonic + ' ' + ins.op_str == row['instruction']
            span = set(range(addr, addr+len(b)))
            assert not span & covered
            covered |= span
            count += 1
        for row in f['nonInstructionSpans']:
            addr, size2 = int(row['addr'],16), row['size']
            assert read(addr, size2) == bytes.fromhex(row['originalBytes'])
            span = set(range(addr, addr+size2))
            assert not span & covered
            covered |= span
            padding += size2
        assert covered == set(range(start,start+size))
        bytecount += size
    data_bytes = 0
    for d in evidence['data']:
        b = bytes.fromhex(d['originalBytes'])
        assert len(b) == d['size'] and b == read(int(d['addr'],16),len(b))
        assert [hex(x) for x in struct.unpack('<'+'Q'*(len(b)//8),b)] == d['qwords']
        data_bytes += len(b)
    for d in evidence['dependencies']:
        assert sha((ROOT/d['path']).read_bytes()) == d['sha256']
    manifest_count = 0
    if (STUDY/'manifest.json').exists():
        rows = load(STUDY/'manifest.json')['files']
        assert {r['path'] for r in rows} == {p.relative_to(STUDY).as_posix() for p in STUDY.rglob('*') if p.is_file() and p.name != 'manifest.json'}
        for row in rows:
            b = (STUDY/row['path']).read_bytes()
            assert sha(b) == row['sha256'] and len(b) == row['bytes']
        manifest_count = len(rows)
    assert 32+720+8 <= 784
    result = {'status':'PASS', 'originalSha256':PIN, 'functions':len(evidence['functions']),
              'instructions':count, 'bodyBytes':bytecount, 'unlistedPaddingBytes':padding,
              'dataBytes':data_bytes, 'dependencyFiles':len(evidence['dependencies']),
              'manifestFiles':manifest_count,
              'reportSha256':sha((STUDY/'report.json').read_bytes()),
              'evidenceSha256':sha((STUDY/'evidence.json').read_bytes()),
              'manifestSha256':sha((STUDY/'manifest.json').read_bytes()) if manifest_count else None,
              'nativeExecution':False, 'modelCases':0}
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    result = audit()
    text = (json.dumps(result,indent=2)+'\n').encode()
    if args.check:
        assert (HERE/'audit.json').read_bytes() == text
    else:
        (HERE/'audit.json').write_bytes(text)
    print(text.decode())
