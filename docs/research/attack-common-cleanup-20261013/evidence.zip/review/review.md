# Independent review: attack common cleanup

**PASS. No open findings.** The final source manifest is `52b04878c2b2874836902062d82b17ff37ae4c0be690cd91c683cca4ed7b3f29`.

I read all21 selected complete instruction bodies and the eleven structured claims. A separate verifier reread the original PE, compared every body and data byte, independently decoded all594 captured instructions with Capstone, compared full mnemonic/operand text, and checked complete byte coverage including4 retained padding bytes. Total:2210 body bytes,24 allocator-table bytes and6 pinned dependency files. The source author's `verify.py --check` also passed, including its43 claim references. No native code or semantic model was executed.

## Semantic checks

- `3BF4F0` excludes candidates intersecting `0x10080000` at Actor+288; `3D2E50` additionally requires mask2 at Actor+1736. The cleanup sweep is filtered.
- Contact+8 mask`0x400` gates both the selected Actor/contact bitmap sweep and ID release. It does not gate the earlier Actor reference decrements/list unlink or final embedded-node removal.
- The identity check at Actor+3320 is separate from the already completed unconditional external-cell zero through attack+720 in `40F4C0`.
- The destructor's mask1 is the outer release gate. With mask4 clear, `152570` dispatches to the current allocator; with mask4 set, `031DD0(this,728)` is reached. The entire latter body is `RET 0`. Mask4 alone does not invoke either branch.
- Under the specified matching allocator,728 rounds to736, then48 bytes of overhead produce784. The payload starts32 bytes after the header. The eight bytes at payload+720 occupy header+752..759, inside the784-byte poison fill. Erasing this storage does not republish a replacement into a separate manager cell.
- `3A08F0` ignores its incoming bounds and locally traverses a packed list without node writes/callbacks. Pointer decoder initialization and opaque CRT/semaphore effects remain explicit limits.

## Resolved wording item

The initial summary sounded unconditional about ID recycling and storage reclamation. The final introduction and JSON conclusion now state the contact mask, deletion flags and matching-allocator conditions. The eleven per-function claims already had these conditions. No code or evidence change was requested.

## Boundaries

The review accepts the report's selected valid list/ID/header/nonaliasing conditions. It does not establish all callers, all allocator implementations, Actor-owner lifetime, transitive runtime helper effects, a reachable slot-reuse bug or an observed game crash. The21 checked bodies are not21 newly discovered functions. Product, docs, coverage, packages and the author's frozen artifacts were not modified by this review.
