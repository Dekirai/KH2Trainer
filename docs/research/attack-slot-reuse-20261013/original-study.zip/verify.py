"""Verify bounded original bodies and reproduce explicitly synthetic slot probes."""
import argparse, hashlib, importlib.util, json, runpy, struct
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_64

H=Path(__file__).resolve().parent
ROOT=H.parents[1]
B=0x140000000
PIN='9002b2de6a1f91a790bd0673de125d1cf833f7942bfec827cdcf6ba64d5849ed'
SOURCE=Path(r'E:\SteamLibrary\steamapps\common\KINGDOM HEARTS -HD 1.5+2.5 ReMIX-\KINGDOM HEARTS II FINAL MIX.exe')
sha=lambda data:hashlib.sha256(data).hexdigest()
load=lambda path:json.loads(path.read_bytes())
num=lambda v:int(v,16) if isinstance(v,str) else v
def octets(s):return bytes(int(x,16) for x in s.split()) if '0x' in s else bytes.fromhex(s)

def main(check=False):
 raw=SOURCE.read_bytes();assert sha(raw)==PIN
 nt=struct.unpack_from('<I',raw,0x3c)[0];opt=nt+24
 assert struct.unpack_from('<Q',raw,opt+24)[0]==B
 sections=[struct.unpack_from('<IIII',raw,opt+struct.unpack_from('<H',raw,nt+20)[0]+40*i+8) for i in range(struct.unpack_from('<H',raw,nt+6)[0])]
 def pe(addr,size):
  rva=addr-B
  for vs,start,rs,offset in sections:
   if start<=rva and rva+size<=start+rs:return raw[offset+rva-start:offset+rva-start+size]
  raise AssertionError(('unmapped PE range',hex(addr),size))
 def emit(name,value):
  data=(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
  if check:assert (H/name).read_bytes()==data,name
  else:(H/name).write_bytes(data)
 inv={num(f['address']):f['size'] for line in (ROOT/'docs/research/coverage/function_status.jsonl').read_text().splitlines() if (f:=json.loads(line))['domain']=='native'}
 cs=Cs(CS_ARCH_X86,CS_MODE_64);cs.detail=True
 aliases={'retn':'ret','jz':'je','jnz':'jne','jnb':'jae','jna':'jbe','jnl':'jge','jng':'jle','cmovz':'cmove','cmovnz':'cmovne','setz':'sete','setnz':'setne','setnb':'setae','sal':'shl'}
 fs=[];ins={};deps=[]
 def body(addr,size,data,rows,origin,fresh):
  assert data==pe(addr,size) and len(data)==inv[addr]==size
  normalized=[];assert num(rows[0]['addr'])==addr
  for index,row in enumerate(rows):
   at=num(row['addr']);end=num(rows[index+1]['addr']) if index+1<len(rows) else addr+size
   i=next(cs.disasm(data[at-addr:end-addr],at,count=1));text=row.get('disasm',row.get('instruction'))
   mnemonic=text.split()[0]
   assert i.size==end-at
   assert aliases.get(mnemonic,mnemonic)==i.mnemonic or (text=='xchg ax, ax' and i.mnemonic=='nop')
   ins[at]=i
   normalized.append({'addr':hex(at),'bytes':bytes(i.bytes).hex(),'instruction':i.mnemonic+' '+i.op_str,'ida':text})
  fs.append({'addr':hex(addr),'size':size,'originalBytes':data.hex(),'sha256':sha(data),'complete':True,'sourceMetadata':{'freshCapture':fresh,'source':origin},'instructions':normalized})
 capture=H/'root-capture';captured={num(r['addr']):octets(r['data']) for r in load(capture/'bytes.json')['result']}
 for path in sorted(capture.glob('*-insns.json')):
  q=load(path)['result'][0];assert q['cursor']=={'done':True} and not q.get('truncated') and not q.get('error')
  assert q['count']==q['scanned']==len(q['matches']) and len(q['ranges'])==1
  addr=num(q['ranges'][0]['start']);size=num(q['ranges'][0]['end'])-addr
  body(addr,size,captured[addr],q['matches'],path.relative_to(H).as_posix(),True)
 for path in sorted(capture.glob('*-decompile.json')):
  q=load(path);assert q['cursor']=={'done':True} and not q.get('truncated') and q['line_count']==q['total_lines']
 sources={
  'docs/research/attack-owner-cell-20261013/evidence.json':[0x3D25D0,0x3D29B0,0x3D0EB0],
  'docs/research/attack-object-ownership-20261011/evidence.json':[0x40F1C0,0x40F4C0],
  'artifacts/actor-contact-retirement-20261013/evidence.json':[0x3CFF40],
 }
 for rel,rvas in sources.items():
  path=ROOT/rel;ev=load(path);selected=[f for f in ev['functions'] if num(f['addr'])-B in rvas];assert len(selected)==len(rvas)
  deps.append({'path':rel,'sha256':sha(path.read_bytes()),'functions':[hex(B+r) for r in rvas]})
  for f in selected:
   if 'instructions' in f:rows=f['instructions']
   elif 'disassembly' in f:rows=f['disassembly']['asm']['lines']
   else:rows=[r for page in f['pages'] for r in page['asm']['lines']]
   body(num(f['addr']),f['size'],octets(f['originalBytes']),rows,rel+'#functions[addr='+f['addr']+']',False)
 xrefs=[]
 for path in sorted(capture.glob('*xrefs.json')):
  for q in load(path)['result']:
   assert not q.get('more') and q['xref_count']==len(q['xrefs'])
   xrefs.append({'addr':q['addr'],'count':q['xref_count'],'source':path.relative_to(H).as_posix()})
 tables=[]
 for rva,size in [(0x5CE6C0,32),(0x5C62E8,8)]:
  data=pe(B+rva,size);tables.append({'addr':hex(B+rva),'size':size,'bytes':data.hex(),'qwords':[hex(x[0]) for x in struct.iter_unpack('<Q',data)]})
 assert num(tables[0]['qwords'][0])==B+0x40F4C0
 assert num(tables[0]['qwords'][3])==B+0x40F610
 assert num(tables[1]['qwords'][0])==B+0x3D29B0
 anchors=[]
 for rva in [0x3D2694,0x3D26E0,0x3D26E5,0x3D26ED,0x40F468,0x40F4D9,0x40F4E0,0x3CFFF9,0x3D0002,0x40F8BF,0x4323C2]:
  i=ins[B+rva];anchors.append({'addr':hex(i.address),'bytes':bytes(i.bytes).hex(),'instruction':i.mnemonic+' '+i.op_str})
 machinepath=ROOT/'docs/research/attack-object-ownership-20261011/machine.py'
 machinehash=sha(machinepath.read_bytes())
 assert machinehash=='f753c7e4c969e79dedb33b3699b8ef73b4720f6e5f84dc92dda9ca8d12e370eb'
 spec=importlib.util.spec_from_file_location('slot_machine',machinepath);machine=importlib.util.module_from_spec(spec);spec.loader.exec_module(machine)
 from probe import run
 probe=run(machine,ins,pe)
 emit('probe-results.json',probe)
 emit('evidence.json',{'schema':1,'originalSha256':PIN,'functions':fs,'dependencies':deps,'data':tables,'anchors':anchors,'xrefQueries':xrefs,'interpreter':{'path':machinepath.relative_to(ROOT).as_posix(),'sha256':machinehash,'modified':False}})
 claims=load(H/'report.json')['claims'];referencecount=0
 parser=runpy.run_path(str(ROOT/'scripts/update-analysis-coverage.py'),run_name='bounded_slot_reference_check')
 for claim in claims:
  assert {'addr','Finding','Evidence','Limitations'}<=claim.keys()
  for reference in claim['Evidence']:
   assert parser['resolve_reference'](H/'report.json',reference).get('status')=='exists',reference
   referencecount+=1
 groups={}
 for fresh,name in [(True,'fresh'),(False,'reused')]:
  selection=[f for f in fs if f['sourceMetadata']['freshCapture']==fresh]
  groups[name]={'functions':len(selection),'instructions':sum(len(f['instructions']) for f in selection),'bodyBytes':sum(f['size'] for f in selection)}
 emit('verification.json',{'status':'PASS','originalSha256':PIN,'counts':groups,'dataBytes':sum(t['size'] for t in tables),'anchors':len(anchors),'claims':len(claims),'resolvedEvidenceReferences':referencecount,'probeCases':probe['caseCount'],'probeSteps':probe['steps'],'probeDistinctInstructions':probe['distinctInstructions'],'readiness':'Root session captures; global autoanalysis completion not independently observed.','scope':'Original bytes/instruction boundaries/mnemonics and explicit synthetic external-boundary fixtures; no native execution or reachable game-bug claim.'})
 if check and (H/'manifest.json').exists():
  records=load(H/'manifest.json')['files'];actual={p.relative_to(H).as_posix() for p in H.rglob('*') if p.is_file() and p.name!='manifest.json'}
  assert actual=={r['path'] for r in records}
  for r in records:
   data=(H/r['path']).read_bytes();assert len(data)==r['bytes'] and sha(data)==r['sha256']
 print(json.dumps({'status':'PASS','counts':groups,'dataBytes':sum(t['size'] for t in tables),'probeCases':probe['caseCount'],'steps':probe['steps'],'distinctInstructions':probe['distinctInstructions']}))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');main(p.parse_args().check)
