"""Synthetic call ordering; execute original local bodies, explicitly stub externals."""
def run(module,instructions,pe):
 B=module.B;STACK=module.STACK
 A=0x200000;G=0x210000;OLD=0x220000;NEW=0x230000;PARAM=0x240000;OTHER=0x250000
 HEAD=B+0x2A24B40;ACTIVE=B+0x2A24B58
 cases=[];visited=set();totalsteps=0
 for name,param,tag,active,listed in [
  ('parameter_change',29,3,1,True),('tag_change',17,4,1,True),
  ('same_parameters',17,3,1,True),('inactive_marking',29,3,0,True),
  ('missing_contact_membership',29,3,1,False),
 ]:
  m=module.Machine(instructions,pe)
  for at,size in [(A,4096),(G,4096),(OLD,728),(NEW,728),(PARAM,64),(OTHER,728),(HEAD,32)]:m.allocate(at,size)
  enc={0:0};dec={0:0};events=[]
  def encode(pointer):
   if pointer not in enc:enc[pointer]=0x100+4*len(enc);dec[enc[pointer]]=pointer
   return enc[pointer]
  def decode(x):assert x.reg('ecx') in dec;x.setreg('rax',dec[x.reg('ecx')])
  def alloc(x):assert x.reg('ecx')==728;events.append('allocate_new');x.setreg('rax',NEW)
  def base_construct(x):
   # This stub provides fields used after the opaque common constructor call.
   # It intentionally does not claim native list insertion or refcount behavior.
   assert x.reg('rcx')==NEW and x.reg('rdx')==A and x.reg('r8')==G
   m.put(NEW+20,4,encode(G));m.put(NEW+24,4,x.reg('r9d'));m.put(NEW+36,4,9);m.put(NEW+48,8,PARAM)
   events.append('opaque_base_constructor');x.setreg('rax',NEW)
  def common_cleanup(x):
   assert x.reg('rcx')==OLD and m.get(cell,8)==0
   events.append('opaque_common_cleanup_after_observed_zero');x.setreg('rax',0)
  def free(x):assert x.reg('rcx')==OLD;events.append('opaque_free')
  m.stubs.update({B+0x4AD270:decode,B+0x4AD240:lambda x:x.setreg('eax',encode(x.reg('rcx'))),B+0x152430:alloc,B+0x3CF830:base_construct,B+0x3CFB10:common_cleanup,B+0x152570:free})
  manager=A+3088;cell=manager+16
  m.put(manager,4,encode(A));m.put(manager+4,4,9);m.put(manager+8,4,3);m.put(cell,8,OLD)
  m.put(OLD+20,4,encode(G));m.put(OLD+24,4,17);m.put(OLD+200,4,7);m.put(OLD+720,8,cell)
  m.put(PARAM+18,1,10);m.put(HEAD,8,OLD if listed else OTHER);m.put(ACTIVE,1,active)
  def invoke(rva,args):
   m.setreg('rsp',STACK);m.put(STACK,8,0);m.depth=0;m.invoke(rva,args,budget=5000)
  invoke(0x3D25D0,(manager,param,7,G,tag))
  changed=(param!=17 or tag!=3)
  assert m.get(cell,8)==(NEW if changed else OLD)
  assert m.get(OLD+720,8)==cell
  marked=bool(m.get(OLD+8,4)&0x800)
  assert marked==bool(changed and active and listed)
  row={'case':name,'replacement':changed,'oldMarked':marked,'cellAfterManager':hex(m.get(cell,8)),'oldCellPointer':hex(m.get(OLD+720,8)),'callerSuppliedLaterDestructor':False}
  if changed:
   assert m.get(NEW+720,8)==cell and m.get(NEW+200,4)==7
   assert m.get(NEW+24,4)==param and m.get(manager+8,4)==tag
   row['newCellPointer']=hex(m.get(NEW+720,8))
   if marked:
    # The fixture chooses a later deletion, representing the proven native
    # consumer edge without pretending to execute its full scheduling context.
    invoke(0x40F4C0,(OLD,1))
    assert m.get(cell,8)==0 and m.get(NEW+720,8)==cell
    row.update(callerSuppliedLaterDestructor=True,cellAfterOldDestructor=hex(m.get(cell,8)),newObjectStillAllocatedInFixture=True)
  else:assert not events
  row.update(events=events,steps=m.steps);cases.append(row);totalsteps+=m.steps;visited.update(m.visited)
 return {'kind':'Original local bodies with explicit opaque native-helper fixtures; staged calls, not game execution','caseCount':len(cases),'cases':cases,'steps':totalsteps,'distinctInstructions':len(visited),'limits':[
  'The manager, mark helper, derived constructor and old deleting wrapper execute decoded original instructions. No branch replacing their local slot stores is modeled.',
  'Common constructor and common cleanup are opaque stubs. They do not establish native registration, unlinking, refcounts or all side effects.',
  'Ptr32 mapping and successful allocation are fixture inputs; all synthetic object/cell memory is supplied and remains allocated.',
  'Two later old-destructor calls are explicitly supplied by the fixture; the contact scheduler/caller sequence is not executed.',
  'No asynchronous mutation, reentrancy, external-helper writes, caller-save clobbering, exception or lifetime/concurrency behavior is modeled.',
  'A cleared new registration in this fixture is not a reachable game bug, memory leak or use-after-free proof.'
 ]}
